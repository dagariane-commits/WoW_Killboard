--[[
    WoWKillboard - UI.lua
    In-game graphical dashboard modeled after EVE Online's zKillboard.com.
    Features:
    - Dark Tactical Glassmorphic Theme with clean 1px gunmetal borders.
    - Real-time KPI Stat Cards Header (K/D, Duels W/L, BGs W/L, Arenas W/L).
    - Dynamic 5-Way Mode Filter Pills (All PvP, World, BGs, Arenas, Duels) with active glow states.
    - Embedded High-Resolution Blizzard Class Icons on combatants.
    - Left-edge colored engagement accent bars (Gold = Duel, Purple = Arena, Cyan = BG, Green = Solo, Orange = Gang).
    - Alternating Zebra Striping and smooth row hover highlights.
    - Split Dossier Killmail Detail Modal with dual combatant cards.
    - 100% Template-Free & Secure: Zero UIPanel templates, zero UISpecialFrames,
      zero anonymous frame churning, zero combat lockdown taint.
]]

WoWKillboard = WoWKillboard or {}
local KB = WoWKillboard
KB.UI = {}
local UI = KB.UI

local SafePrint = function(...)
    if KB.Utils and KB.Utils.SafePrint then
        KB.Utils.SafePrint(...)
    elseif not InCombatLockdown() and DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        local pieces = {}
        for i = 1, select("#", ...) do table.insert(pieces, tostring(select(i, ...))) end
        DEFAULT_CHAT_FRAME:AddMessage(table.concat(pieces, " "))
    end
end

local mainFrame = nil
local activeTab = "FEED"   -- "FEED", "LEADERBOARD", "BOUNTIES", "RALLIES", "ZONES"
local currentMode = "WORLD"  -- "WORLD", "BG", "DUEL", "ARENA"
local currentFilter = "ALL"  -- "ALL", "SOLO", "GROUP", "RAID"
local hlSubTab = "PLAYERS"   -- "PLAYERS" (Player Ranks), "GUILDS" (Guild Ranks), "GANKERS_24H" (Top Gankers 24h)
local ribbonMode = "REALM"   -- "REALM" or "SESSION" (Defaults to REALM for immediate telemetry visibility)
local marksSubTab = "ACTIVE" -- "ACTIVE" (Execution List), "RECORDS" (Hall of Fame), "DEBTORS" (The Marked Debts)

local pveHlSubTab = "PREDATORS" -- "PREDATORS" (Monsters & Elites), "VICTIMS" (Fallen Mortals), "ZONES" (Deadliest Zones)

local tabButtons = {}
local filterButtons = {}

function UI:GetRuleset()
    local realm = (GetRealmName and GetRealmName()) or ""
    if WoWKillboardDB and WoWKillboardDB.realmRulesets and realm ~= "" and WoWKillboardDB.realmRulesets[realm] then
        return tostring(WoWKillboardDB.realmRulesets[realm]):upper()
    end
    if KB.Utils and KB.Utils.GetRealmRuleset then
        return KB.Utils.GetRealmRuleset()
    end
    if WoWKillboardDB and WoWKillboardDB.campaignRuleset then
        return tostring(WoWKillboardDB.campaignRuleset):upper()
    end
    if realm:lower():find("pve") or realm:lower():find("normal") then return "PVE" end
    return "PVP"
end

function UI:IsPve()
    if KB.Utils and KB.Utils.IsPveRuleset then
        return KB.Utils.IsPveRuleset()
    end
    local r = UI:GetRuleset()
    return (r == "PVE" or r == "HARDCORE" or r == "RP")
end

-- Standard Blizzard Class Coordinates (safe fallback for all WoW versions)
local CLASS_ICON_TEXTURE = "Interface\\TargetingFrame\\UI-Classes-Circles"
local CLASS_COORDS = CLASS_ICON_TCOORDS or {
    WARRIOR     = {0, 0.25, 0, 0.25},
    MAGE        = {0.25, 0.49609375, 0, 0.25},
    ROGUE       = {0.49609375, 0.7421875, 0, 0.25},
    DRUID       = {0.7421875, 0.98828125, 0, 0.25},
    HUNTER      = {0, 0.25, 0.25, 0.5},
    SHAMAN      = {0.25, 0.49609375, 0.25, 0.5},
    PRIEST      = {0.49609375, 0.7421875, 0.25, 0.5},
    WARLOCK     = {0.7421875, 0.98828125, 0.25, 0.5},
    PALADIN     = {0, 0.25, 0.5, 0.75},
    DEATHKNIGHT = {0.25, 0.49609375, 0.5, 0.75},
    MONK        = {0.49609375, 0.7421875, 0.5, 0.75},
    DEMONHUNTER = {0.7421875, 0.98828125, 0.5, 0.75},
    EVOKER      = {0, 0.25, 0.75, 1.0},
}

-- Helper function to generate a flat modern web card (Theme 3: Web 1:1)
local function ApplyWebTheme(frame, bgColor, borderColor)
    if not frame or not frame.SetBackdrop then return end
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false,
        tileSize = 0,
        edgeSize = 1, -- Exact 1px solid border
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    
    local bg = bgColor or { 0.067, 0.094, 0.153, 1.0 }
    local border = borderColor or { 0.122, 0.161, 0.216, 1.0 }
    
    frame:SetBackdropColor(bg[1], bg[2], bg[3], bg[4])
    frame:SetBackdropBorderColor(border[1], border[2], border[3], border[4])
end
UI.ApplyWebTheme = ApplyWebTheme

-- Flat Pill Button Styling (100% pure Lua BackdropTemplate)
local function CreateWebPillButton(parent, text, width, height)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(width or 70, height or 22)
    
    btn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    
    local bg = btn:CreateTexture(nil, "BACKGROUND", nil, -1)
    bg:SetAllPoints(btn)
    bg:SetColorTexture(0.06, 0.08, 0.12, 0.8)
    btn.bg = bg
    
    -- Inactive default state: dark slate fill with muted gray text
    btn:SetBackdropColor(0.06, 0.08, 0.12, 0.8)
    btn:SetBackdropBorderColor(0.15, 0.19, 0.26, 1.0)
    
    local fontString = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fontString:SetPoint("CENTER", 0, 0)
    fontString:SetText(text or "")
    fontString:SetTextColor(0.65, 0.70, 0.75, 1.0)
    if fontString.SetFont then local f, s = fontString:GetFont(); fontString:SetFont(f, s or 10, "OUTLINE") end
    fontString:SetShadowOffset(0, 0)
    btn.text = fontString
    btn.Label = fontString
    
    btn:SetScript("OnEnter", function(self)
        if not self.isActive then
            if self.bg then self.bg:SetColorTexture(0.12, 0.16, 0.24, 1.0) end
            self:SetBackdropColor(0.12, 0.16, 0.24, 1.0)
            self:SetBackdropBorderColor(0.78, 0.60, 0.24, 0.8)
            if self.Label then self.Label:SetTextColor(1, 1, 1, 1) end
            if self.text then self.text:SetTextColor(1, 1, 1, 1) end
        end
    end)
    btn:SetScript("OnLeave", function(self)
        if not self.isActive then
            if self.bg then self.bg:SetColorTexture(0.06, 0.08, 0.12, 0.8) end
            self:SetBackdropColor(0.06, 0.08, 0.12, 0.8)
            self:SetBackdropBorderColor(0.15, 0.19, 0.26, 1.0)
            if self.Label then self.Label:SetTextColor(0.65, 0.70, 0.75, 1.0) end
            if self.text then self.text:SetTextColor(0.65, 0.70, 0.75, 1.0) end
        else
            if self.bg then self.bg:SetColorTexture(0.78, 0.60, 0.24, 1.0) end
            self:SetBackdropColor(0.78, 0.60, 0.24, 1.0)
            self:SetBackdropBorderColor(0.85, 0.70, 0.30, 1.0)
            if self.Label then self.Label:SetTextColor(0.05, 0.05, 0.05, 1.0) end
            if self.text then self.text:SetTextColor(0.05, 0.05, 0.05, 1.0) end
        end
    end)
    
    return btn
end
UI.CreateWebPillButton = CreateWebPillButton

-- Theme Engine: Strict 3-Theme Architecture (WKB Theme vs ElvUI vs Classic Blizzard Stone)
function UI:GetCurrentThemeName()
    local t = nil
    if WoWKillboardDB and WoWKillboardDB.theme then
        t = WoWKillboardDB.theme:lower()
    elseif WoWKillboardSettings and WoWKillboardSettings.theme then
        t = WoWKillboardSettings.theme:lower()
    end
    if t == "classic" then return "classic" end
    if t == "elvui" then return "elvui" end
    return "wkb"
end

function UI:GetTheme()
    local name = UI:GetCurrentThemeName()
    return (KB.Themes and (KB.Themes[name:upper()] or KB.Themes[name])) or (KB.Themes and (KB.Themes["WKB"] or KB.Themes["wkb"])) or {}
end

function UI:SetTheme(themeName)
    themeName = (themeName or ""):lower()
    if themeName == "web" or themeName == "slate" or themeName == "shadownetwork" or themeName == "web11" or themeName == "web_slate" then
        themeName = "wkb"
    end
    if themeName ~= "classic" and themeName ~= "elvui" and themeName ~= "wkb" then
        themeName = "wkb"
    end

    WoWKillboardDB = WoWKillboardDB or {}
    WoWKillboardDB.theme = themeName

    WoWKillboardSettings = WoWKillboardSettings or {}
    WoWKillboardSettings.theme = themeName

    UI:ApplyTheme()
    UI:ApplyBannerTheme()
    if mainFrame and mainFrame:IsShown() then
        UI:Refresh()
    end

    local th = KB.Themes and (KB.Themes[themeName:upper()] or KB.Themes[themeName])
    if th and th.name then
        SafePrint(string.format("|cff00ccff[WoWKB]|r Theme switched to: |cffffd100%s|r", th.name))
    end
end

function UI:CycleTheme()
    local current = UI:GetCurrentThemeName()
    local nextTheme
    if current == "wkb" then
        nextTheme = "elvui"
    elseif current == "elvui" then
        nextTheme = "classic"
    else
        nextTheme = "wkb"
    end
    UI:SetTheme(nextTheme)
    return nextTheme
end

function UI:ApplyButtonStyle(btn, theme)
    if not btn then return end
    theme = theme or UI:GetTheme()

    local nt = btn:GetNormalTexture()
    if nt then nt:SetTexture(nil) nt:Hide() end
    local pt = btn:GetPushedTexture()
    if pt then pt:SetTexture(nil) pt:Hide() end
    local ht = btn:GetHighlightTexture()
    if ht then ht:SetTexture(nil) ht:Hide() end

    if theme.btnBackdrop then
        btn:SetBackdrop(theme.btnBackdrop)
        if btn.isActive then
            btn:SetBackdropColor(unpack(theme.btnActiveBg or {0.32, 0.22, 0.10, 1.0}))
            btn:SetBackdropBorderColor(unpack(theme.btnActiveBorder or {1.0, 0.84, 0.0, 1.0}))
        else
            btn:SetBackdropColor(unpack(theme.btnBg))
            btn:SetBackdropBorderColor(unpack(theme.btnBorder))
        end
    end

    if btn.Label then
        if theme.id == "classic" then
            btn.Label:SetTextColor(1.0, 0.82, 0.0)
            btn.Label:SetShadowOffset(1, -1)
            btn.Label:SetShadowColor(0, 0, 0, 1)
        else
            btn.Label:SetTextColor(1.0, 1.0, 1.0)
            btn.Label:SetShadowOffset(1, -1)
            btn.Label:SetShadowColor(0, 0, 0, 1)
        end
    end
end

function UI:ApplyTheme()
    if not mainFrame then return end
    local theme = UI:GetTheme()
    if not theme or not theme.mainBackdrop then return end

    if UI.SolidBg then
        if theme.id == "classic" then
            UI.SolidBg:Hide()
        else
            UI.SolidBg:Show()
            UI.SolidBg:SetColorTexture(unpack(theme.solidBg or theme.mainBg))
        end
    end

    mainFrame:SetBackdrop(theme.mainBackdrop)
    mainFrame:SetBackdropColor(unpack(theme.mainBg))
    mainFrame:SetBackdropBorderColor(unpack(theme.mainBorder))

    if UI.ContentInset then
        UI.ContentInset:SetBackdrop(theme.insetBackdrop or theme.cardBackdrop)
        UI.ContentInset:SetBackdropColor(unpack(theme.insetBg or theme.cardBg))
        UI.ContentInset:SetBackdropBorderColor(unpack(theme.insetBorder or theme.cardBorder))
        if UI.ContentInset.BgArt then
            if theme.id == "classic" then
                UI.ContentInset.BgArt:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\dark_war_bg.tga")
                UI.ContentInset.BgArt:SetTexCoord(0, 1, 0, 1)
                UI.ContentInset.BgArt:SetAlpha(0.40)
                if UI.ContentInset.Vignette then
                    UI.ContentInset.Vignette:SetColorTexture(0.06, 0.05, 0.04, 0.65)
                    UI.ContentInset.Vignette:SetAlpha(0.65)
                    UI.ContentInset.Vignette:Show()
                end
                UI.ContentInset.BgArt:Show()
            elseif theme.id == "web" or theme.id == "elvui" then
                UI.ContentInset.BgArt:Hide()
                if UI.ContentInset.Vignette then
                    UI.ContentInset.Vignette:Hide()
                end
            else
                UI.ContentInset.BgArt:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\dark_war_bg.tga")
                UI.ContentInset.BgArt:SetTexCoord(0, 1, 0, 1)
                UI.ContentInset.BgArt:SetAlpha(0.65)
                if UI.ContentInset.Vignette then
                    UI.ContentInset.Vignette:SetColorTexture(0.015, 0.02, 0.035, 0.40)
                    UI.ContentInset.Vignette:SetAlpha(0.40)
                    UI.ContentInset.Vignette:Show()
                end
                UI.ContentInset.BgArt:Show()
            end
        end
    end

    if UI.MainContainer then
        UI.MainContainer:SetBackdropColor(unpack(theme.insetBg or theme.cardBg))
        UI.MainContainer:SetBackdropBorderColor(unpack(theme.insetBorder or theme.cardBorder))
    end
    if UI.SidebarContainer then
        if theme.sidebarContainerBg then
            UI.SidebarContainer:SetBackdropColor(unpack(theme.sidebarContainerBg))
            UI.SidebarContainer:SetBackdropBorderColor(unpack(theme.sidebarContainerBorder))
        elseif theme.id == "wkb" or theme.id == "web" then
            UI.SidebarContainer:SetBackdropColor(0.015, 0.023, 0.035, 0.0)
            UI.SidebarContainer:SetBackdropBorderColor(0.015, 0.023, 0.035, 0.0)
        else
            UI.SidebarContainer:SetBackdropColor(unpack(theme.cardBg or theme.insetBg))
            UI.SidebarContainer:SetBackdropBorderColor(unpack(theme.cardBorder or theme.insetBorder))
        end
    end

    if UI.HeaderPlate then
        if theme.id == "classic" then
            UI.HeaderPlate:Show()
            if UI.TitleText then
                UI.TitleText:ClearAllPoints()
                UI.TitleText:SetPoint("TOP", UI.HeaderPlate, "TOP", 0, -10)
                UI.TitleText:SetFontObject("GameFontNormalLarge")
                UI.TitleText:SetText("|cffffd100WoW Killboard|r")
            end
            if UI.SubtitleText and UI.TitleText then
                UI.SubtitleText:ClearAllPoints()
                UI.SubtitleText:SetPoint("TOP", UI.TitleText, "BOTTOM", 0, -2)
                local sub = KB.Utils and KB.Utils.GetClientFlavorSubtitle and KB.Utils.GetClientFlavorSubtitle()
                UI.SubtitleText:SetText(sub or string.format("|cff00e5ffWoW Forever|r | |cffc7b28c%s|r | |cff888888v%s|r", (GetRealmName and GetRealmName()) or "PvP", KB.Version))
            end
        else
            UI.HeaderPlate:Hide()
            if UI.TitleText and (UI.PlayerPortrait or (UI.Medallion and UI.Medallion.Frame)) then
                local medFrame = UI.PlayerPortrait or UI.Medallion.Frame
                UI.TitleText:ClearAllPoints()
                UI.TitleText:SetPoint("LEFT", medFrame, "RIGHT", 14, 0)
                UI.TitleText:SetFontObject("GameFontNormalLarge")
                UI.TitleText:SetText(theme.titleText or "|cffffd100WoW Killboard|r")
            end
            if UI.SubtitleText and UI.TitleText then
                UI.SubtitleText:ClearAllPoints()
                UI.SubtitleText:SetPoint("TOPLEFT", UI.TitleText, "BOTTOMLEFT", 0, -3)
                local sub = KB.Utils and KB.Utils.GetClientFlavorSubtitle and KB.Utils.GetClientFlavorSubtitle()
                UI.SubtitleText:SetText(sub or string.format("|cff00e5ffWoW Forever|r | |cffc7b28c%s|r | |cff888888v%s|r", (GetRealmName and GetRealmName()) or "PvP", KB.Version))
            end
        end
    end
    if UI.ThemeButton then
        UI:ApplyButtonStyle(UI.ThemeButton, theme)
        if UI.ThemeButton.Label then UI.ThemeButton.Label:SetText(theme.themeBtnText) end
        if theme.id == "classic" then UI.ThemeButton:SetHeight(22) else UI.ThemeButton:SetHeight(20) end
    end
    if UI.AlertsButton then
        UI:ApplyButtonStyle(UI.AlertsButton, theme)
        if theme.id == "classic" then UI.AlertsButton:SetHeight(22) else UI.AlertsButton:SetHeight(20) end
    end
    if UI.CallBackupButton then
        UI:ApplyButtonStyle(UI.CallBackupButton, theme)
        if theme.id == "classic" then UI.CallBackupButton:SetHeight(22) else UI.CallBackupButton:SetHeight(20) end
    end
    if UI.WebProfileButton then
        UI:ApplyButtonStyle(UI.WebProfileButton, theme)
        if theme.id == "classic" then UI.WebProfileButton:SetHeight(22) else UI.WebProfileButton:SetHeight(20) end
    end
    if UI.ExportButton then
        UI:ApplyButtonStyle(UI.ExportButton, theme)
        if theme.id == "classic" then UI.ExportButton:SetHeight(22) else UI.ExportButton:SetHeight(20) end
    end
    if UI.SyncButton then
        UI:ApplyButtonStyle(UI.SyncButton, theme)
        if theme.id == "classic" then UI.SyncButton:SetHeight(22) else UI.SyncButton:SetHeight(20) end
    end
    if UI.SettingsButton then
        UI:ApplyButtonStyle(UI.SettingsButton, theme)
        if theme.id == "classic" then UI.SettingsButton:SetHeight(22) else UI.SettingsButton:SetHeight(20) end
    end
    if UI.BugButton then
        UI:ApplyButtonStyle(UI.BugButton, theme)
        if theme.id == "classic" then UI.BugButton:SetHeight(22) else UI.BugButton:SetHeight(20) end
    end
    if UI.WireButton then
        UI:ApplyButtonStyle(UI.WireButton, theme)
        if theme.id == "classic" then UI.WireButton:SetHeight(22) else UI.WireButton:SetHeight(20) end
    end
    if UI.RibbonToggleBtn then
        UI:ApplyButtonStyle(UI.RibbonToggleBtn, theme)
        if theme.id == "classic" then UI.RibbonToggleBtn:SetHeight(22) else UI.RibbonToggleBtn:SetHeight(20) end
    end
    if UI.RegisteredButtons then
        for _, b in ipairs(UI.RegisteredButtons) do
            UI:ApplyButtonStyle(b, theme)
        end
    end
    if UI.CloseButton then
        UI.CloseButton:SetSize(22, 22)
        UI.CloseButton:ClearAllPoints()
        UI.CloseButton:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -8, -8)
        local nt = UI.CloseButton:GetNormalTexture()
        if nt then nt:SetTexture(nil) nt:Hide() end
        local pt = UI.CloseButton:GetPushedTexture()
        if pt then pt:SetTexture(nil) pt:Hide() end
        local ht = UI.CloseButton:GetHighlightTexture()
        if ht then ht:SetTexture(nil) ht:Hide() end
        UI.CloseButton:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        if theme.id == "classic" then
            UI.CloseButton:SetBackdropColor(0.14, 0.10, 0.07, 1.0)
            UI.CloseButton:SetBackdropBorderColor(0.60, 0.48, 0.22, 1.0)
        else
            UI.CloseButton:SetBackdropColor(0.10, 0.10, 0.12, 1.0)
            UI.CloseButton:SetBackdropBorderColor(0.0, 0.0, 0.0, 1.0)
        end
        if UI.CloseButton.Label then
            UI.CloseButton.Label:SetFontObject("GameFontHighlightSmall")
            UI.CloseButton.Label:SetText("|cffff3333X|r")
        end
    end
    if UI.Divider then
        UI.Divider:SetColorTexture(unpack(theme.dividerColor))
    end
    if UI.TopMetricsBar then
        if UI.TopMetricsBar.SetBackdrop then
            UI.TopMetricsBar:SetBackdrop(theme.cardBackdrop or theme.insetBackdrop)
            UI.TopMetricsBar:SetBackdropColor(unpack(theme.cardBg or {24/255, 24/255, 24/255, 1.0}))
            UI.TopMetricsBar:SetBackdropBorderColor(unpack(theme.cardBorder or {0, 0, 0, 1.0}))
        end
    end
    if UI.StatCards then
        for _, card in pairs(UI.StatCards) do
            if type(card) == "table" and card.SetBackdrop and not UI.TopMetricsBar then
                card:SetBackdrop(theme.cardBackdrop)
                card:SetBackdropColor(unpack(theme.cardBg))
                card:SetBackdropBorderColor(unpack(theme.cardBorder))
            end
            if card.HeaderStrip then
                card.HeaderStrip:SetColorTexture(unpack(theme.cardHeaderBg or {0.09, 0.12, 0.17, 1.0}))
            end
            if card.HeaderDivider then
                card.HeaderDivider:SetColorTexture(unpack(theme.cardHeaderBorder or {0.35, 0.28, 0.16, 0.8}))
            end
            if card.TitleLabel and card.rawTitle then
                local tColor = (theme.id == "classic") and "|cffffd100" or ((theme.id == "web") and "|cfffbbf24" or "|cffffffff")
                card.TitleLabel:SetText(tColor .. card.rawTitle .. "|r")
            end
        end
    end
    if UI.SidebarCards then
        for _, card in ipairs(UI.SidebarCards) do
            if card and card.SetBackdrop then
                card:SetBackdropColor(unpack(theme.cardBg))
                card:SetBackdropBorderColor(unpack(theme.cardBorder))
            end
            if card.HeaderStrip then
                card.HeaderStrip:SetColorTexture(unpack(theme.cardHeaderBg or {0.025, 0.035, 0.055, 1.0}))
            end
            if card.HeaderDivider then
                card.HeaderDivider:SetColorTexture(unpack(theme.cardHeaderBorder or {0.58, 0.45, 0.22, 0.4}))
            end
            if card.Title then
                if theme.headerColor then
                    card.Title:SetTextColor(unpack(theme.headerColor))
                elseif theme.id == "classic" then
                    card.Title:SetTextColor(1.0, 0.82, 0.0, 1.0)
                elseif theme.id == "wkb" or theme.id == "web" then
                    card.Title:SetTextColor(0.78, 0.65, 0.35, 1.0)
                else
                    card.Title:SetTextColor(1.0, 1.0, 1.0, 1.0)
                end
            end
            if card.TitleLabel and card.rawTitle then
                local tColor = (theme.id == "classic") and "|cffffd100" or ((theme.id == "wkb" or theme.id == "web") and "|cfffbbf24" or "|cffffffff")
                card.TitleLabel:SetText(tColor .. card.rawTitle .. "|r")
            end
        end
    end
    if UI.DetailModal then
        if UI.DetailModal.SolidBg then
            if theme.id == "classic" then
                UI.DetailModal.SolidBg:Hide()
            else
                UI.DetailModal.SolidBg:Show()
                UI.DetailModal.SolidBg:SetColorTexture(unpack(theme.solidBg or theme.modalBg))
            end
        end
        UI.DetailModal:SetBackdrop(theme.modalBackdrop)
        UI.DetailModal:SetBackdropColor(unpack(theme.modalBg))
        UI.DetailModal:SetBackdropBorderColor(unpack(theme.modalBorder))
        if UI.DetailModal.Title then
            local mColor = (theme.id == "classic") and "|cffffd100" or ((theme.id == "web") and "|cfffbbf24" or "|cffffffff")
            UI.DetailModal.Title:SetText(mColor .. "KILLMAIL COMBAT RECORD|r")
        end
        if UI.DetailModal.CloseBtn then
            if theme.id == "classic" then
                UI.DetailModal.CloseBtn:SetSize(24, 24)
                UI.DetailModal.CloseBtn:ClearAllPoints()
                UI.DetailModal.CloseBtn:SetPoint("TOPRIGHT", UI.DetailModal, "TOPRIGHT", -4, -4)
                UI.DetailModal.CloseBtn:SetBackdrop(nil)
                local nt = UI.DetailModal.CloseBtn:GetNormalTexture()
                if nt then nt:Show() end
                local pt = UI.DetailModal.CloseBtn:GetPushedTexture()
                if pt then pt:Show() end
                local ht = UI.DetailModal.CloseBtn:GetHighlightTexture()
                if ht then ht:Show() end
                UI.DetailModal.CloseBtn:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
                UI.DetailModal.CloseBtn:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
                UI.DetailModal.CloseBtn:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight", "ADD")
                if UI.DetailModal.CloseBtn.Label then UI.DetailModal.CloseBtn.Label:SetText("") end
            else
                UI.DetailModal.CloseBtn:SetSize(18, 18)
                UI.DetailModal.CloseBtn:ClearAllPoints()
                UI.DetailModal.CloseBtn:SetPoint("TOPRIGHT", UI.DetailModal, "TOPRIGHT", -8, -8)
                local nt = UI.DetailModal.CloseBtn:GetNormalTexture()
                if nt then nt:SetTexture(nil) nt:Hide() end
                local pt = UI.DetailModal.CloseBtn:GetPushedTexture()
                if pt then pt:SetTexture(nil) pt:Hide() end
                local ht = UI.DetailModal.CloseBtn:GetHighlightTexture()
                if ht then ht:SetTexture(nil) ht:Hide() end
                UI.DetailModal.CloseBtn:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
                UI.DetailModal.CloseBtn:SetBackdropColor(0.10, 0.10, 0.12, 1.0)
                UI.DetailModal.CloseBtn:SetBackdropBorderColor(0.0, 0.0, 0.0, 1.0)
                if UI.DetailModal.CloseBtn.Label then UI.DetailModal.CloseBtn.Label:SetText("|cffff3333X|r") end
            end
        end
        if UI.DetailModal.DismissBtn then
            UI.DetailModal.DismissBtn:SetBackdrop(theme.btnBackdrop)
            UI.DetailModal.DismissBtn:SetBackdropColor(unpack(theme.btnBg))
            UI.DetailModal.DismissBtn:SetBackdropBorderColor(unpack(theme.btnBorder))
        end
        if UI.DetailModal.KillerCard then
            if theme.id == "classic" then
                UI.DetailModal.KillerCard:SetBackdrop(theme.cardBackdrop)
                UI.DetailModal.KillerCard:SetBackdropColor(0.08, 0.14, 0.10, 0.95)
                UI.DetailModal.KillerCard:SetBackdropBorderColor(0.2, 0.7, 0.3, 0.9)
                if UI.DetailModal.KillerCard.IconBorder then UI.DetailModal.KillerCard.IconBorder:Show() end
            else
                UI.DetailModal.KillerCard:SetBackdrop(theme.cardBackdrop)
                UI.DetailModal.KillerCard:SetBackdropColor(0.08, 0.12, 0.09, 0.95)
                UI.DetailModal.KillerCard:SetBackdropBorderColor(0.0, 0.0, 0.0, 1.0)
                if UI.DetailModal.KillerCard.IconBorder then UI.DetailModal.KillerCard.IconBorder:Hide() end
            end
        end
        if UI.DetailModal.VictimCard then
            if theme.id == "classic" then
                UI.DetailModal.VictimCard:SetBackdrop(theme.cardBackdrop)
                UI.DetailModal.VictimCard:SetBackdropColor(0.14, 0.08, 0.08, 0.95)
                UI.DetailModal.VictimCard:SetBackdropBorderColor(0.8, 0.25, 0.25, 0.9)
                if UI.DetailModal.VictimCard.IconBorder then UI.DetailModal.VictimCard.IconBorder:Show() end
            else
                UI.DetailModal.VictimCard:SetBackdrop(theme.cardBackdrop)
                UI.DetailModal.VictimCard:SetBackdropColor(0.12, 0.07, 0.07, 0.95)
                UI.DetailModal.VictimCard:SetBackdropBorderColor(0.0, 0.0, 0.0, 1.0)
                if UI.DetailModal.VictimCard.IconBorder then UI.DetailModal.VictimCard.IconBorder:Hide() end
            end
        end
        if UI.DetailModal.InfoPanel then
            if theme.id == "classic" then
                UI.DetailModal.InfoPanel:SetBackdrop(theme.cardBackdrop)
                UI.DetailModal.InfoPanel:SetBackdropColor(0.08, 0.07, 0.05, 0.95)
                UI.DetailModal.InfoPanel:SetBackdropBorderColor(unpack(theme.cardBorder))
            else
                UI.DetailModal.InfoPanel:SetBackdrop(theme.cardBackdrop)
                UI.DetailModal.InfoPanel:SetBackdropColor(0.07, 0.07, 0.07, 0.95)
                UI.DetailModal.InfoPanel:SetBackdropBorderColor(0.0, 0.0, 0.0, 1.0)
            end
        end
    end

    if UI.SearchBox then
        UI.SearchBox:SetBackdropColor(unpack(theme.searchBg or {0.07, 0.06, 0.04, 0.95}))
        UI.SearchBox:SetBackdropBorderColor(unpack(theme.searchBorder or {0.55, 0.44, 0.22, 0.95}))
        if UI.SearchBox.Icon then
            if theme.id == "classic" then
                UI.SearchBox.Icon:SetVertexColor(0.85, 0.75, 0.50, 0.8)
            else
                UI.SearchBox.Icon:SetVertexColor(0.70, 0.70, 0.70, 0.8)
            end
        end
    end

    if UI.ScrollBar then
        UI.ScrollBar:SetBackdropColor(unpack(theme.scrollbarRail or {0.05, 0.04, 0.03, 0.85}))
        UI.ScrollBar:SetBackdropBorderColor(unpack(theme.scrollbarRailBorder or {0.45, 0.35, 0.18, 0.8}))
        if UI.ScrollBar.Thumb then
            UI.ScrollBar.Thumb:SetColorTexture(unpack(theme.scrollbarThumb or {0.70, 0.55, 0.22, 0.95}))
        end
    end

    if KB.UpdateMinimapTheme then
        KB:UpdateMinimapTheme()
    end

    if UI.KillBanner then
        UI:ApplyBannerTheme()
    end
end

-- Standalone Tactical Button (Zero UIPanelButtonTemplate or sound XML taint)
function UI:CreateButton(parent, w, h, text, fontSize)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(w, h)
    btn:EnableMouse(true)

    local label = btn:CreateFontString(nil, "OVERLAY", fontSize or "GameFontHighlightSmall")
    label:SetPoint("CENTER", 0, 0)
    label:SetText(text or "")
    btn.Label = label

    UI:ApplyButtonStyle(btn, UI:GetTheme())

    UI.RegisteredButtons = UI.RegisteredButtons or {}
    table.insert(UI.RegisteredButtons, btn)

    btn:SetScript("OnEnter", function(self)
        local t = UI:GetTheme()
        if not self.isActive and t.btnHoverBg then
            self:SetBackdropColor(unpack(t.btnHoverBg))
            self:SetBackdropBorderColor(unpack(t.btnHoverBorder or {1.0, 0.85, 0.3, 1.0}))
        end
    end)
    btn:SetScript("OnLeave", function(self)
        local t = UI:GetTheme()
        if not self.isActive and t.btnBg then
            self:SetBackdropColor(unpack(t.btnBg))
            self:SetBackdropBorderColor(unpack(t.btnBorder))
        end
    end)

    return btn
end

-- Helper: Create a Class Icon Texture
function UI:CreateClassIcon(parent, classFilename, size)
    local tex = parent:CreateTexture(nil, "ARTWORK")
    tex:SetSize(size or 18, size or 18)
    tex:SetTexture(CLASS_ICON_TEXTURE)
    local coords = CLASS_COORDS[(classFilename or ""):upper()] or {0, 0.25, 0, 0.25}
    tex:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
    return tex
end

-- Cross-Client Safe Horizontal Gradient Helper
local function SafeSetHorizontalGradient(tex, r1, g1, b1, a1, r2, g2, b2, a2)
    if not tex then return end
    if tex.SetGradient and CreateColor then
        pcall(function()
            tex:SetGradient("HORIZONTAL", CreateColor(r1, g1, b1, a1), CreateColor(r2, g2, b2, a2))
        end)
    elseif tex.SetGradientAlpha then
        pcall(function()
            tex:SetGradientAlpha("HORIZONTAL", r1, g1, b1, a1, r2, g2, b2, a2)
        end)
    else
        tex:SetColorTexture(r1, g1, b1, a1)
    end
end
UI.SafeSetHorizontalGradient = SafeSetHorizontalGradient

-- Helper: Render high-contrast solid faction pill badge
local function CreateFactionBadge(parent, faction, width, height)
    local badge = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    badge:SetSize(width or 62, height or 16)
    badge:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })

    local icon = badge:CreateTexture(nil, "OVERLAY")
    icon:SetSize(12, 12)
    icon:SetPoint("LEFT", badge, "LEFT", 3, 0)
    badge.Icon = icon

    local text = badge:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    text:SetPoint("LEFT", icon, "RIGHT", 3, 0)
    text:SetPoint("RIGHT", badge, "RIGHT", -2, 0)
    text:SetJustifyH("LEFT")
    text:SetTextColor(1.0, 1.0, 1.0, 1.0) -- Bright crisp white
    if text.SetFont then
        local f, s = text:GetFont()
        text:SetFont(f, (s or 9), "OUTLINE")
    end
    text:SetShadowOffset(0, 0)
    badge.Label = text

    local fLower = tostring(faction or ""):lower()
    if fLower == "horde" then
        -- Horde Badge: Solid deep crimson red (0.55, 0.08, 0.08, 0.85) (Hex #8C1414), 1px border bright orange-red (0.85, 0.20, 0.20, 1.0)
        badge:SetBackdropColor(0.55, 0.08, 0.08, 0.85)
        badge:SetBackdropBorderColor(0.85, 0.20, 0.20, 1.0)
        icon:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\crest_horde.tga")
        text:SetText("Horde")
    elseif fLower == "alliance" then
        -- Alliance Badge: Solid deep royal blue (0.06, 0.22, 0.58, 0.85) (Hex #103894), 1px border bright cyan/sky blue (0.18, 0.45, 0.85, 1.0)
        badge:SetBackdropColor(0.06, 0.22, 0.58, 0.85)
        badge:SetBackdropBorderColor(0.18, 0.45, 0.85, 1.0)
        icon:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\crest_alliance.tga")
        text:SetText("Alliance")
    else
        badge:SetBackdropColor(0.10, 0.12, 0.16, 0.85)
        badge:SetBackdropBorderColor(0.20, 0.25, 0.35, 1.0)
        icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-FFA")
        text:SetText(tostring(faction or "Contested"))
    end

    return badge
end
UI.CreateFactionBadge = CreateFactionBadge

-- Helper: Apply clean subtle local player row highlight [YOU] without harsh border outlines
local function ApplyPlayerRowHighlight(row, faction)
    if not row then return end
    row.isPlayerRow = true

    -- Do NOT draw any yellow/gold border outline around the combatant's row, name, or icon
    -- Keep border natural and identical to surrounding rows

    if not row.highlightGrad then
        local grad = row:CreateTexture(nil, "BORDER")
        grad:SetAllPoints(row)
        row.highlightGrad = grad
    end

    -- Subtle semi-transparent background wash (0.12, 0.16, 0.24, 0.35) so the row stands out naturally without harsh edges
    row.highlightGrad:SetColorTexture(0.12, 0.16, 0.24, 0.35)
    row.highlightGrad:Show()
end
UI.ApplyPlayerRowHighlight = ApplyPlayerRowHighlight

-- Helper: Update circular portrait medallion and player level
function UI:UpdatePortrait()
    local pf = UI.PlayerPortrait or (UI.Medallion and UI.Medallion.Frame)
    local portraitTex = (pf and pf.portraitTex) or (UI.Medallion and UI.Medallion.Portrait)
    if portraitTex and SetPortraitTexture then
        SetPortraitTexture(portraitTex, "player")
        if not portraitTex:GetTexture() then
            portraitTex:SetTexture("Interface\\Icons\\Achievement_PVP_P_01")
        end
    end

    local pLvl = (UnitLevel and UnitLevel("player")) or 1
    if pLvl and pLvl > 0 then
        local lvlStr = tostring(pLvl)
        if UI.LevelBadge and UI.LevelBadge.SetText then
            UI.LevelBadge:SetText(lvlStr)
        end
        if pf and pf.levelBadge and pf.levelBadge.text and pf.levelBadge.text.SetText then
            pf.levelBadge.text:SetText(lvlStr)
        end
        if UI.Medallion and UI.Medallion.LevelBadge and UI.Medallion.LevelBadge.SetText then
            UI.Medallion.LevelBadge:SetText(lvlStr)
        end
    end
end

-- Create or show main window
function UI:Toggle()
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot toggle Killboard during combat.")
        return
    end

    if not mainFrame then
        UI:CreateMainWindow()
    end

    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        mainFrame:Show()
        UI:UpdatePortrait()
        UI:Refresh()
    end
end

function UI:ShowTab(tabId)
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot toggle Killboard during combat.")
        return
    end

    if not mainFrame then
        UI:CreateMainWindow()
    end

    if not mainFrame:IsShown() then
        mainFrame:Show()
        UI:UpdatePortrait()
    end

    activeTab = tabId or "FEED"
    UI:Refresh()
end

function UI:RefreshIfVisible()
    if mainFrame and mainFrame:IsShown() and not InCombatLockdown() then
        UI:Refresh()
    end
end

-- Pending frames to hide once combat lockdown lifts
UI.PendingHides = UI.PendingHides or {}

function UI:OnPlayerRegenDisabled()
    -- Guardrail 1: Safely hide any open interactive frames before lockdown takes hold
    if mainFrame and mainFrame:IsShown() then
        mainFrame:Hide()
    end
    if UI.AlertsDialog and UI.AlertsDialog:IsShown() then
        UI.AlertsDialog:Hide()
    end
    if UI.SettingsDialog and UI.SettingsDialog:IsShown() then
        UI.SettingsDialog:Hide()
    end
    if UI.KOSDialog and UI.KOSDialog:IsShown() then
        UI.KOSDialog:Hide()
    end
    if UI.DeathBountyDialog and UI.DeathBountyDialog:IsShown() then
        UI.DeathBountyDialog:Hide()
    end
    if UI.BountyDialog and UI.BountyDialog:IsShown() then
        UI.BountyDialog:Hide()
    end
    if UI.WebProfileDialog and UI.WebProfileDialog:IsShown() then
        UI.WebProfileDialog:Hide()
    end
    if UI.ReinforcementDialog and UI.ReinforcementDialog:IsShown() then
        UI.ReinforcementDialog:Hide()
    end
    if UI.ExportDialog and UI.ExportDialog:IsShown() then
        UI.ExportDialog:Hide()
    end
    if UI.RallyDialog and UI.RallyDialog:IsShown() then
        UI.RallyDialog:Hide()
    end
    if UI.PrivateTooltipFrame and UI.PrivateTooltipFrame:IsShown() then
        UI.PrivateTooltipFrame:Hide()
    end
    -- Make HUD click-through during active combat so targeting is never obstructed
    if UI.RadarHUD then
        UI.RadarHUD:EnableMouse(false)
        if UI.RadarHUD.header then UI.RadarHUD.header:EnableMouse(false) end
    end
    if UI.CombatWireHUD then
        UI.CombatWireHUD:EnableMouse(false)
        if UI.CombatWireHUD.header then UI.CombatWireHUD.header:EnableMouse(false) end
    end
    if UI.KillBanner then
        UI.KillBanner:EnableMouse(false)
    end
end

function UI:OnPlayerRegenEnabled()
    -- Guardrail 1: Process deferred hides for frames whose timers expired during combat
    if UI.PendingHides and #UI.PendingHides > 0 then
        for _, f in ipairs(UI.PendingHides) do
            if f then
                if f.Hide then f:Hide() end
                if f.SetAlpha then f:SetAlpha(1.0) end
            end
        end
        UI.PendingHides = {}
    end
    -- Restore mouse interaction on HUD out of combat
    if UI.RadarHUD and not InCombatLockdown() then
        UI.RadarHUD:EnableMouse(true)
        if UI.RadarHUD.header then UI.RadarHUD.header:EnableMouse(true) end
    end
    if UI.CombatWireHUD and not InCombatLockdown() then
        UI.CombatWireHUD:EnableMouse(true)
        if UI.CombatWireHUD.header then UI.CombatWireHUD.header:EnableMouse(true) end
    end
    if UI.KillBanner and not InCombatLockdown() then
        UI.KillBanner:EnableMouse(UI.bannerUnlocked or false)
    end
    -- Flush pending combat wire entries outside combat lockdown
    if UI.PendingWireEntries and #UI.PendingWireEntries > 0 and not InCombatLockdown() then
        if not combatWireHUD then UI:InitializeCombatWire() end
        if combatWireHUD and combatWireHUD.msgFrame then
            for _, line in ipairs(UI.PendingWireEntries) do
                combatWireHUD.msgFrame:AddMessage(line)
            end
            local s = WoWKillboardSettings or KB.DefaultSettings
            if (not s or s.showCombatWire ~= false) and not combatWireHUD:IsShown() then
                combatWireHUD:Show()
            end
        end
        UI.PendingWireEntries = {}
    end
    -- Deliver pending death bounty prompt outside combat lockdown
    if UI.PendingDeathBountyKiller and not InCombatLockdown() then
        local k = UI.PendingDeathBountyKiller
        UI.PendingDeathBountyKiller = nil
        UI:ShowDeathBountyPrompt(k)
    end
end

-- Dedicated Private Tooltip (100% Taint-Free, Zero GameTooltip Touching, Anonymous Frame)
function UI:GetOrCreatePrivateTooltip()
    if UI.PrivateTooltipFrame then return UI.PrivateTooltipFrame end
    local tip = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    tip:SetSize(280, 60)
    tip:SetFrameStrata("TOOLTIP")
    tip:SetFrameLevel(200)
    tip:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 },
    })
    if UI.GetCurrentThemeName and UI:GetCurrentThemeName() == "elvui" then
        tip:SetBackdropColor(18/255, 18/255, 18/255, 0.98)
        tip:SetBackdropBorderColor(0, 0, 0, 1.0)
    else
        tip:SetBackdropColor(0.04, 0.05, 0.08, 0.96)
        tip:SetBackdropBorderColor(0.85, 0.65, 0.20, 0.90)
    end
    tip:EnableMouse(false)
    tip:Hide()

    local title = tip:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    title:SetPoint("TOPLEFT", 8, -6)
    title:SetPoint("TOPRIGHT", -8, -6)
    title:SetJustifyH("LEFT")
    tip.Title = title

    local desc = tip:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    desc:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -3)
    desc:SetPoint("RIGHT", -8, 0)
    desc:SetJustifyH("LEFT")
    desc:SetWordWrap(true)
    tip.Desc = desc

    UI.PrivateTooltipFrame = tip
    return tip
end

function UI:ShowPrivateTooltip(owner, point, relPoint, x, y, titleText, descText)
    if InCombatLockdown() then return end
    local tip = UI:GetOrCreatePrivateTooltip()
    if not tip then return end
    tip:ClearAllPoints()
    tip:SetPoint(point or "BOTTOM", owner, relPoint or "TOP", x or 0, y or 4)
    tip.Title:SetText(titleText or "")
    tip.Desc:SetText(descText or "")
    local descH = tip.Desc:GetStringHeight() or 14
    tip:SetHeight(math.max(48, 22 + descH))
    tip:Show()
end

function UI:HidePrivateTooltip()
    if UI.PrivateTooltipFrame then
        UI.PrivateTooltipFrame:Hide()
    end
end

-- Construct the main frame
function UI:CreateMainWindow()
    if mainFrame then return end

    -- Anonymous frame to prevent Blizzard AccountData UI_LAYOUT tracking
    mainFrame = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    mainFrame:SetSize(960, 660)
    mainFrame:SetPoint("CENTER")
    mainFrame:SetMovable(true)
    mainFrame:EnableMouse(true)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", function(self)
        if not InCombatLockdown() then
            self:StartMoving()
        end
    end)
    mainFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)
    mainFrame:SetClampedToScreen(true)

    -- Custom ESC key handling (100% taint-free, active strictly when shown)
    mainFrame:EnableKeyboard(false)
    mainFrame:SetScript("OnShow", function(self)
        if self.EnableKeyboard then self:EnableKeyboard(true) end
        if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        UI:UpdatePortrait()
    end)
    mainFrame:SetScript("OnHide", function(self)
        if self.EnableKeyboard then self:EnableKeyboard(false) end
        if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
    end)
    mainFrame:SetScript("OnKeyDown", function(self, key)
        if not self:IsShown() then
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            return
        end
        if key == "ESCAPE" then
            if UI.DetailModal and UI.DetailModal:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                UI.DetailModal:Hide()
                return
            end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
            self:Hide()
        else
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end
    end)

    -- Opaque Base Layer (Active in ElvUI, Hidden in Classic to expose Blizzard Stone)
    local initTheme = UI:GetTheme()
    local solidBg = mainFrame:CreateTexture(nil, "BACKGROUND", nil, -8)
    solidBg:SetAllPoints(mainFrame)
    if initTheme.id == "classic" then
        solidBg:Hide()
    else
        solidBg:SetColorTexture(unpack(initTheme.solidBg or initTheme.mainBg or {0.045, 0.055, 0.08, 1.0}))
        solidBg:Show()
    end
    UI.SolidBg = solidBg

    -- Frame Backdrop from Active Theme (Blizzard Stone Dialog or ElvUI Minimalist)
    mainFrame:SetBackdrop(initTheme.mainBackdrop)
    mainFrame:SetBackdropColor(unpack(initTheme.mainBg or {1.0, 1.0, 1.0, 1.0}))
    mainFrame:SetBackdropBorderColor(unpack(initTheme.mainBorder or {1.0, 1.0, 1.0, 1.0}))

    -- 1. Integrated Character Portrait Medallion (48x48, anchored (12, -4), Strata HIGH)
    local portraitFrame = CreateFrame("Frame", "WoWKillboardPlayerPortrait", mainFrame, "BackdropTemplate")
    portraitFrame:SetSize(48, 48)
    portraitFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 12, -4)
    portraitFrame:SetFrameStrata("HIGH")

    local portraitTex = portraitFrame:CreateTexture(nil, "BACKGROUND")
    portraitTex:SetAllPoints(portraitFrame)
    if SetPortraitTexture then
        SetPortraitTexture(portraitTex, "player")
        if not portraitTex:GetTexture() then
            portraitTex:SetTexture("Interface\\Icons\\Achievement_PVP_P_01")
        end
    end

    if portraitFrame.CreateMaskTexture and portraitTex.AddMaskTexture then
        local mask = portraitFrame:CreateMaskTexture()
        mask:SetAllPoints(portraitTex)
        mask:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        portraitTex:AddMaskTexture(mask)
        portraitFrame.mask = mask
    end
    portraitFrame.portraitTex = portraitTex

    -- Gold Border Ring (60x60 centered proportionally over the portrait)
    local border = portraitFrame:CreateTexture(nil, "OVERLAY")
    border:SetPoint("CENTER", portraitFrame, "CENTER", 0, 0)
    border:SetSize(60, 60)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    portraitFrame.border = border
    portraitFrame.ring = border

    -- Circular Level Medallion (20x20, anchored BOTTOMRIGHT (2, -2), Strata HIGH)
    local levelFrame = CreateFrame("Frame", nil, portraitFrame)
    local levelBadge = levelFrame
    levelBadge:SetSize(20, 20)
    levelBadge:SetPoint("BOTTOMRIGHT", portraitFrame, "BOTTOMRIGHT", 2, -2)
    levelBadge:SetFrameStrata("HIGH")
    levelBadge:SetFrameLevel(portraitFrame:GetFrameLevel() + 5)

    local levelBg = levelFrame:CreateTexture(nil, "BACKGROUND")
    levelBg:SetAllPoints(levelFrame)
    levelBg:SetColorTexture(0.04, 0.05, 0.08, 0.95)
    if levelFrame.CreateMaskTexture and levelBg.AddMaskTexture then
        local mask = levelFrame:CreateMaskTexture()
        mask:SetAllPoints(levelBg)
        mask:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        levelBg:AddMaskTexture(mask)
        levelFrame.mask = mask
    end
    levelFrame.bg = levelBg

    local levelBorder = levelFrame:CreateTexture(nil, "OVERLAY")
    levelBorder:SetPoint("CENTER", levelFrame, "CENTER", 0, 0)
    levelBorder:SetSize(28, 28)
    levelBorder:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    levelBorder:SetVertexColor(0.85, 0.70, 0.25, 1.0) -- Gold accent
    levelFrame.border = levelBorder

    local levelText = levelFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    levelText:SetPoint("CENTER", levelFrame, "CENTER", 0, 0)
    levelText:SetTextColor(1.0, 0.85, 0.0, 1.0) -- Bright Blizzard Gold
    if levelText.SetFont then
        local f, s = levelText:GetFont()
        levelText:SetFont(f, (s or 10), "OUTLINE,THICK")
    end
    levelText:SetShadowOffset(0, 0)
    levelText:SetText(tostring((UnitLevel and UnitLevel("player")) or 1))
    levelFrame.text = levelText
    portraitFrame.levelBadge = levelFrame

    portraitFrame:RegisterEvent("UNIT_PORTRAIT_UPDATE")
    portraitFrame:RegisterEvent("UNIT_LEVEL")
    portraitFrame:RegisterEvent("PLAYER_LEVEL_UP")
    portraitFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    portraitFrame:RegisterEvent("PLAYER_XP_UPDATE")
    portraitFrame:RegisterEvent("PLAYER_ALIVE")
    portraitFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    portraitFrame:SetScript("OnEvent", function(self, event, unit)
        if (event == "UNIT_PORTRAIT_UPDATE" or event == "UNIT_LEVEL") and unit and unit ~= "player" then
            return
        end
        UI:UpdatePortrait()
    end)

    UI.PlayerPortrait = portraitFrame
    UI.LevelBadge = levelText
    UI.Medallion = {
        Portrait = portraitTex,
        LevelBadge = levelText,
        Frame = portraitFrame,
    }

    -- 2. Header & Top Control Bar (Height 42px, Solid #1A1A1A, 1px solid black bottom divider)
    local headerBar = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    headerBar:SetSize(960, 42)
    headerBar:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 0, 0)
    headerBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    headerBar:SetBackdropColor(18/255, 22/255, 30/255, 1.0)
    headerBar:SetBackdropBorderColor(0, 0, 0, 1.0)
    UI.HeaderBar = headerBar

    -- 1px bottom divider
    local headerDiv = headerBar:CreateTexture(nil, "OVERLAY")
    headerDiv:SetHeight(1)
    headerDiv:SetPoint("BOTTOMLEFT", headerBar, "BOTTOMLEFT", 0, 0)
    headerDiv:SetPoint("BOTTOMRIGHT", headerBar, "BOTTOMRIGHT", 0, 0)
    headerDiv:SetColorTexture(40/255, 50/255, 65/255, 0.8)
    headerBar.Divider = headerDiv

    -- Addon Title (Shifted to 74px to cleanly clear the 60px circular gold portrait ring with 8px margin)
    local title = headerBar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("LEFT", headerBar, "LEFT", 74, 0)
    title:SetTextColor(1.0, 0.82, 0.0, 1.0)
    title:SetText("WoW Killboard")
    if title.SetFont then local f, s = title:GetFont(); title:SetFont(f, (s or 12) + 1, "OUTLINE") end
    title:SetShadowOffset(0, 0)
    UI.TitleText = title

    -- Version Tag
    local verTag = headerBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    verTag:SetPoint("LEFT", title, "RIGHT", 6, 0)
    verTag:SetTextColor(102/255, 102/255, 102/255, 1.0)
    verTag:SetText(string.format("v%s", KB.Version or "1.0.5"))
    if verTag.SetFont then local f, s = verTag:GetFont(); verTag:SetFont(f, s or 10, "OUTLINE") end
    verTag:SetShadowOffset(0, 0)
    UI.VersionText = verTag

    -- Active Realm Display Badge
    local realmBadge = CreateFrame("Frame", nil, headerBar, "BackdropTemplate")
    realmBadge:SetSize(130, 22)
    realmBadge:SetPoint("LEFT", verTag, "RIGHT", 10, 0)
    realmBadge:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    realmBadge:SetBackdropColor(24/255, 32/255, 44/255, 0.9)
    realmBadge:SetBackdropBorderColor(56/255, 189/255, 248/255, 0.4)
    local realmTag = realmBadge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    realmTag:SetPoint("CENTER", 0, 0)
    realmTag:SetTextColor(56/255, 189/255, 248/255, 1.0)
    local rName = (GetRealmName and GetRealmName()) or "Classic Beta PvP"
    realmTag:SetText(rName)
    if realmTag.SetFont then local f, s = realmTag:GetFont(); realmTag:SetFont(f, s or 9, "OUTLINE") end
    realmTag:SetShadowOffset(0, 0)
    realmBadge.Label = realmTag
    UI.RealmBadge = realmTag

    -- Right Controls: Close (X), Settings, Sync
    local closeBtn = CreateFrame("Button", nil, headerBar, "BackdropTemplate")
    closeBtn:SetSize(22, 22)
    closeBtn:SetPoint("RIGHT", headerBar, "RIGHT", -10, 0)
    closeBtn:EnableMouse(true)
    closeBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    closeBtn:SetBackdropColor(30/255, 30/255, 30/255, 1.0)
    closeBtn:SetBackdropBorderColor(0, 0, 0, 1.0)
    local closeLabel = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    closeLabel:SetPoint("CENTER", 0, 0)
    closeLabel:SetTextColor(255/255, 56/255, 56/255, 1.0)
    closeLabel:SetText("X")
    if closeLabel.SetFont then local f, s = closeLabel:GetFont(); closeLabel:SetFont(f, s or 10, "OUTLINE") end
    closeLabel:SetShadowOffset(0, 0)
    closeBtn.Label = closeLabel
    closeBtn:SetScript("OnEnter", function(self) self:SetBackdropColor(42/255, 42/255, 42/255, 1.0) end)
    closeBtn:SetScript("OnLeave", function(self) self:SetBackdropColor(30/255, 30/255, 30/255, 1.0) end)
    closeBtn:SetScript("OnClick", function() mainFrame:Hide() end)
    UI.CloseButton = closeBtn

    local settingsBtn = CreateFrame("Button", nil, headerBar, "BackdropTemplate")
    settingsBtn:SetSize(54, 22)
    settingsBtn:SetPoint("RIGHT", closeBtn, "LEFT", -6, 0)
    settingsBtn:EnableMouse(true)
    settingsBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    settingsBtn:SetBackdropColor(26/255, 32/255, 42/255, 1.0)
    settingsBtn:SetBackdropBorderColor(50/255, 60/255, 75/255, 0.8)
    local settingsLabel = settingsBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    settingsLabel:SetPoint("CENTER", 0, 0)
    settingsLabel:SetTextColor(204/255, 204/255, 204/255, 1.0)
    settingsLabel:SetText("Settings")
    if settingsLabel.SetFont then local f, s = settingsLabel:GetFont(); settingsLabel:SetFont(f, s or 10, "OUTLINE") end
    settingsLabel:SetShadowOffset(0, 0)
    settingsBtn.Label = settingsLabel
    settingsBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(36/255, 44/255, 58/255, 1.0)
        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Settings & Preferences|r", "Configure Theme, Alert Banners, Sound, Mute Death Marks, Combat Feed & Data Export.")
    end)
    settingsBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(26/255, 32/255, 42/255, 1.0)
        UI:HidePrivateTooltip()
    end)
    settingsBtn:SetScript("OnClick", function() UI:ShowSettingsModal() end)
    UI.SettingsButton = settingsBtn

    local syncBtn = CreateFrame("Button", nil, headerBar, "BackdropTemplate")
    syncBtn:SetSize(46, 22)
    syncBtn:SetPoint("RIGHT", settingsBtn, "LEFT", -6, 0)
    syncBtn:EnableMouse(true)
    syncBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    syncBtn:SetBackdropColor(26/255, 32/255, 42/255, 1.0)
    syncBtn:SetBackdropBorderColor(16/255, 185/255, 129/255, 0.6)
    local syncLabel = syncBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    syncLabel:SetPoint("CENTER", 0, 0)
    syncLabel:SetTextColor(16/255, 185/255, 129/255, 1.0)
    syncLabel:SetText("Sync")
    if syncLabel.SetFont then local f, s = syncLabel:GetFont(); syncLabel:SetFont(f, s or 10, "OUTLINE") end
    syncLabel:SetShadowOffset(0, 0)
    syncBtn.Label = syncLabel
    syncBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(36/255, 44/255, 58/255, 1.0)
        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cff10b981Save & Sync Kills|r", "Flushes all in-memory combat records to SavedVariables on disk via /reload.")
    end)
    syncBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(26/255, 32/255, 42/255, 1.0)
        UI:HidePrivateTooltip()
    end)
    syncBtn:SetScript("OnClick", function()
        if InCombatLockdown and InCombatLockdown() then return end
        WoWKillboardDB = WoWKillboardDB or {}
        WoWKillboardDB.lastManualSync = time()
        ReloadUI()
    end)
    UI.SyncButton = syncBtn

    -- Mode Switcher Segmented Toggle: [ ⚔ PvP Combat ] and [ 💀 PvE Hazards ]
    local modeBar = CreateFrame("Frame", nil, headerBar, "BackdropTemplate")
    modeBar:SetSize(224, 24)
    modeBar:SetPoint("RIGHT", syncBtn, "LEFT", -10, 0)
    modeBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    modeBar:SetBackdropColor(14/255, 18/255, 24/255, 1.0)
    modeBar:SetBackdropBorderColor(40/255, 50/255, 65/255, 0.7)

    -- [PVP STATS] mode toggle button
    local pvpBtn = CreateFrame("Button", nil, modeBar, "BackdropTemplate")
    pvpBtn:SetSize(110, 20)
    pvpBtn:SetPoint("LEFT", modeBar, "LEFT", 2, 0)
    pvpBtn:EnableMouse(true)
    pvpBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    local pvpLabel = pvpBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    pvpLabel:SetPoint("CENTER", 0, 0)
    pvpLabel:SetText("⚔ PvP Combat")
    if pvpLabel.SetFont then local f, s = pvpLabel:GetFont(); pvpLabel:SetFont(f, s or 10, "OUTLINE") end
    pvpBtn.Label = pvpLabel

    -- [PVE STATS] mode toggle button
    local pveBtn = CreateFrame("Button", nil, modeBar, "BackdropTemplate")
    pveBtn:SetSize(110, 20)
    pveBtn:SetPoint("RIGHT", modeBar, "RIGHT", -2, 0)
    pveBtn:EnableMouse(true)
    pveBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    local pveLabel = pveBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    pveLabel:SetPoint("CENTER", 0, 0)
    pveLabel:SetText("💀 PvE Hazards")
    if pveLabel.SetFont then local f, s = pveLabel:GetFont(); pveLabel:SetFont(f, s or 10, "OUTLINE") end
    pveBtn.Label = pveLabel

    function UI:UpdateRulesetButton()
        local isPve = UI:IsPve()
        local aR, aG, aB, aHex = WoWKB.AccentColor()
        if isPve then
            pveBtn:SetBackdropColor(20/255, 45/255, 30/255, 1.0)
            pveBtn:SetBackdropBorderColor(16/255, 185/255, 129/255, 0.9)
            pveBtn.Label:SetTextColor(16/255, 185/255, 129/255, 1.0)

            pvpBtn:SetBackdropColor(18/255, 22/255, 28/255, 0.6)
            pvpBtn:SetBackdropBorderColor(35/255, 45/255, 55/255, 0.5)
            pvpBtn.Label:SetTextColor(119/255, 119/255, 119/255, 1.0)
        else
            pvpBtn:SetBackdropColor(45/255, 20/255, 20/255, 1.0)
            pvpBtn:SetBackdropBorderColor(239/255, 68/255, 68/255, 0.9)
            pvpBtn.Label:SetTextColor(239/255, 68/255, 68/255, 1.0)

            pveBtn:SetBackdropColor(18/255, 22/255, 28/255, 0.6)
            pveBtn:SetBackdropBorderColor(35/255, 45/255, 55/255, 0.5)
            pveBtn.Label:SetTextColor(119/255, 119/255, 119/255, 1.0)
        end

        if UI.RealmBadge then
            local realm = (GetRealmName and GetRealmName()) or "Classic Beta PvP"
            if UI.RealmBadge.SetText then
                UI.RealmBadge:SetText(realm)
            elseif UI.RealmBadge.Label then
                UI.RealmBadge.Label:SetText(realm)
            end
        end

        if UI.TitleText then
            UI.TitleText:SetTextColor(aR, aG, aB, 1.0)
        end
    end

    pvpBtn:SetScript("OnClick", function()
        if UI:IsPve() then
            WoWKillboardDB = WoWKillboardDB or {}
            local realm = (GetRealmName and GetRealmName()) or ""
            WoWKillboardDB.realmRulesets = WoWKillboardDB.realmRulesets or {}
            if realm ~= "" then WoWKillboardDB.realmRulesets[realm] = "PVP" end
            WoWKillboardDB.campaignRuleset = "PVP"
            if KB.Leaderboard and KB.Leaderboard.Rebuild then KB.Leaderboard:Rebuild() end
            UI:UpdateRulesetButton()
            UI:Refresh()
        end
    end)
    pvpBtn:SetScript("OnEnter", function(self)
        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffef4444Contested PvP Combat|r", "View player-versus-player combat ledger, bounties, and rankings.")
    end)
    pvpBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)

    pveBtn:SetScript("OnClick", function()
        if not UI:IsPve() then
            WoWKillboardDB = WoWKillboardDB or {}
            local realm = (GetRealmName and GetRealmName()) or ""
            WoWKillboardDB.realmRulesets = WoWKillboardDB.realmRulesets or {}
            if realm ~= "" then WoWKillboardDB.realmRulesets[realm] = "PVE" end
            WoWKillboardDB.campaignRuleset = "PVE"
            if KB.Leaderboard and KB.Leaderboard.Rebuild then KB.Leaderboard:Rebuild() end
            UI:UpdateRulesetButton()
            UI:Refresh()
        end
    end)
    pveBtn:SetScript("OnEnter", function(self)
        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cff10b981Wilderness PvE Hazards|r", "View monster executions, environmental hazards, and mortality bestiary.")
    end)
    pveBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)

    UI.RulesetButton = modeBar
    UI.PvpModeBtn = pvpBtn
    UI.PveModeBtn = pveBtn
    UI:UpdateRulesetButton()

    -- Real-Time Tactical Search Input Box
    local searchBox = CreateFrame("Frame", nil, headerBar, "BackdropTemplate")
    searchBox:SetSize(150, 22)
    searchBox:SetPoint("RIGHT", modeBar, "LEFT", -10, 0)
    searchBox:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 },
    })
    searchBox:SetBackdropColor(18/255, 22/255, 30/255, 1.0)
    searchBox:SetBackdropBorderColor(50/255, 60/255, 75/255, 0.8)
    UI.SearchBox = searchBox

    local searchIcon = searchBox:CreateTexture(nil, "ARTWORK")
    searchIcon:SetSize(12, 12)
    searchIcon:SetPoint("LEFT", 4, 0)
    searchIcon:SetTexture("Interface\\Common\\UI-Searchbox-Icon")
    searchIcon:SetVertexColor(0.85, 0.75, 0.50, 0.8)
    searchBox.Icon = searchIcon

    local eb = CreateFrame("EditBox", nil, searchBox)
    eb:SetPoint("LEFT", searchIcon, "RIGHT", 3, 0)
    eb:SetPoint("RIGHT", searchBox, "RIGHT", -16, 0)
    eb:SetHeight(18)
    eb:SetFontObject("GameFontHighlightSmall")
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(30)
    searchBox.EditBox = eb

    local placeholder = searchBox:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    placeholder:SetPoint("LEFT", searchIcon, "RIGHT", 4, 0)
    placeholder:SetText("|cff777777Q Search...|r")
    searchBox.Placeholder = placeholder

    local clearBtn = CreateFrame("Button", nil, searchBox)
    clearBtn:SetSize(14, 14)
    clearBtn:SetPoint("RIGHT", -3, 0)
    clearBtn:Hide()
    local clearLabel = clearBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    clearLabel:SetPoint("CENTER", 0, 0)
    clearLabel:SetText("|cff999999x|r")
    clearBtn.Label = clearLabel
    searchBox.ClearBtn = clearBtn

    clearBtn:SetScript("OnClick", function()
        eb:SetText("")
        eb:ClearFocus()
        UI.activeSearchQuery = nil
        clearBtn:Hide()
        placeholder:Show()
        UI:Refresh()
    end)

    eb:SetScript("OnEditFocusGained", function(self)
        placeholder:Hide()
        searchBox:SetBackdropBorderColor(1.0, 0.82, 0.0, 1.0)
    end)
    eb:SetScript("OnEditFocusLost", function(self)
        local text = self:GetText()
        if not text or text:match("^%s*$") then
            placeholder:Show()
            clearBtn:Hide()
        else
            clearBtn:Show()
        end
        searchBox:SetBackdropBorderColor(50/255, 60/255, 75/255, 0.8)
    end)
    eb:SetScript("OnTextChanged", function(self, isUserInput)
        local raw = self:GetText() or ""
        local clean = raw:match("^%s*(.-)%s*$")
        if clean and clean ~= "" then
            placeholder:Hide()
            clearBtn:Show()
            UI.activeSearchQuery = clean:lower()
        else
            if not self:HasFocus() then placeholder:Show() end
            clearBtn:Hide()
            UI.activeSearchQuery = nil
        end
        if isUserInput then
            UI:Refresh()
        end
    end)
    eb:SetScript("OnEscapePressed", function(self)
        self:SetText("")
        self:ClearFocus()
        UI.activeSearchQuery = nil
        clearBtn:Hide()
        placeholder:Show()
        UI:Refresh()
    end)
    eb:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)

    -- 3. Telemetry Ribbon Strip (28px height horizontal stats bar directly under header)
    local metricsBar = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    metricsBar:SetSize(940, 28)
    metricsBar:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -44)
    metricsBar:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -10, -44)
    metricsBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    metricsBar:SetBackdropColor(0.025, 0.035, 0.055, 1.0)
    metricsBar:SetBackdropBorderColor(0.58, 0.45, 0.22, 0.4)
    UI.TopMetricsBar = metricsBar

    -- Faction War Split Visual Progress Bar (Telemetry Strip: 140px x 12px)
    local splitBar = CreateFrame("Frame", nil, metricsBar, "BackdropTemplate")
    splitBar:SetSize(140, 12)
    splitBar:SetPoint("RIGHT", metricsBar, "RIGHT", -12, 0)
    splitBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    splitBar:SetBackdropColor(0.04, 0.05, 0.08, 0.95)
    splitBar:SetBackdropBorderColor(0.12, 0.16, 0.23, 1.0)
    UI.FactionSplitBar = splitBar

    local splitBarLabel = metricsBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    splitBarLabel:SetPoint("RIGHT", splitBar, "LEFT", -8, 0)
    splitBarLabel:SetTextColor(136/255, 136/255, 136/255, 1.0)
    splitBarLabel:SetText("|cff888888WAR SPLIT:|r")
    if splitBarLabel.SetFont then local f, s = splitBarLabel:GetFont(); splitBarLabel:SetFont(f, s or 10, "OUTLINE") end
    splitBarLabel:SetShadowOffset(0, 0)
    UI.FactionSplitLabel = splitBarLabel

    -- Left Fill (Alliance %): Solid Royal Blue (0.08, 0.35, 0.85, 1.0)
    local allyFill = splitBar:CreateTexture(nil, "ARTWORK")
    allyFill:SetPoint("TOPLEFT", splitBar, "TOPLEFT", 1, -1)
    allyFill:SetPoint("BOTTOMLEFT", splitBar, "BOTTOMLEFT", 1, 1)
    allyFill:SetWidth(69)
    allyFill:SetColorTexture(0.08, 0.35, 0.85, 1.0)
    splitBar.AllianceFill = allyFill

    -- Right Fill (Horde %): Solid Crimson Red (0.85, 0.12, 0.12, 1.0)
    local hordeFill = splitBar:CreateTexture(nil, "ARTWORK")
    hordeFill:SetPoint("TOPRIGHT", splitBar, "TOPRIGHT", -1, -1)
    hordeFill:SetPoint("BOTTOMRIGHT", splitBar, "BOTTOMRIGHT", -1, 1)
    hordeFill:SetPoint("LEFT", allyFill, "RIGHT", 0, 0)
    hordeFill:SetColorTexture(0.85, 0.12, 0.12, 1.0)
    splitBar.HordeFill = hordeFill

    -- Centered text: "57% A | 43% H" in white bold font with a drop shadow
    local splitText = splitBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    splitText:SetPoint("CENTER", splitBar, "CENTER", 0, 0)
    splitText:SetTextColor(1.0, 1.0, 1.0, 1.0)
    if splitText.SetFont then
        local f, s = splitText:GetFont()
        splitText:SetFont(f, (s or 9), "OUTLINE,THICK")
    end
    splitText:SetShadowColor(0, 0, 0, 1.0)
    splitText:SetShadowOffset(1, -1)
    splitText:SetText("50% A | 50% H")
    splitBar.Text = splitText

    local ribbonText = metricsBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ribbonText:SetPoint("LEFT", metricsBar, "LEFT", 70, 0)
    ribbonText:SetPoint("RIGHT", splitBarLabel, "LEFT", -8, 0)
    ribbonText:SetJustifyH("LEFT")
    ribbonText:SetTextColor(1.0, 1.0, 1.0, 1.0)
    if ribbonText.SetFont then local f, s = ribbonText:GetFont(); ribbonText:SetFont(f, (s or 10), "OUTLINE") end
    ribbonText:SetShadowOffset(0, 0)
    ribbonText:SetText("|cff888888REALM:|r |cffffffff0|r  |cff444444|  |cff88888824H:|r |cffffffff0|r  |cff444444|  |cff888888PVE CASUALTIES:|r |cffff80000|r  |cff444444|  |cff888888HOT ZONE:|r |cffffd200Scanning...|r")
    UI.TelemetryText = ribbonText

    -- 4. Nav Tabs Bar (30px height) - Exactly 5 clean tabs
    local tabs = {
        { id = "FEED",        text = "Intel",         w = 64 },
        { id = "LEADERBOARD", text = "Leaderboards",  w = 98 },
        { id = "BOUNTIES",    text = "The Marked",    w = 86 },
        { id = "RALLIES",     text = "Call to Arms",  w = 90 },
        { id = "ZONES",       text = "Danger Zones",  w = 92 },
    }

    tabButtons = {}
    local prevTab = nil
    for _, t in ipairs(tabs) do
        local btn = UI:CreateButton(mainFrame, t.w, 24, t.text, "GameFontHighlightSmall")
        if not prevTab then
            btn:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -74)
        else
            btn:SetPoint("LEFT", prevTab, "RIGHT", 4, 0)
        end
        local tabId = t.id
        btn:SetScript("OnClick", function()
            activeTab = tabId
            UI:Refresh()
        end)

        -- 2px Solid Bright Gold Bottom Line Accent for Web 1:1 Parity
        local bottomAccent = btn:CreateTexture(nil, "OVERLAY")
        bottomAccent:SetHeight(2)
        bottomAccent:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0)
        bottomAccent:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 0, 0)
        bottomAccent:SetColorTexture(0.85, 0.70, 0.25, 1.0)
        bottomAccent:Hide()
        btn.bottomAccent = bottomAccent

        tabButtons[t.id] = btn
        prevTab = btn
    end

    -- Mode Filter Pills on right of Nav Bar: [ World ] [ BGs ] [ Duels ] [ Arenas ]
    -- Ordered right-to-left so they display left-to-right: [ World ] [ BGs ] [ Duels ] [ Arenas ]
    local filterConfigs = {
        { id = "ARENA", text = "Arenas", w = 64, tooltip = "Rated & Skirmish Arena Engagements" },
        { id = "DUEL",  text = "Duels",  w = 58, tooltip = "Sanctioned 1v1 Duel Mortalities" },
        { id = "BG",    text = "BGs",    w = 54, tooltip = "Battleground Engagements (Warsong, Arathi, Alterac)" },
        { id = "WORLD", text = "World",  w = 62, tooltip = "Open World Contested Zone Combat" },
    }

    filterButtons = {}
    local prevPill = nil
    for _, f in ipairs(filterConfigs) do
        local pill = CreateWebPillButton(mainFrame, f.text, f.w, 22)
        if not prevPill then
            pill:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -10, -75)
        else
            pill:SetPoint("RIGHT", prevPill, "LEFT", -4, 0)
        end
        pill.tooltipText = f.tooltip
        local filterId = f.id
        pill:SetScript("OnClick", function()
            WoWKillboardDB = WoWKillboardDB or {}
            WoWKillboardDB.combatFilter = filterId
            if WoWKillboardSettings then WoWKillboardSettings.combatFilter = filterId end
            currentMode = filterId
            UI:Refresh()
        end)
        filterButtons[f.id] = pill
        prevPill = pill
    end

    -- 5. Dual-Column Frame Layout
    -- Left: MainContainer (~70% width = 646px)
    local mainContainer = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    mainContainer:SetSize(646, 544)
    mainContainer:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -104)
    mainContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    mainContainer:SetBackdropColor(0.043, 0.059, 0.090, 0.95)
    mainContainer:SetBackdropBorderColor(0.12, 0.16, 0.23, 1.0)
    UI.MainContainer = mainContainer
    UI.ContentInset = mainContainer

    local bgArt = mainContainer:CreateTexture(nil, "BACKGROUND", nil, -5)
    bgArt:SetAllPoints(mainContainer)
    bgArt:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\dark_war_bg.tga")
    bgArt:SetTexCoord(0, 1, 0, 1)
    bgArt:SetAlpha(0.65)
    mainContainer.BgArt = bgArt

    local vignette = mainContainer:CreateTexture(nil, "BACKGROUND", nil, -4)
    vignette:SetAllPoints(mainContainer)
    vignette:SetColorTexture(0.015, 0.02, 0.035, 0.40)
    mainContainer.Vignette = vignette

    local container = CreateFrame("ScrollFrame", nil, mainContainer)
    container:SetPoint("TOPLEFT", mainContainer, "TOPLEFT", 6, -6)
    container:SetPoint("BOTTOMRIGHT", mainContainer, "BOTTOMRIGHT", -18, 6)
    container:EnableMouseWheel(true)

    local content = CreateFrame("Frame", nil, container)
    content:SetSize(620, 532)
    container:SetScrollChild(content)
    UI.ContentFrame = content
    UI.ScrollContainer = container

    local scrollBar = CreateFrame("Slider", nil, mainContainer, "BackdropTemplate")
    scrollBar:SetPoint("TOPRIGHT", mainContainer, "TOPRIGHT", -5, -8)
    scrollBar:SetPoint("BOTTOMRIGHT", mainContainer, "BOTTOMRIGHT", -5, 8)
    scrollBar:SetWidth(10)
    scrollBar:SetOrientation("VERTICAL")
    scrollBar:SetMinMaxValues(0, 100)
    scrollBar:SetValue(0)
    scrollBar:SetValueStep(1)
    scrollBar:EnableMouse(true)
    scrollBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 },
    })

    local thumb = scrollBar:CreateTexture(nil, "OVERLAY")
    thumb:SetSize(10, 36)
    thumb:SetColorTexture(0.70, 0.55, 0.22, 0.95)
    scrollBar:SetThumbTexture(thumb)
    scrollBar.Thumb = thumb
    UI.ScrollBar = scrollBar

    scrollBar:SetScript("OnValueChanged", function(self, value)
        container:SetVerticalScroll(value)
    end)
    container:SetScript("OnMouseWheel", function(self, delta)
        local current = self:GetVerticalScroll()
        local maxScroll = math.max(0, (UI.ContentFrame:GetHeight() or 500) - self:GetHeight())
        local newScroll = math.max(0, math.min(maxScroll, current - (delta * 36)))
        self:SetVerticalScroll(newScroll)
        if scrollBar:IsShown() then
            scrollBar:SetValue(newScroll)
        end
    end)

    function UI:UpdateScrollbar()
        if not UI.ScrollContainer or not UI.ContentFrame or not UI.ScrollBar then return end
        local viewHeight = UI.ScrollContainer:GetHeight() or 500
        local contentHeight = UI.ContentFrame:GetHeight() or 500
        local maxScroll = math.max(0, contentHeight - viewHeight)
        if maxScroll > 4 then
            UI.ScrollBar:SetMinMaxValues(0, maxScroll)
            UI.ScrollBar:SetValue(math.min(UI.ScrollContainer:GetVerticalScroll() or 0, maxScroll))
            UI.ScrollBar:Show()
        else
            UI.ScrollBar:SetMinMaxValues(0, 0)
            UI.ScrollBar:SetValue(0)
            UI.ScrollBar:Hide()
        end
    end

    -- Right: SidebarContainer (~30% width = 284px)
    local sidebarContainer = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    sidebarContainer:SetSize(284, 544)
    sidebarContainer:SetPoint("TOPLEFT", mainContainer, "TOPRIGHT", 10, 0)
    sidebarContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    sidebarContainer:SetBackdropColor(0.015, 0.023, 0.035, 0.0)
    sidebarContainer:SetBackdropBorderColor(0.015, 0.023, 0.035, 0.0)
    UI.SidebarContainer = sidebarContainer

    -- Card 1: Lifetime Combat Activity (Height: 136px)
    local card1 = CreateFrame("Frame", nil, sidebarContainer, "BackdropTemplate")
    card1:SetPoint("TOPLEFT", sidebarContainer, "TOPLEFT", 6, -6)
    card1:SetPoint("TOPRIGHT", sidebarContainer, "TOPRIGHT", -6, -6)
    card1:SetHeight(136)
    card1:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    card1:SetBackdropColor(0.043, 0.059, 0.090, 0.95)
    card1:SetBackdropBorderColor(0.12, 0.16, 0.23, 1.0)

    local card1Title = card1:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    card1Title:SetPoint("TOPLEFT", 8, -6)
    card1Title:SetTextColor(0.78, 0.65, 0.35, 1.0)
    card1Title:SetText("LIFETIME COMBAT ACTIVITY")
    if card1Title.SetFont then local f, s = card1Title:GetFont(); card1Title:SetFont(f, s or 10, "OUTLINE") end
    card1.Title = card1Title

    local card1Div = card1:CreateTexture(nil, "OVERLAY")
    card1Div:SetPoint("TOPLEFT", 0, -22)
    card1Div:SetPoint("TOPRIGHT", 0, -22)
    card1Div:SetHeight(1)
    card1Div:SetColorTexture(0.58, 0.45, 0.22, 0.4)
    card1.HeaderDivider = card1Div

    local c1Line1 = card1:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    c1Line1:SetPoint("TOPLEFT", 8, -28)
    c1Line1:SetText("|cff888888Realm Kills:|r |cffffffff0|r")

    local c1Line2 = card1:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    c1Line2:SetPoint("TOPLEFT", 8, -48)
    c1Line2:SetText("|cff88888824H Activity:|r |cffffffff0|r")

    local c1Line3 = card1:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    c1Line3:SetPoint("TOPLEFT", 8, -68)
    c1Line3:SetText("|cff888888PvE Casualties:|r |cffffffff0|r")

    local c1Line4 = card1:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    c1Line4:SetPoint("TOPLEFT", 8, -88)
    c1Line4:SetText("|cff888888War Split:|r |cff0080ff50% A|r / |cffff202050% H|r")

    local c1Line5 = card1:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    c1Line5:SetPoint("TOPLEFT", 8, -108)
    c1Line5:SetText("|cff8888881v1 Solo Rate:|r |cff4ade800%|r")

    card1.Lines = { c1Line1, c1Line2, c1Line3, c1Line4, c1Line5 }

    -- Card 2: The Marked (Bounties) (Height: 210px)
    local card2 = CreateFrame("Frame", nil, sidebarContainer, "BackdropTemplate")
    card2:SetPoint("TOPLEFT", card1, "BOTTOMLEFT", 0, -6)
    card2:SetPoint("TOPRIGHT", card1, "BOTTOMRIGHT", 0, -6)
    card2:SetHeight(210)
    card2:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    card2:SetBackdropColor(0.043, 0.059, 0.090, 0.95)
    card2:SetBackdropBorderColor(0.12, 0.16, 0.23, 1.0)

    local card2Title = card2:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    card2Title:SetPoint("TOPLEFT", 8, -6)
    card2Title:SetTextColor(0.78, 0.65, 0.35, 1.0)
    card2Title:SetText("THE MARKED")
    if card2Title.SetFont then local f, s = card2Title:GetFont(); card2Title:SetFont(f, s or 10, "OUTLINE") end
    card2.Title = card2Title

    local card2Div = card2:CreateTexture(nil, "OVERLAY")
    card2Div:SetPoint("TOPLEFT", 0, -22)
    card2Div:SetPoint("TOPRIGHT", 0, -22)
    card2Div:SetHeight(1)
    card2Div:SetColorTexture(0.58, 0.45, 0.22, 0.4)
    card2.HeaderDivider = card2Div

    local bountyRows = {}
    for bIdx = 1, 3 do
        local bRow = CreateFrame("Frame", nil, card2, "BackdropTemplate")
        bRow:SetSize(260, 56)
        bRow:SetPoint("TOPLEFT", card2, "TOPLEFT", 6, -26 - ((bIdx - 1) * 60))
        bRow:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        bRow:SetBackdropColor(14/255, 18/255, 26/255, 0.9)
        bRow:SetBackdropBorderColor(35/255, 45/255, 58/255, 0.6)

        local bIcon = bRow:CreateTexture(nil, "ARTWORK")
        bIcon:SetSize(22, 22)
        bIcon:SetPoint("TOPLEFT", 6, -6)
        bRow.Icon = bIcon

        local bName = bRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        bName:SetPoint("TOPLEFT", bIcon, "TOPRIGHT", 6, -2)
        bName:SetPoint("RIGHT", -55, 0)
        bName:SetJustifyH("LEFT")
        bRow.Name = bName

        local bReward = bRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        bReward:SetPoint("BOTTOMLEFT", 6, 6)
        bReward:SetTextColor(1.0, 0.82, 0.0, 1.0)
        bRow.Reward = bReward

        local trackBtn = CreateFrame("Button", nil, bRow, "BackdropTemplate")
        trackBtn:SetSize(52, 20)
        trackBtn:SetPoint("BOTTOMRIGHT", -6, 6)
        trackBtn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        trackBtn:SetBackdropColor(30/255, 40/255, 55/255, 1.0)
        trackBtn:SetBackdropBorderColor(56/255, 189/255, 248/255, 0.6)
        local trackLabel = trackBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        trackLabel:SetPoint("CENTER", 0, 0)
        trackLabel:SetTextColor(56/255, 189/255, 248/255, 1.0)
        trackLabel:SetText("Track")
        trackBtn.Label = trackLabel
        bRow.TrackBtn = trackBtn

        bRow:Hide()
        bountyRows[bIdx] = bRow
    end
    card2.BountyRows = bountyRows

    local noBountiesLabel = card2:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    noBountiesLabel:SetPoint("CENTER", 0, -10)
    noBountiesLabel:SetTextColor(119/255, 119/255, 119/255, 1.0)
    noBountiesLabel:SetText("No active bounties posted.\nUse |cffffd100/kb mark <name> <gold>|r")
    card2.NoBounties = noBountiesLabel

    -- Card 3: All Classes (Compact 2-Column Matrix) (Height: 178px)
    local card3 = CreateFrame("Frame", nil, sidebarContainer, "BackdropTemplate")
    card3:SetPoint("TOPLEFT", card2, "BOTTOMLEFT", 0, -6)
    card3:SetPoint("TOPRIGHT", card2, "BOTTOMRIGHT", 0, -6)
    card3:SetHeight(178)
    card3:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    card3:SetBackdropColor(0.043, 0.059, 0.090, 0.95)
    card3:SetBackdropBorderColor(0.12, 0.16, 0.23, 1.0)

    local card3Title = card3:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    card3Title:SetPoint("TOPLEFT", 8, -6)
    card3Title:SetTextColor(0.78, 0.65, 0.35, 1.0)
    card3Title:SetText("ALL CLASSES")
    if card3Title.SetFont then local f, s = card3Title:GetFont(); card3Title:SetFont(f, s or 10, "OUTLINE") end
    card3.Title = card3Title

    local card3Div = card3:CreateTexture(nil, "OVERLAY")
    card3Div:SetPoint("TOPLEFT", 0, -22)
    card3Div:SetPoint("TOPRIGHT", 0, -22)
    card3Div:SetHeight(1)
    card3Div:SetColorTexture(0.58, 0.45, 0.22, 0.4)
    card3.HeaderDivider = card3Div

    local classRows = {}
    local classList = {
        { tag = "WARRIOR", name = "Warrior", col = 1, row = 1 },
        { tag = "PALADIN", name = "Paladin", col = 1, row = 2 },
        { tag = "HUNTER",  name = "Hunter",  col = 1, row = 3 },
        { tag = "ROGUE",   name = "Rogue",   col = 1, row = 4 },
        { tag = "PRIEST",  name = "Priest",  col = 1, row = 5 },
        { tag = "SHAMAN",  name = "Shaman",  col = 2, row = 1 },
        { tag = "MAGE",    name = "Mage",    col = 2, row = 2 },
        { tag = "WARLOCK", name = "Warlock", col = 2, row = 3 },
        { tag = "DRUID",   name = "Druid",   col = 2, row = 4 },
        { tag = "DEATHKNIGHT", name = "DK", col = 2, row = 5 },
    }
    for _, cDef in ipairs(classList) do
        local xOff = (cDef.col == 1) and 10 or 142
        local yOff = -26 - ((cDef.row - 1) * 28)
        local cFrame = CreateFrame("Frame", nil, card3)
        cFrame:SetSize(126, 24)
        cFrame:SetPoint("TOPLEFT", card3, "TOPLEFT", xOff, yOff)

        local icon = cFrame:CreateTexture(nil, "ARTWORK")
        icon:SetSize(16, 16)
        icon:SetPoint("LEFT", 0, 0)
        icon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
        local coords = CLASS_COORDS[cDef.tag] or {0, 0.25, 0, 0.25}
        icon:SetTexCoord(coords[1], coords[2], coords[3], coords[4])

        local nameLbl = cFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        nameLbl:SetPoint("LEFT", icon, "RIGHT", 4, 0)
        local cColor = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(cDef.name, cDef.tag) or cDef.name
        nameLbl:SetText(cColor)

        local countLbl = cFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        countLbl:SetPoint("RIGHT", 0, 0)
        countLbl:SetTextColor(1.0, 1.0, 1.0, 1.0)
        countLbl:SetText("0")

        cFrame.Count = countLbl
        classRows[cDef.tag] = cFrame
    end
    card3.ClassRows = classRows

    UI.Sidebar = {
        Container = sidebarContainer,
        Card1 = card1,
        Card2 = card2,
        Card3 = card3,
    }
    UI.SidebarCards = { card1, card2, card3 }

    function UI:UpdateSidebar()
        if not UI.Sidebar or not UI.Sidebar.Card1 or InCombatLockdown() then return end
        local c1 = UI.Sidebar.Card1
        local c2 = UI.Sidebar.Card2
        local c3 = UI.Sidebar.Card3

        local killsCount, soloCount = 0, 0
        local aKills, hKills = 0, 0
        local now = time()
        local kills24h = 0
        local classVictimCounts = {}

        if WoWKillboardDB and WoWKillboardDB.kills then
            for _, km in pairs(WoWKillboardDB.kills) do
                if not KB.Leaderboard or KB.Leaderboard:MatchesRealm(km) then
                    killsCount = killsCount + 1
                    if km.timestamp and (now - km.timestamp) <= 86400 then
                        kills24h = kills24h + 1
                    end
                    if km.isSolo then
                        soloCount = soloCount + 1
                    end
                    if km.killer and km.killer.faction then
                        local f = km.killer.faction:lower()
                        if f:find("alliance") then aKills = aKills + 1
                        elseif f:find("horde") then hKills = hKills + 1 end
                    end
                    if km.victim and km.victim.class then
                        local c = km.victim.class:upper()
                        classVictimCounts[c] = (classVictimCounts[c] or 0) + 1
                    end
                end
            end
        end

        local pveDeathsCount = 0
        if WoWKillboardDB and WoWKillboardDB.pveDeaths then
            for _, pd in pairs(WoWKillboardDB.pveDeaths) do
                if not KB.Leaderboard or KB.Leaderboard:MatchesRealm(pd) then
                    pveDeathsCount = pveDeathsCount + 1
                end
            end
        end

        local totFaction = aKills + hKills
        local aPct = totFaction > 0 and math.floor((aKills / totFaction) * 100) or 50
        local hPct = 100 - aPct
        local soloPct = killsCount > 0 and math.floor((soloCount / killsCount) * 100) or 0

        if c1.Lines then
            c1.Lines[1]:SetText(string.format("|cff888888Realm Kills:|r |cffffffff%d|r", killsCount))
            c1.Lines[2]:SetText(string.format("|cff88888824H Activity:|r |cffffffff%d|r", kills24h))
            c1.Lines[3]:SetText(string.format("|cff888888PvE Casualties:|r |cffffffff%d|r", pveDeathsCount))
            c1.Lines[4]:SetText(string.format("|cff888888War Split:|r |cff0080ff%d%% A|r / |cffff2020%d%% H|r", aPct, hPct))
            c1.Lines[5]:SetText(string.format("|cff8888881v1 Solo Rate:|r |cff4ade80%d%%|r", soloPct))
        end

        -- Update Card 2: The Marked
        local activeOutlaws = {}
        local seen = {}
        local function CollectBounty(b)
            if not b or (KB.Leaderboard and not KB.Leaderboard:MatchesRealm(b)) then return end
            local bId = b.id or b.bountyId
            local bStatus = b.status or "ACTIVE"
            local tName = b.targetName or b.target_name
            if (bStatus == "ACTIVE" or bStatus == (KB.STATUS and KB.STATUS.ACTIVE or "ACTIVE")) and bId and not seen[bId] and tName and tName ~= "" and tName:lower() ~= "unknown" then
                seen[bId] = true
                b.id = bId
                b.targetName = tName
                b.targetClass = b.targetClass or b.target_class or "UNKNOWN"
                b.targetFaction = b.targetFaction or b.target_faction or ""
                local copper = tonumber(b.amountCopper or b.amount_copper or 0) or 0
                local gold = tonumber(b.amountGold or b.amount_gold or math.floor(copper / 10000)) or 0
                if copper <= 0 and gold > 0 then copper = gold * 10000 end
                b.amountCopper = copper
                b.amountGold = gold
                table.insert(activeOutlaws, b)
            end
        end
        if WoWKillboardBounties then
            for _, b in pairs(WoWKillboardBounties) do CollectBounty(b) end
        end
        local rData = WoWKillboard_RealmData or (WoWKillboardDB and WoWKillboardDB.RealmData)
        if rData and rData.ActiveBounties then
            for _, b in ipairs(rData.ActiveBounties) do CollectBounty(b) end
        end
        table.sort(activeOutlaws, function(a, b) return (a.amountCopper or 0) > (b.amountCopper or 0) end)

        if #activeOutlaws == 0 then
            if c2.NoBounties then c2.NoBounties:Show() end
            if c2.BountyRows then
                for _, r in ipairs(c2.BountyRows) do r:Hide() end
            end
        else
            if c2.NoBounties then c2.NoBounties:Hide() end
            if c2.BountyRows then
                for idx = 1, 3 do
                    local r = c2.BountyRows[idx]
                    local b = activeOutlaws[idx]
                    if r and b then
                        r:Show()
                        local tClass = b.targetClass or "WARRIOR"
                        local tName = b.targetName or "Target"
                        local coords = CLASS_COORDS[tClass:upper()] or {0, 0.25, 0, 0.25}
                        r.Icon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
                        r.Icon:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
                        local cName = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(tName, tClass) or tName
                        r.Name:SetText(cName)
                        local gAmt = b.amountGold or 0
                        r.Reward:SetText(string.format("Bounty: |cffffd100%dg|r", gAmt))
                        r.TrackBtn:SetScript("OnClick", function()
                            if InCombatLockdown and InCombatLockdown() then return end
                            TargetUnit(tName)
                            if UnitExists("target") and (GetRaidTargetIndex("target") ~= 8) then
                                SetRaidTarget("target", 8)
                            end
                            DEFAULT_CHAT_FRAME:AddMessage(string.format("|cff38bdf8[WoWKillboard]|r Tracking active bounty target: %s", tName))
                        end)
                    elseif r then
                        r:Hide()
                    end
                end
            end
        end

        -- Update Card 3: Class matrix
        if c3.ClassRows then
            for cTag, cFrame in pairs(c3.ClassRows) do
                local cnt = classVictimCounts[cTag] or 0
                if cFrame.Count then
                    cFrame.Count:SetText(tostring(cnt))
                end
            end
        end

        -- Update Top Telemetry Ribbon
        if UI.TelemetryText then
            local topZone = "Azeroth"
            if KB.Leaderboard and KB.Leaderboard.GetTopZones then
                local topZones = KB.Leaderboard:GetTopZones(1)
                if topZones and topZones[1] and topZones[1].name then
                    topZone = topZones[1].name
                end
            end
            UI.TelemetryText:SetText(string.format(
                "|cff888888REALM:|r |cffffffff%d|r  |cff444444|  |cff88888824H:|r |cffffffff%d|r  |cff444444|  |cff888888PVE CASUALTIES:|r |cffff8000%d|r  |cff444444|  |cff888888HOT ZONE:|r |cffffd200%s|r",
                killsCount, kills24h, pveDeathsCount, topZone
            ))
        end

        if UI.FactionSplitBar then
            local barInnerWidth = 138 -- 140 - 2px outer border
            local aWidth = math.max(1, math.min(barInnerWidth - 1, math.floor(barInnerWidth * (aPct / 100))))
            UI.FactionSplitBar.AllianceFill:SetWidth(aWidth)
            UI.FactionSplitBar.Text:SetText(string.format("%d%% A | %d%% H", aPct, hPct))
        end
    end

    -- Detail Modal Frame
    UI:CreateDetailModal()

    -- Frontline Kill Banner
    UI:InitializeKillBanner()

    -- Tactical Radar HUD Frame
    UI:InitializeRadarHUD()

    UI:ApplyTheme()
    mainFrame:Hide()
end

-- Refresh UI content based on activeTab and currentMode
function UI:Refresh()
    if not UI.ContentFrame or InCombatLockdown() then return end
    UI:UpdatePortrait()
    if KB.SyncRealmData then KB:SyncRealmData() end
    KB.Leaderboard:Rebuild()

    -- Update KPI Header Cards
    local s = KB.CombatTracker.SessionStats
    local st = WoWKillboardDB and WoWKillboardDB.stats or {}

    -- Calculate total activity across the board and reconcile player stats
    local totalKillsCount = 0
    local soloKillsCount = 0
    local totalDuelsCount = (st.duels and st.duels.total) or 0
    local totalBgsCount = (st.bgs and st.bgs.total) or 0
    local histKills, histDeaths = 0, 0
    if WoWKillboardDB and WoWKillboardDB.kills then
        local pName = UnitName("player")
        local histWins, histLosses = 0, 0
        local duelKills, bgKills, worldKills = 0, 0, 0
        for _, km in pairs(WoWKillboardDB.kills) do
            if not KB.Leaderboard or KB.Leaderboard:MatchesRealm(km) then
                if km.isSolo then
                    soloKillsCount = soloKillsCount + 1
                end
                if km.isDuel then
                    duelKills = duelKills + 1
                    if pName then
                        local isW = (km.killer and km.killer.name and (km.killer.name:lower():find(pName:lower(), 1, true) ~= nil))
                        local isL = (km.victim and km.victim.name and (km.victim.name:lower():find(pName:lower(), 1, true) ~= nil))
                        if isW then histWins = histWins + 1 end
                        if isL then histLosses = histLosses + 1 end
                    end
                elseif km.isBattleground then
                    bgKills = bgKills + 1
                    if pName then
                        local isK = (km.killer and km.killer.name and (km.killer.name:lower() == pName:lower() or km.killer.name:lower():find(pName:lower(), 1, true) ~= nil))
                        local isV = (km.victim and km.victim.name and (km.victim.name:lower() == pName:lower() or km.victim.name:lower():find(pName:lower(), 1, true) ~= nil))
                        if isK then histKills = histKills + 1 end
                        if isV then histDeaths = histDeaths + 1 end
                    end
                else
                    worldKills = worldKills + 1
                    if pName then
                        local isK = (km.killer and km.killer.name and (km.killer.name:lower() == pName:lower() or km.killer.name:lower():find(pName:lower(), 1, true) ~= nil))
                        local isV = (km.victim and km.victim.name and (km.victim.name:lower() == pName:lower() or km.victim.name:lower():find(pName:lower(), 1, true) ~= nil))
                        if isK then histKills = histKills + 1 end
                        if isV then histDeaths = histDeaths + 1 end
                    end
                end
            end
        end
        if st.duels then
            st.duels.wins = math.max(st.duels.wins or 0, histWins)
            st.duels.losses = math.max(st.duels.losses or 0, histLosses)
            st.duels.total = math.max(st.duels.total or 0, duelKills)
        end
        totalDuelsCount = math.max(totalDuelsCount, duelKills)
        totalBgsCount = math.max(totalBgsCount, bgKills)
        totalKillsCount = worldKills
    end

    local myKills = math.max(s.kills or 0, histKills)
    local myDeaths = math.max(s.deaths or 0, histDeaths)

    local dW = st.duels and st.duels.wins or 0
    local dL = st.duels and st.duels.losses or 0
    local dTot = dW + dL
    local dRate = dTot > 0 and math.floor((dW / dTot) * 100) or 0

    local bgW = st.bgs and st.bgs.wins or 0
    local bgL = st.bgs and st.bgs.losses or 0
    local bgTot = bgW + bgL
    local bgRate = bgTot > 0 and math.floor((bgW / bgTot) * 100) or 0

    local kd = (myDeaths > 0) and string.format("%.2f", myKills / myDeaths) or tostring(myKills)

    if UI.UpdateRulesetButton then
        UI:UpdateRulesetButton()
    end

    local isPveMode = UI:IsPve()

    -- Dynamic Tab Configuration: Exactly 5 clean tabs for PvP and PvE
    local tabOrder = { "FEED", "LEADERBOARD", "BOUNTIES", "RALLIES", "ZONES" }
    local pveTabDefs = {
        FEED        = { text = "Casualties",         w = 76 },
        LEADERBOARD = { text = "Deadly Hazards",     w = 104 },
        BOUNTIES    = { text = "Notorious Elites",   w = 108 },
        RALLIES     = { text = "Rescue Beacons",     w = 102 },
        ZONES       = { text = "Zone Mortality",     w = 98 },
    }
    local pvpTabDefs = {
        FEED        = { text = "Intel",              w = 56 },
        LEADERBOARD = { text = "Leaderboards",       w = 96 },
        BOUNTIES    = { text = "The Marked",         w = 82 },
        RALLIES     = { text = "Call to Arms",       w = 86 },
        ZONES       = { text = "Danger Zones",       w = 92 },
    }
    local tabDefs = isPveMode and pveTabDefs or pvpTabDefs
    local prevTab = nil
    for _, tid in ipairs(tabOrder) do
        local btn = tabButtons and tabButtons[tid]
        local def = tabDefs[tid]
        if btn and def then
            btn:SetWidth(def.w)
            if btn.Label then btn.Label:SetText(def.text) end
            btn:ClearAllPoints()
            if not prevTab then
                btn:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -74)
            else
                btn:SetPoint("LEFT", prevTab, "RIGHT", 4, 0)
            end
            prevTab = btn
        end
    end

    -- Dynamic Mode Filter Pills ([ World ] [ BGs ] [ Duels ] [ Arenas ])
    local filterOrder = { "ARENA", "DUEL", "BG", "WORLD" }
    local pillDefs = {
        ARENA = { text = "Arenas", w = 64, tooltip = "Rated & Skirmish Arena Engagements" },
        DUEL  = { text = "Duels",  w = 58, tooltip = "Sanctioned 1v1 Duel Mortalities" },
        BG    = { text = "BGs",    w = 54, tooltip = "Battleground Engagements (Warsong, Arathi, Alterac)" },
        WORLD = { text = "World",  w = 62, tooltip = "Open World Contested Zone Combat" },
    }
    local prevPill = nil
    for _, fid in ipairs(filterOrder) do
        local pill = filterButtons and filterButtons[fid]
        local pDef = pillDefs[fid]
        if pill and pDef then
            pill:SetWidth(pDef.w)
            if pill.Label then pill.Label:SetText(pDef.text) end
            pill.tooltipText = pDef.tooltip
            pill:ClearAllPoints()
            if not prevPill then
                pill:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -10, -75)
            else
                pill:SetPoint("RIGHT", prevPill, "LEFT", -4, 0)
            end
            prevPill = pill

            local filterId = fid
            pill:SetScript("OnClick", function()
                WoWKillboardDB = WoWKillboardDB or {}
                WoWKillboardDB.combatFilter = filterId
                if WoWKillboardSettings then WoWKillboardSettings.combatFilter = filterId end
                currentMode = filterId
                UI:Refresh()
            end)
            pill:SetScript("OnEnter", function(self)
                self:SetBackdropBorderColor(0.831, 0.686, 0.216, 0.8)
                if self.Label then self.Label:SetTextColor(1, 1, 1, 1) end
                if self.tooltipText then
                    UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100" .. (self.Label and self.Label:GetText() or "") .. "|r", self.tooltipText)
                end
            end)
            pill:SetScript("OnLeave", function(self)
                if not self.isActive then
                    self:SetBackdropBorderColor(0.122, 0.161, 0.216, 1.0)
                    if self.Label then self.Label:SetTextColor(0.612, 0.639, 0.686, 1.0) end
                else
                    self:SetBackdropBorderColor(0.831, 0.686, 0.216, 0.85)
                    if self.Label then self.Label:SetTextColor(0.984, 0.749, 0.141, 1.0) end
                end
                UI:HidePrivateTooltip()
            end)
        end
    end

    local pveSummary = nil
    local myPveDeaths = 0
    if isPveMode then
        pveSummary = KB.Leaderboard and KB.Leaderboard.GetPveSummary and KB.Leaderboard:GetPveSummary() or {
            totalDeaths = 0,
            uniqueMonsters = 0,
            topMonster = "None Encountered",
            topMonsterKills = 0,
            deadliestZone = "Unknown",
            deadliestZoneDeaths = 0,
        }
        myPveDeaths = s.pveDeaths or 0
        if WoWKillboardDB and WoWKillboardDB.pveDeaths then
            local pName = UnitName("player")
            local localMyD = 0
            for _, pd in pairs(WoWKillboardDB.pveDeaths) do
                if pd.victim and pd.victim.name and pName and (pd.victim.name:lower() == pName:lower()) then
                    localMyD = localMyD + 1
                end
            end
            myPveDeaths = math.max(myPveDeaths, localMyD)
        end
    end

    local aR, aG, aB, aHex = WoWKB.AccentColor()
    local aCode = "|cff" .. (aHex or "ffd100")

    local modeSummary = KB.Leaderboard and KB.Leaderboard.GetModeSummary and KB.Leaderboard:GetModeSummary(currentMode or "WORLD") or {
        totalKills = totalKillsCount or 0,
        soloKills = soloKillsCount or 0,
        soloPct = (totalKillsCount > 0 and soloKillsCount) and math.floor((soloKillsCount / totalKillsCount) * 100) or 0,
        alliancePct = 50,
        hordePct = 50,
    }

    if UI.StatCards then
        -- Segment 1: Total Kills
        if UI.StatCards.KD then
            if UI.StatCards.KD.TitleLabel then
                UI.StatCards.KD.TitleLabel:SetTextColor(136/255, 136/255, 136/255, 1.0)
                UI.StatCards.KD.TitleLabel:SetText(isPveMode and "Total Deaths" or "Total Kills")
            end
            if UI.StatCards.KD.PrimaryLabel then
                UI.StatCards.KD.PrimaryLabel:SetTextColor(1.0, 1.0, 1.0, 1.0)
                local val = isPveMode and (pveSummary and pveSummary.totalDeaths or 0) or (modeSummary and modeSummary.totalKills or totalKillsCount or 0)
                UI.StatCards.KD.PrimaryLabel:SetText(tostring(val))
            end
            if UI.StatCards.KD.SubLabel then
                UI.StatCards.KD.SubLabel:SetTextColor(102/255, 102/255, 102/255, 1.0)
                if isPveMode then
                    UI.StatCards.KD.SubLabel:SetText(string.format("Personal: %d", myPveDeaths or 0))
                else
                    UI.StatCards.KD.SubLabel:SetText(string.format("Personal: %d Kills / %d Deaths", myKills or 0, myDeaths or 0))
                end
            end
        end

        -- Segment 2: 1v1 Solo Ratio (or Top Threat in PvE)
        if UI.StatCards.DUELS then
            if UI.StatCards.DUELS.TitleLabel then
                UI.StatCards.DUELS.TitleLabel:SetTextColor(136/255, 136/255, 136/255, 1.0)
                UI.StatCards.DUELS.TitleLabel:SetText(isPveMode and "Top Threat" or "1v1 Solo Ratio")
            end
            if UI.StatCards.DUELS.PrimaryLabel then
                if isPveMode then
                    UI.StatCards.DUELS.PrimaryLabel:SetTextColor(1.0, 56/255, 56/255, 1.0) -- Hostile Red #FF3838
                    UI.StatCards.DUELS.PrimaryLabel:SetText(pveSummary and pveSummary.topMonster or "None")
                else
                    UI.StatCards.DUELS.PrimaryLabel:SetTextColor(74/255, 222/255, 128/255, 1.0) -- Green #4ADE80
                    local sPct = (modeSummary and modeSummary.soloPct) or ((totalKillsCount > 0 and soloKillsCount) and math.floor((soloKillsCount / totalKillsCount) * 100)) or 0
                    UI.StatCards.DUELS.PrimaryLabel:SetText(string.format("%d%%", sPct))
                end
            end
            if UI.StatCards.DUELS.SubLabel then
                UI.StatCards.DUELS.SubLabel:SetTextColor(102/255, 102/255, 102/255, 1.0)
                if isPveMode then
                    UI.StatCards.DUELS.SubLabel:SetTextColor(aR, aG, aB, 1.0)
                    UI.StatCards.DUELS.SubLabel:SetText(string.format("%d Kills", pveSummary and pveSummary.topMonsterKills or 0))
                else
                    local sCount = (modeSummary and modeSummary.soloKills) or soloKillsCount or 0
                    UI.StatCards.DUELS.SubLabel:SetText(string.format("%d Encounters", sCount))
                end
            end
        end

        -- Segment 3: Faction Balance (or Deadliest Zone in PvE)
        if UI.StatCards.BGS then
            if UI.StatCards.BGS.TitleLabel then
                UI.StatCards.BGS.TitleLabel:SetTextColor(136/255, 136/255, 136/255, 1.0)
                UI.StatCards.BGS.TitleLabel:SetText(isPveMode and "Deadliest Zone" or "Faction Balance")
            end
            if UI.StatCards.BGS.PrimaryLabel then
                if isPveMode then
                    UI.StatCards.BGS.PrimaryLabel:SetTextColor(aR, aG, aB, 1.0)
                    UI.StatCards.BGS.PrimaryLabel:SetText(pveSummary and pveSummary.deadliestZone or "Azeroth")
                else
                    local aPct = (modeSummary and modeSummary.alliancePct) or 50
                    local hPct = (modeSummary and modeSummary.hordePct) or 50
                    UI.StatCards.BGS.PrimaryLabel:SetText(string.format("|cff0078ffA: %d%%|r  |cffff3838H: %d%%|r", aPct, hPct))
                end
            end
            if UI.StatCards.BGS.SubLabel then
                UI.StatCards.BGS.SubLabel:SetTextColor(102/255, 102/255, 102/255, 1.0)
                if isPveMode then
                    UI.StatCards.BGS.SubLabel:SetText(string.format("%d Casualties", pveSummary and pveSummary.deadliestZoneDeaths or 0))
                else
                    UI.StatCards.BGS.SubLabel:SetText("Realm Balance")
                end
            end
        end
    end

    local theme = UI:GetTheme()

    -- Update Tab Button Highlights
    for tid, btn in pairs(tabButtons) do
        if tid == activeTab then
            btn.isActive = true
            if theme.btnBackdrop then btn:SetBackdrop(theme.btnBackdrop) end
            if theme.id == "wkb" or theme.id == "web" then
                -- Match Web Header: Background dark slate (0.08, 0.11, 0.16, 1.0), 2px solid bright gold bottom line (0.85, 0.70, 0.25, 1.0), font solid white bold (1.0, 1.0, 1.0, 1.0)
                btn:SetBackdropColor(0.08, 0.11, 0.16, 1.0)
                btn:SetBackdropBorderColor(0.12, 0.16, 0.23, 1.0)
                btn.Label:SetTextColor(1.0, 1.0, 1.0, 1.0)
                if btn.bottomAccent then
                    btn.bottomAccent:SetColorTexture(0.85, 0.70, 0.25, 1.0)
                    btn.bottomAccent:Show()
                end
            else
                btn:SetBackdropColor(unpack(theme.btnActiveBg or {0.20, 0.20, 0.20, 1.0}))
                btn:SetBackdropBorderColor(aR, aG, aB, 1.0)
                btn.Label:SetTextColor(aR, aG, aB, 1.0)
                if btn.bottomAccent then btn.bottomAccent:Hide() end
            end
        else
            btn.isActive = false
            if btn.bottomAccent then btn.bottomAccent:Hide() end
            if theme.btnBackdrop then btn:SetBackdrop(theme.btnBackdrop) end
            btn:SetBackdropColor(unpack(theme.btnBg))
            btn:SetBackdropBorderColor(unpack(theme.btnBorder))
            if theme.id == "classic" then
                btn.Label:SetTextColor(0.85, 0.75, 0.60)
            elseif theme.id == "wkb" or theme.id == "web" then
                btn.Label:SetTextColor(0.612, 0.639, 0.686, 1.0)
            else
                btn.Label:SetTextColor(0.65, 0.65, 0.65)
            end
        end
    end

    -- Update Filter Pill Active Glow: [ World ] [ BGs ] [ Duels ] [ Arenas ]
    local activeFilter = (WoWKillboardDB and WoWKillboardDB.combatFilter) or currentMode or "WORLD"
    for fid, pill in pairs(filterButtons) do
        if isPveMode then
            pill:Hide()
        else
            pill:Show()
            if fid == activeFilter then
                pill.isActive = true
                if pill.bg then
                    pill.bg:SetColorTexture(0.78, 0.60, 0.24, 1.0)
                end
                pill:SetBackdropColor(0.78, 0.60, 0.24, 1.0)
                pill:SetBackdropBorderColor(0.85, 0.70, 0.30, 1.0)
                if pill.Label then
                    pill.Label:SetTextColor(0.05, 0.05, 0.05, 1.0)
                end
                if pill.text then
                    pill.text:SetTextColor(0.05, 0.05, 0.05, 1.0)
                end
            else
                pill.isActive = false
                if pill.bg then
                    pill.bg:SetColorTexture(0.06, 0.08, 0.12, 0.8)
                end
                pill:SetBackdropColor(0.06, 0.08, 0.12, 0.8)
                pill:SetBackdropBorderColor(0.15, 0.19, 0.26, 1.0)
                if pill.Label then
                    pill.Label:SetTextColor(0.65, 0.70, 0.75, 1.0)
                end
                if pill.text then
                    pill.text:SetTextColor(0.65, 0.70, 0.75, 1.0)
                end
            end
        end
    end

    if UI.ScrollContainer then
        UI.ScrollContainer:SetVerticalScroll(0)
    end

    -- Clear previous rows safely
    local children = { UI.ContentFrame:GetChildren() }
    for _, child in ipairs(children) do
        child:Hide()
    end
    local regions = { UI.ContentFrame:GetRegions() }
    for _, region in ipairs(regions) do
        region:Hide()
    end

    if isPveMode then
        if activeTab == "FEED" or activeTab == "BG_METRICS" then
            activeTab = "FEED"
            UI:RenderPveFeed()
        elseif activeTab == "LEADERBOARD" or activeTab == "HAZARDS" then
            activeTab = "LEADERBOARD"
            UI:RenderPveLeaderboard()
        elseif activeTab == "BOUNTIES" then
            UI:RenderPveBounties()
        elseif activeTab == "RALLIES" then
            UI:RenderPveRallies()
        elseif activeTab == "ZONES" then
            UI:RenderPveZones()
        else
            activeTab = "FEED"
            UI:RenderPveFeed()
        end
    else
        if activeTab == "FEED" or activeTab == "BG_METRICS" then
            activeTab = "FEED"
            UI:RenderLiveFeed()
        elseif activeTab == "LEADERBOARD" then
            UI:RenderLeaderboard()
        elseif activeTab == "BOUNTIES" then
            UI:RenderBounties()
        elseif activeTab == "HAZARDS" then
            activeTab = "LEADERBOARD"
            UI:RenderLeaderboard()
        elseif activeTab == "RALLIES" then
            UI:RenderRallies()
        elseif activeTab == "ZONES" then
            UI:RenderZones()
        else
            activeTab = "FEED"
            UI:RenderLiveFeed()
        end
    end

    if UI.UpdateScrollbar then
        UI:UpdateScrollbar()
    end

    if UI.UpdateSidebar then
        UI:UpdateSidebar()
    end
end

-- 1. Render Live Killmail Feed (Tactical Intel)
function UI:RenderLiveFeed()
    local activeMode = (WoWKillboardDB and WoWKillboardDB.combatFilter) or currentMode or "WORLD"
    currentMode = activeMode
    local kills = KB.Leaderboard:GetRecentKills(activeMode, 50)
    local theme = UI:GetTheme()
    local aR, aG, aB = WoWKB.AccentColor()

    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, km in ipairs(kills) do
            local kName = (km.killer and km.killer.name or ""):lower()
            local vName = (km.victim and km.victim.name or ""):lower()
            local kGuild = (km.killer and km.killer.guild or ""):lower()
            local vGuild = (km.victim and km.victim.guild or ""):lower()
            local loc = (km.location and km.location.zone or ""):lower()
            local subLoc = (km.location and km.location.subZone or ""):lower()
            if kName:find(q, 1, true) or vName:find(q, 1, true) or kGuild:find(q, 1, true) or vGuild:find(q, 1, true) or loc:find(q, 1, true) or subLoc:find(q, 1, true) then
                table.insert(filtered, km)
            end
        end
        kills = filtered
    end

    -- Strict Mode Filter Verification: [World, BGs, Duels, Arenas]
    local filteredMode = {}
    for _, km in ipairs(kills) do
        if KB.Leaderboard and KB.Leaderboard.MatchesMode then
            if KB.Leaderboard:MatchesMode(km, activeMode) then
                table.insert(filteredMode, km)
            end
        else
            table.insert(filteredMode, km)
        end
    end
    kills = filteredMode

    local cWidth = 620

    -- Section Header Strip (18px height)
    local recentHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    recentHeader:SetSize(cWidth, 18)
    recentHeader:SetPoint("TOPLEFT", 0, -4)
    recentHeader:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    recentHeader:SetBackdropColor(24/255, 24/255, 24/255, 1.0)
    recentHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

    local recentTitle = recentHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    recentTitle:SetPoint("LEFT", recentHeader, "LEFT", 8, 0)
    recentTitle:SetTextColor(aR, aG, aB, 1.0)
    recentTitle:SetText("RECENT COMBAT INTEL")
    if recentTitle.SetFont then local f, s = recentTitle:GetFont(); recentTitle:SetFont(f, s or 10, "OUTLINE") end
    recentTitle:SetShadowOffset(0, 0)

    -- Table Column Header Strip (Direction: Attacker / Killer on left, Victim on right)
    local colHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    colHeader:SetSize(cWidth, 18)
    colHeader:SetPoint("TOPLEFT", 0, -24)
    colHeader:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    colHeader:SetBackdropColor(22/255, 22/255, 22/255, 1.0)
    colHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

    local function CreateColHeaderLabel(parent, x, w, text, rightAnchor)
        local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        lbl:SetPoint("LEFT", parent, "LEFT", x, 0)
        if rightAnchor then
            lbl:SetPoint("RIGHT", parent, "RIGHT", rightAnchor, 0)
        elseif w then
            lbl:SetWidth(w)
        end
        lbl:SetJustifyH("LEFT")
        lbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
        lbl:SetText(text)
        if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
        lbl:SetShadowOffset(0, 0)
        return lbl
    end

    CreateColHeaderLabel(colHeader, 6, 50, "TIME")
    CreateColHeaderLabel(colHeader, 58, 160, "ATTACKER / KILLER")
    CreateColHeaderLabel(colHeader, 222, 125, "ACTION / SPELL")
    CreateColHeaderLabel(colHeader, 350, 155, "VICTIM")
    CreateColHeaderLabel(colHeader, 512, nil, "ZONE", -6)

    local yOffset = -44

    if #kills == 0 then
        local emptyFrame = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        emptyFrame:SetSize(cWidth, 54)
        emptyFrame:SetPoint("TOPLEFT", 0, yOffset)
        emptyFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        emptyFrame:SetBackdropColor(20/255, 20/255, 20/255, 1.0)
        emptyFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

        local emptyText = emptyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        emptyText:SetPoint("CENTER", 0, 0)
        emptyText:SetTextColor(119/255, 119/255, 119/255, 1.0)
        emptyText:SetText("No combat casualties recorded in this filter. Awaiting combat telemetry.")
        if emptyText.SetFont then local f, s = emptyText:GetFont(); emptyText:SetFont(f, s or 10, "OUTLINE") end
        emptyText:SetShadowOffset(0, 0)

        yOffset = yOffset - 58
        UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
        return
    end

    for idx, km in ipairs(kills) do
        if km and type(km) == "table" and km.killer and type(km.killer) == "table" and km.killer.name and km.victim and type(km.victim) == "table" and km.victim.name then
            local row = CreateFrame("Button", nil, UI.ContentFrame, "BackdropTemplate")
            row:SetSize(cWidth, 24)
            row:SetPoint("TOPLEFT", 0, yOffset)
            local isEven = (idx % 2 == 0)
            local theme = UI:GetTheme()
            local rowBg = isEven and (theme.rowBgAlt or { 0.043, 0.059, 0.090, 0.4 }) or (theme.rowBg or { 0.060, 0.080, 0.115, 0.6 })
            local rowBorder = theme.rowBorder or { 0.12, 0.16, 0.23, 1.0 }

            row:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            row:SetBackdropColor(unpack(rowBg))
            row:SetBackdropBorderColor(unpack(rowBorder))

            local div = row:CreateTexture(nil, "OVERLAY")
            div:SetPoint("BOTTOMLEFT", 0, 0)
            div:SetPoint("BOTTOMRIGHT", 0, 0)
            div:SetHeight(1)
            div:SetColorTexture(0, 0, 0, 1.0)

            local vName = km.victim.name or "Unknown"
            local vClass = km.victim.class or "WARRIOR"
            local vLevel = tonumber(km.victim.level or 0) or 0
            local vGuild = km.victim.guild or ""
            local kName = km.killer.name or "Unknown"
            local kClass = km.killer.class or "WARRIOR"
            local kLevel = tonumber(km.killer.level or 0) or 0
            local locName = km.isBattleground and (km.battlegroundName or "Battleground") or (km.location and km.location.zone or "Azeroth")
            local subLoc = (km.location and km.location.subZone) or ""

            -- Col 1 (Time): 50px
            local timeAgoStr = KB.Utils and KB.Utils.FormatTimeAgo and KB.Utils.FormatTimeAgo(km.timestamp) or "Recently"
            local timeLbl = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            timeLbl:SetPoint("LEFT", row, "LEFT", 6, 0)
            timeLbl:SetWidth(50)
            timeLbl:SetJustifyH("LEFT")
            timeLbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
            timeLbl:SetText(timeAgoStr)
            if timeLbl.SetFont then local f, s = timeLbl:GetFont(); timeLbl:SetFont(f, s or 10, "OUTLINE") end
            timeLbl:SetShadowOffset(0, 0)

            -- Col 2 (Attacker / Killer): 160px | Icon + Level + Name + Guild
            local kIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
            kIconFrame:SetSize(16, 16)
            kIconFrame:SetPoint("LEFT", row, "LEFT", 58, 0)
            kIconFrame:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            kIconFrame:SetBackdropColor(0, 0, 0, 1.0)
            kIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

            local kIcon = UI:CreateClassIcon(kIconFrame, kClass, 16)
            kIcon:SetAllPoints(kIconFrame)

            local kLvlStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            kLvlStr:SetPoint("LEFT", kIconFrame, "RIGHT", 3, 0)
            kLvlStr:SetTextColor(1.0, 0.82, 0.0, 1.0)
            kLvlStr:SetText((kLevel > 0) and string.format("[%d]", kLevel) or "[??]")
            if kLvlStr.SetFont then local f, s = kLvlStr:GetFont(); kLvlStr:SetFont(f, s or 9, "OUTLINE") end
            kLvlStr:SetShadowOffset(0, 0)

            local pName = UnitName and UnitName("player")
            local isLocalKiller = pName and (kName:lower() == pName:lower())
            local isLocalVictim = pName and (vName:lower() == pName:lower())
            local isLocalPlayer = isLocalKiller or isLocalVictim

            local killerStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            killerStr:SetPoint("LEFT", kLvlStr, "RIGHT", 3, 0)
            killerStr:SetPoint("RIGHT", row, "LEFT", 218, 0)
            killerStr:SetJustifyH("LEFT")
            killerStr:SetWordWrap(false)
            local kColorName = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(kName, kClass) or kName
            if isLocalKiller then
                kColorName = kColorName .. " |cffffd100[YOU]|r"
            end
            killerStr:SetText(kColorName)
            if killerStr.SetFont then local f, s = killerStr:GetFont(); killerStr:SetFont(f, s or 10, "OUTLINE") end
            killerStr:SetShadowOffset(0, 0)

            -- Col 3 (Action / Spell): 125px
            local actionStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            actionStr:SetPoint("LEFT", row, "LEFT", 222, 0)
            actionStr:SetPoint("RIGHT", row, "LEFT", 345, 0)
            actionStr:SetJustifyH("LEFT")
            actionStr:SetWordWrap(false)
            local spellName = km.killingBlowAbility or (km.combatLog and km.combatLog.ability) or "Combat Strike"
            actionStr:SetText(string.format("|cff777777slain by |r|cffffe066%s|r", spellName))
            if actionStr.SetFont then local f, s = actionStr:GetFont(); actionStr:SetFont(f, s or 10, "OUTLINE") end
            actionStr:SetShadowOffset(0, 0)

            -- Col 4 (Victim): 155px | Icon + Level + Name + Guild
            local vIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
            vIconFrame:SetSize(16, 16)
            vIconFrame:SetPoint("LEFT", row, "LEFT", 350, 0)
            vIconFrame:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            vIconFrame:SetBackdropColor(0, 0, 0, 1.0)
            vIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

            local vIcon = UI:CreateClassIcon(vIconFrame, vClass, 16)
            vIcon:SetAllPoints(vIconFrame)

            local vLvlStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            vLvlStr:SetPoint("LEFT", vIconFrame, "RIGHT", 3, 0)
            vLvlStr:SetTextColor(1.0, 0.82, 0.0, 1.0)
            vLvlStr:SetText((vLevel > 0) and string.format("[%d]", vLevel) or "[??]")
            if vLvlStr.SetFont then local f, s = vLvlStr:GetFont(); vLvlStr:SetFont(f, s or 9, "OUTLINE") end
            vLvlStr:SetShadowOffset(0, 0)

            local victimStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            victimStr:SetPoint("LEFT", vLvlStr, "RIGHT", 3, 0)
            victimStr:SetPoint("RIGHT", row, "LEFT", 508, 0)
            victimStr:SetJustifyH("LEFT")
            victimStr:SetWordWrap(false)
            local vColorName = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(vName, vClass) or vName
            if isLocalVictim then
                vColorName = vColorName .. " |cffffd100[YOU]|r"
            end
            local vGuildStr = (vGuild and vGuild ~= "" and vGuild ~= "None") and string.format(" |cff888888<%s>|r", vGuild) or ""
            victimStr:SetText(vColorName .. vGuildStr)
            if victimStr.SetFont then local f, s = victimStr:GetFont(); victimStr:SetFont(f, s or 10, "OUTLINE") end
            victimStr:SetShadowOffset(0, 0)

            -- Col 5 (Zone): Auto-fill width
            local locStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            locStr:SetPoint("LEFT", row, "LEFT", 512, 0)
            locStr:SetPoint("RIGHT", row, "RIGHT", -6, 0)
            locStr:SetJustifyH("LEFT")
            locStr:SetWordWrap(false)
            local fullLoc = (subLoc and subLoc ~= "" and subLoc ~= locName) and string.format("%s (%s)", locName, subLoc) or locName
            locStr:SetTextColor(212/255, 163/255, 89/255, 1.0)
            locStr:SetText(fullLoc)
            if locStr.SetFont then local f, s = locStr:GetFont(); locStr:SetFont(f, s or 10, "OUTLINE") end
            locStr:SetShadowOffset(0, 0)

            if isLocalPlayer then
                local myFac = (isLocalKiller and km.killer and km.killer.faction) or (isLocalVictim and km.victim and km.victim.faction) or (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"
                ApplyPlayerRowHighlight(row, myFac)
            end

            -- Row hover interaction
            row:EnableMouse(true)
            local hoverBg = theme.rowHoverBg or { 0.12, 0.16, 0.23, 0.8 }
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(unpack(hoverBg))
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropBorderColor(unpack(rowBorder))
                self:SetBackdropColor(unpack(rowBg))
            end)

            local targetKM = km
            row:SetScript("OnClick", function()
                UI:ShowKillDetail(targetKM)
            end)

            yOffset = yOffset - 24
        end
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
end

-- =========================================================================
-- PvE BESTIARY & WILDERNESS MORTALITY VIEWS
-- =========================================================================

-- 1B. Render PvE Bestiary & Wilderness Mortality Feed (Casualties)
function UI:RenderPveFeed()
    local deaths = KB.Leaderboard:GetRecentPveDeaths(50, currentMode)
    local theme = UI:GetTheme()
    local aR, aG, aB = WoWKB.AccentColor()

    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, pd in ipairs(deaths) do
            local nName = (pd.npc and pd.npc.name or ""):lower()
            local nSpell = (pd.npc and pd.npc.spell or ""):lower()
            local vName = (pd.victim and pd.victim.name or ""):lower()
            local vGuild = (pd.victim and pd.victim.guild or ""):lower()
            local loc = (pd.location and pd.location.zone or ""):lower()
            local subLoc = (pd.location and pd.location.subZone or ""):lower()
            if nName:find(q, 1, true) or nSpell:find(q, 1, true) or vName:find(q, 1, true) or vGuild:find(q, 1, true) or loc:find(q, 1, true) or subLoc:find(q, 1, true) then
                table.insert(filtered, pd)
            end
        end
        deaths = filtered
    end

    local cWidth = 620

    -- Section Header Strip (18px height)
    local recentHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    recentHeader:SetSize(cWidth, 18)
    recentHeader:SetPoint("TOPLEFT", 0, -4)
    recentHeader:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    recentHeader:SetBackdropColor(24/255, 24/255, 24/255, 1.0)
    recentHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

    local recentTitle = recentHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    recentTitle:SetPoint("LEFT", recentHeader, "LEFT", 8, 0)
    recentTitle:SetTextColor(16/255, 185/255, 129/255, 1.0)
    recentTitle:SetText("WILDERNESS MORTALITIES")
    if recentTitle.SetFont then local f, s = recentTitle:GetFont(); recentTitle:SetFont(f, s or 10, "OUTLINE") end
    recentTitle:SetShadowOffset(0, 0)

    -- Table Column Header Strip (Direction: NPC/Hazard on left, Victim on right)
    local colHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    colHeader:SetSize(cWidth, 18)
    colHeader:SetPoint("TOPLEFT", 0, -24)
    colHeader:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    colHeader:SetBackdropColor(22/255, 22/255, 22/255, 1.0)
    colHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

    local function CreateColHeaderLabel(parent, x, w, text, rightAnchor)
        local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        lbl:SetPoint("LEFT", parent, "LEFT", x, 0)
        if rightAnchor then
            lbl:SetPoint("RIGHT", parent, "RIGHT", rightAnchor, 0)
        elseif w then
            lbl:SetWidth(w)
        end
        lbl:SetJustifyH("LEFT")
        lbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
        lbl:SetText(text)
        if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
        lbl:SetShadowOffset(0, 0)
        return lbl
    end

    CreateColHeaderLabel(colHeader, 6, 50, "TIME")
    CreateColHeaderLabel(colHeader, 58, 160, "NPC / HAZARD")
    CreateColHeaderLabel(colHeader, 222, 125, "ACTION / FATAL BLOW")
    CreateColHeaderLabel(colHeader, 350, 155, "VICTIM")
    CreateColHeaderLabel(colHeader, 512, nil, "ZONE", -6)

    local yOffset = -44

    if #deaths == 0 then
        local emptyFrame = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        emptyFrame:SetSize(cWidth, 54)
        emptyFrame:SetPoint("TOPLEFT", 0, yOffset)
        emptyFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        emptyFrame:SetBackdropColor(20/255, 20/255, 20/255, 1.0)
        emptyFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

        local emptyText = emptyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        emptyText:SetPoint("CENTER", 0, 0)
        emptyText:SetTextColor(119/255, 119/255, 119/255, 1.0)
        emptyText:SetText("No casualties recorded in this filter. Awaiting combat telemetry.")
        if emptyText.SetFont then local f, s = emptyText:GetFont(); emptyText:SetFont(f, s or 10, "OUTLINE") end
        emptyText:SetShadowOffset(0, 0)

        yOffset = yOffset - 58
        UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
        return
    end

    for idx, pd in ipairs(deaths) do
        local row = CreateFrame("Button", nil, UI.ContentFrame, "BackdropTemplate")
        row:SetSize(cWidth, 24)
        row:SetPoint("TOPLEFT", 0, yOffset)
        local isEven = (idx % 2 == 0)
        local theme = UI:GetTheme()
        local rowBg = isEven and (theme.rowBgAlt or { 0.043, 0.059, 0.090, 0.4 }) or (theme.rowBg or { 0.060, 0.080, 0.115, 0.6 })
        local rowBorder = theme.rowBorder or { 0.12, 0.16, 0.23, 1.0 }

        row:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        row:SetBackdropColor(unpack(rowBg))
        row:SetBackdropBorderColor(unpack(rowBorder))

        local div = row:CreateTexture(nil, "OVERLAY")
        div:SetPoint("BOTTOMLEFT", 0, 0)
        div:SetPoint("BOTTOMRIGHT", 0, 0)
        div:SetHeight(1)
        div:SetColorTexture(0, 0, 0, 1.0)

        local vName = (pd.victim and pd.victim.name) or "Unknown"
        local vClass = (pd.victim and pd.victim.class) or "WARRIOR"
        local vLevel = tonumber((pd.victim and pd.victim.level) or 0) or 0
        local vGuild = (pd.victim and pd.victim.guild) or ""
        local nName = (pd.npc and pd.npc.name) or "Unknown Entity"
        local nSpell = (pd.npc and pd.npc.spell) or "Combat Strike"
        local zName = (pd.location and pd.location.zone) or "Azeroth"
        local subZone = (pd.location and pd.location.subZone) or ""

        -- Col 1 (Time): 50px
        local timeAgoStr = KB.Utils and KB.Utils.FormatTimeAgo and KB.Utils.FormatTimeAgo(pd.timestamp) or "Recently"
        local timeLbl = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        timeLbl:SetPoint("LEFT", row, "LEFT", 6, 0)
        timeLbl:SetWidth(50)
        timeLbl:SetJustifyH("LEFT")
        timeLbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
        timeLbl:SetText(timeAgoStr)
        if timeLbl.SetFont then local f, s = timeLbl:GetFont(); timeLbl:SetFont(f, s or 10, "OUTLINE") end
        timeLbl:SetShadowOffset(0, 0)

        -- Col 2 (Attacker / NPC / Hazard): 160px | Icon + Name in Hostile Red
        local nIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
        nIconFrame:SetSize(16, 16)
        nIconFrame:SetPoint("LEFT", row, "LEFT", 58, 0)
        nIconFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        nIconFrame:SetBackdropColor(0, 0, 0, 1.0)
        nIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

        local nIconTex = nIconFrame:CreateTexture(nil, "ARTWORK")
        nIconTex:SetAllPoints(nIconFrame)
        local iconPath = pd.icon or "Interface\\Icons\\INV_Misc_MonsterHead_02"
        nIconTex:SetTexture(iconPath)

        local npcStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        npcStr:SetPoint("LEFT", nIconFrame, "RIGHT", 4, 0)
        npcStr:SetPoint("RIGHT", row, "LEFT", 218, 0)
        npcStr:SetJustifyH("LEFT")
        npcStr:SetWordWrap(false)
        npcStr:SetTextColor(1.0, 56/255, 56/255, 1.0)
        npcStr:SetText(nName)
        if npcStr.SetFont then local f, s = npcStr:GetFont(); npcStr:SetFont(f, s or 10, "OUTLINE") end
        npcStr:SetShadowOffset(0, 0)

        -- Col 3 (Action / Fatal Blow): 125px
        local actionStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        actionStr:SetPoint("LEFT", row, "LEFT", 222, 0)
        actionStr:SetPoint("RIGHT", row, "LEFT", 345, 0)
        actionStr:SetJustifyH("LEFT")
        actionStr:SetWordWrap(false)
        local spellText = (nSpell and nSpell ~= "") and nSpell or "Melee Strike"
        actionStr:SetText(string.format("|cff777777slain by |r|cffffe066%s|r", spellText))
        if actionStr.SetFont then local f, s = actionStr:GetFont(); actionStr:SetFont(f, s or 10, "OUTLINE") end
        actionStr:SetShadowOffset(0, 0)

        -- Col 4 (Victim): 155px | Icon + Level + Name + Guild
        local vIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
        vIconFrame:SetSize(16, 16)
        vIconFrame:SetPoint("LEFT", row, "LEFT", 350, 0)
        vIconFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        vIconFrame:SetBackdropColor(0, 0, 0, 1.0)
        vIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

        local vIcon = UI:CreateClassIcon(vIconFrame, vClass, 16)
        vIcon:SetAllPoints(vIconFrame)

        local vLvlStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        vLvlStr:SetPoint("LEFT", vIconFrame, "RIGHT", 3, 0)
        vLvlStr:SetTextColor(1.0, 0.82, 0.0, 1.0)
        vLvlStr:SetText((vLevel > 0) and string.format("[%d]", vLevel) or "[??]")
        if vLvlStr.SetFont then local f, s = vLvlStr:GetFont(); vLvlStr:SetFont(f, s or 9, "OUTLINE") end
        vLvlStr:SetShadowOffset(0, 0)

        local pName = UnitName and UnitName("player")
        local isLocalVictim = pName and (vName:lower() == pName:lower())

        local victimStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        victimStr:SetPoint("LEFT", vLvlStr, "RIGHT", 3, 0)
        victimStr:SetPoint("RIGHT", row, "LEFT", 508, 0)
        victimStr:SetJustifyH("LEFT")
        victimStr:SetWordWrap(false)
        local vColorName = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(vName, vClass) or vName
        if isLocalVictim then
            vColorName = vColorName .. " |cffffd100[YOU]|r"
        end
        local vGuildStr = (vGuild and vGuild ~= "" and vGuild ~= "None") and string.format(" |cff888888<%s>|r", vGuild) or ""
        victimStr:SetText(vColorName .. vGuildStr)
        if victimStr.SetFont then local f, s = victimStr:GetFont(); victimStr:SetFont(f, s or 10, "OUTLINE") end
        victimStr:SetShadowOffset(0, 0)

        -- Col 5 (Zone): Auto-fill width
        local locStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        locStr:SetPoint("LEFT", row, "LEFT", 512, 0)
        locStr:SetPoint("RIGHT", row, "RIGHT", -6, 0)
        locStr:SetJustifyH("LEFT")
        locStr:SetWordWrap(false)
        local fullLoc = (subZone and subZone ~= "" and subZone ~= zName) and string.format("%s (%s)", zName, subZone) or zName
        locStr:SetTextColor(212/255, 163/255, 89/255, 1.0)
        locStr:SetText(fullLoc)
        if locStr.SetFont then local f, s = locStr:GetFont(); locStr:SetFont(f, s or 10, "OUTLINE") end
        locStr:SetShadowOffset(0, 0)

        if isLocalVictim then
            local myFac = (pd.victim and pd.victim.faction) or (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"
            ApplyPlayerRowHighlight(row, myFac)
        end

        -- Row hover interaction
        row:EnableMouse(true)
        local hoverBg = theme.rowHoverBg or { 0.12, 0.16, 0.23, 0.8 }
        row:SetScript("OnEnter", function(self)
            self:SetBackdropColor(unpack(hoverBg))
        end)
        row:SetScript("OnLeave", function(self)
            self:SetBackdropBorderColor(unpack(rowBorder))
            self:SetBackdropColor(unpack(rowBg))
        end)

        -- Click handler to open death detail
        local targetPD = pd
        row:SetScript("OnClick", function()
            UI:ShowPveDeathDetail(targetPD)
        end)

        yOffset = yOffset - 24
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
end

-- 2B. Render PvE Leaderboard Tab (Deadly Hazards & Casualty Registry)
function UI:RenderPveLeaderboard()
    local theme = UI:GetTheme()

    local title = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 10, -8)
    title:SetText("|cffff4444DEADLY HAZARDS & CASUALTY REGISTRY|r")
    title:SetShadowOffset(1, -1)
    title:SetShadowColor(0, 0, 0, 1)

    local sub = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    sub:SetText("|cffb8a080Rankings of the deadliest monsters, fallen adventurers, and perilous zones across Azeroth.|r")
    sub:SetShadowOffset(1, -1)
    sub:SetShadowColor(0, 0, 0, 1)

    -- 3 Column Panes (Apex Executioners, Fallen Mortals, Perilous Regions)
    local cWidth = (UI.ContentFrame and UI.ContentFrame:GetWidth()) or 620
    local gap = 8
    local colW = math.floor((cWidth - 12 - (2 * gap)) / 3)

    -- Column 1: Apex Executioners
    local c1 = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    c1:SetSize(colW, 480)
    c1:SetPoint("TOPLEFT", 6, -52)
    c1:SetBackdrop(theme.rowBackdrop)
    c1:SetBackdropColor(0.04, 0.05, 0.07, 0.95)
    c1:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.8)

    local c1Title = c1:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    c1Title:SetPoint("TOPLEFT", 8, -8)
    c1Title:SetText("|cffff5533APEX EXECUTIONERS|r")

    local c1Sub = c1:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    c1Sub:SetPoint("TOPLEFT", c1Title, "BOTTOMLEFT", 0, -2)
    c1Sub:SetText("|cff94a3b8Deadliest Monsters|r")

    local topNpcs = KB.Leaderboard:GetTopDeadlyNpcs(15) or {}
    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, m in ipairs(topNpcs) do
            local mN = (m.name or ""):lower()
            if mN:find(q, 1, true) then
                table.insert(filtered, m)
            end
        end
        topNpcs = filtered
    end
    local y1 = -38
    for rank, m in ipairs(topNpcs) do
        local rRow = CreateFrame("Frame", nil, c1)
        rRow:SetSize(colW - 14, 26)
        rRow:SetPoint("TOPLEFT", 6, y1)

        local rNum = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rNum:SetPoint("LEFT", 0, 0)
        local rColor = (rank == 1) and "|cffffd100" or ((rank == 2) and "|cffe2e8f0" or ((rank == 3) and "|cffcd7f32" or "|cff64748b"))
        rNum:SetText(string.format("%s#%d|r", rColor, rank))

        local rName = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rName:SetPoint("LEFT", 22, 0)
        rName:SetPoint("RIGHT", -46, 0)
        rName:SetJustifyH("LEFT")
        rName:SetWordWrap(false)
        rName:SetText(string.format("|cffffffff%s|r", m.name or "Unknown"))

        local rKills = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rKills:SetPoint("RIGHT", 0, 0)
        rKills:SetText(string.format("|cffff4444%d|r", m.kills or 0))

        y1 = y1 - 28
    end

    -- Column 2: Fallen Mortals (Most Casualties)
    local c2 = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    c2:SetSize(colW, 480)
    c2:SetPoint("TOPLEFT", c1, "TOPRIGHT", gap, 0)
    c2:SetBackdrop(theme.rowBackdrop)
    c2:SetBackdropColor(0.04, 0.05, 0.07, 0.95)
    c2:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.8)

    local c2Title = c2:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    c2Title:SetPoint("TOPLEFT", 8, -8)
    c2Title:SetText("|cffffd100FALLEN MORTALS|r")

    local c2Sub = c2:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    c2Sub:SetPoint("TOPLEFT", c2Title, "BOTTOMLEFT", 0, -2)
    c2Sub:SetText("|cff94a3b8Adventurers Slain|r")

    local topVictims = KB.Leaderboard:GetTopPveVictims(15) or {}
    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, v in ipairs(topVictims) do
            local vN = (v.name or ""):lower()
            local vC = (v.class or ""):lower()
            if vN:find(q, 1, true) or vC:find(q, 1, true) then
                table.insert(filtered, v)
            end
        end
        topVictims = filtered
    end
    local y2 = -38
    for rank, v in ipairs(topVictims) do
        local rRow = CreateFrame("Frame", nil, c2)
        rRow:SetSize(colW - 14, 26)
        rRow:SetPoint("TOPLEFT", 6, y2)

        local rNum = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rNum:SetPoint("LEFT", 0, 0)
        local rColor = (rank == 1) and "|cffffd100" or ((rank == 2) and "|cffe2e8f0" or ((rank == 3) and "|cffcd7f32" or "|cff64748b"))
        rNum:SetText(string.format("%s#%d|r", rColor, rank))

        local cIcon = UI:CreateClassIcon(rRow, v.class, 16)
        cIcon:SetPoint("LEFT", 20, 0)

        local rName = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rName:SetPoint("LEFT", cIcon, "RIGHT", 3, 0)
        rName:SetPoint("RIGHT", -46, 0)
        rName:SetJustifyH("LEFT")
        rName:SetWordWrap(false)
        rName:SetText(KB.Utils.ColorizeByClass(v.name, v.class))

        local rDeaths = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rDeaths:SetPoint("RIGHT", 0, 0)
        rDeaths:SetText(string.format("|cffef4444%d|r", v.deaths or 0))

        y2 = y2 - 28
    end

    -- Column 3: Perilous Regions
    local c3 = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    c3:SetSize(colW, 480)
    c3:SetPoint("TOPLEFT", c2, "TOPRIGHT", gap, 0)
    c3:SetBackdrop(theme.rowBackdrop)
    c3:SetBackdropColor(0.04, 0.05, 0.07, 0.95)
    c3:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.8)

    local c3Title = c3:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    c3Title:SetPoint("TOPLEFT", 8, -8)
    c3Title:SetText("|cff00e5ffPERILOUS REGIONS|r")

    local c3Sub = c3:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    c3Sub:SetPoint("TOPLEFT", c3Title, "BOTTOMLEFT", 0, -2)
    c3Sub:SetText("|cff94a3b8Deadliest Zones|r")

    local topZones = KB.Leaderboard:GetTopPveZones(12) or {}
    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, z in ipairs(topZones) do
            local zN = (z.zone or ""):lower()
            if zN:find(q, 1, true) then
                table.insert(filtered, z)
            end
        end
        topZones = filtered
    end
    local y3 = -38
    for rank, z in ipairs(topZones) do
        local rRow = CreateFrame("Frame", nil, c3)
        rRow:SetSize(colW - 14, 26)
        rRow:SetPoint("TOPLEFT", 6, y3)

        local rNum = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rNum:SetPoint("LEFT", 0, 0)
        local rColor = (rank == 1) and "|cffffd100" or ((rank == 2) and "|cffe2e8f0" or ((rank == 3) and "|cffcd7f32" or "|cff64748b"))
        rNum:SetText(string.format("%s#%d|r", rColor, rank))

        local rName = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rName:SetPoint("LEFT", 22, 0)
        rName:SetPoint("RIGHT", -46, 0)
        rName:SetJustifyH("LEFT")
        rName:SetWordWrap(false)
        rName:SetText(string.format("|cffffffff%s|r", z.zone or "Unknown"))

        local rCount = rRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rCount:SetPoint("RIGHT", 0, 0)
        rCount:SetText(string.format("|cffffd100%d|r", z.deaths or 0))

        y3 = y3 - 28
    end

    UI.ContentFrame:SetHeight(560)
end

-- 3B. Render PvE Bounties Tab (Notorious Elites & Apex Threats)
function UI:RenderPveBounties()
    local theme = UI:GetTheme()

    local title = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 10, -8)
    title:SetText("|cffffd100NOTORIOUS ELITES & APEX THREATS|r")
    title:SetShadowOffset(1, -1)
    title:SetShadowColor(0, 0, 0, 1)

    local sub = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    sub:SetText("|cffb8a080Lethal world elites, roaming death patrols, and notorious creatures terrorizing Azeroth.|r")
    sub:SetShadowOffset(1, -1)
    sub:SetShadowColor(0, 0, 0, 1)

    -- Apex Intel Notice Banner
    local noticePlate = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    noticePlate:SetSize(820, 32)
    noticePlate:SetPoint("TOPLEFT", 0, -42)
    noticePlate:SetBackdrop(theme.rowBackdrop)
    noticePlate:SetBackdropColor(0.04, 0.08, 0.05, 0.95)
    noticePlate:SetBackdropBorderColor(0.1, 0.65, 0.35, 0.85)

    local noticeText = noticePlate:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    noticeText:SetPoint("CENTER", 0, 0)
    noticeText:SetText("|cff38bdf8APEX INTEL:|r |cffffffffBeware roaming elites on major roads and borders. Casualty counts reflect confirmed player deaths recorded on this realm.|r")
    noticeText:SetShadowOffset(1, -1)
    noticeText:SetShadowColor(0, 0, 0, 1)

    local notoriousElites = {
        { name = "Hogger", title = "Chieftain of the Riverpaw Gnolls", level = 11, classification = "ELITE BOSS", zone = "Elwynn Forest", abilities = "Vicious Bite, Enrage", desc = "Infamous gnoll warlord responsible for widespread slaughter of Stormwind guards and fledgling recruits.", icon = "Interface\\Icons\\Achievement_Boss_Hogger" },
        { name = "Defias Pillager", title = "Outlaw Bandit Pyromancer", level = 14, classification = "LETHAL CASTER", zone = "Westfall (Moonbrook)", abilities = "Fireball (240 Burst DMG)", desc = "Deadly long-range pyromancers with devastating Fireball volleys that have claimed countless travelers.", icon = "Interface\\Icons\\Spell_Fire_Fireball02" },
        { name = "Son of Arugal", title = "Cursed Shadow Worgen", level = 25, classification = "ELITE PATROL", zone = "Silverpine Forest", abilities = "Shadow Bolt, Rend", desc = "Elite shadowstalkers roaming the road between Ambermill and Pyrewood, ambushing traveling mortals.", icon = "Interface\\Icons\\Ability_Racial_BearForm" },
        { name = "Mor'Ladim", title = "Vengeful Ghostly Knight", level = 35, classification = "ELITE UNDEAD", zone = "Duskwood (Raven Hill)", abilities = "Cleave, Mortal Strike", desc = "Former paladin Morgan Ladimore, now a relentlessly aggressive phantom wandering Raven Hill Cemetery.", icon = "Interface\\Icons\\Spell_Shadow_DeathScream" },
        { name = "Stitches", title = "Terror of Darkshire", level = 35, classification = "ELITE ABOMINATION", zone = "Duskwood (Darkshire Road)", abilities = "Aura of Rot, Slam", desc = "Colossal abomination assembled by Abercrombie, marching relentlessly down the main road to Darkshire.", icon = "Interface\\Icons\\INV_Misc_MonsterHead_03" },
        { name = "Devilsaur", title = "Apex Jungle Tyrant", level = 55, classification = "APEX PREDATOR", zone = "Un'Goro Crater", abilities = "Trample, Terrifying Roar", desc = "Terrifying apex predators possessing surprising stealth, crushing unwary adventurers underfoot.", icon = "Interface\\Icons\\Ability_Hunter_Pet_Devilsaur" },
    }

    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filteredElites = {}
        for _, wm in ipairs(notoriousElites) do
            local eN = (wm.name or ""):lower()
            local eT = (wm.title or ""):lower()
            local eZ = (wm.zone or ""):lower()
            local eA = (wm.abilities or ""):lower()
            local eD = (wm.desc or ""):lower()
            if eN:find(q, 1, true) or eT:find(q, 1, true) or eZ:find(q, 1, true) or eA:find(q, 1, true) or eD:find(q, 1, true) then
                table.insert(filteredElites, wm)
            end
        end
        notoriousElites = filteredElites
    end

    local yOffset = -86
    for idx, wm in ipairs(notoriousElites) do
        local card = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        card:SetSize(820, 68)
        card:SetPoint("TOPLEFT", 0, yOffset)
        card:SetBackdrop(theme.rowBackdrop)
        card:SetBackdropColor(0.05, 0.05, 0.07, 0.95)
        card:SetBackdropBorderColor(0.45, 0.35, 0.18, 0.85)

        local icon = card:CreateTexture(nil, "ARTWORK")
        icon:SetSize(42, 42)
        icon:SetPoint("TOPLEFT", 12, -12)
        icon:SetTexture(wm.icon or "Interface\\Icons\\INV_Misc_MonsterClaw_04")

        local nameStr = card:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameStr:SetPoint("TOPLEFT", icon, "TOPRIGHT", 10, -2)
        nameStr:SetText(string.format("|cffff5533%s|r  |cff64748b-  %s|r", wm.name, wm.title))
        nameStr:SetShadowOffset(1, -1)
        nameStr:SetShadowColor(0, 0, 0, 1)

        local descStr = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        descStr:SetPoint("TOPLEFT", nameStr, "BOTTOMLEFT", 0, -3)
        descStr:SetPoint("RIGHT", card, "RIGHT", -190, 0)
        descStr:SetJustifyH("LEFT")
        descStr:SetWordWrap(false)
        descStr:SetText(string.format("|cffcbd5e1%s|r", wm.desc))
        descStr:SetShadowOffset(1, -1)
        descStr:SetShadowColor(0, 0, 0, 1)

        local locStr = card:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        locStr:SetPoint("TOPLEFT", descStr, "BOTTOMLEFT", 0, -3)
        locStr:SetText(string.format("|cff38bdf8Zone:|r |cffffffff%s|r   |cff64748b||r   |cffffd100Lvl %d [%s]|r   |cff64748b||r   |cffea580cSpells:|r |cffffffff%s|r", wm.zone, wm.level, wm.classification, wm.abilities))
        locStr:SetShadowOffset(1, -1)
        locStr:SetShadowColor(0, 0, 0, 1)

        -- Real Telemetry lookup
        local recorded = (KB.Leaderboard and KB.Leaderboard.PveAggregates and KB.Leaderboard.PveAggregates.monsters and KB.Leaderboard.PveAggregates.monsters[wm.name])
        local kills = recorded and (recorded.kills or 0) or 0

        local killsStr = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        killsStr:SetPoint("TOPRIGHT", -14, -14)
        if kills > 0 then
            killsStr:SetText(string.format("|cffff4444%d|r |cffffffffPlayer Deaths|r", kills))
        else
            killsStr:SetText("|cff64748b0 Realm Deaths|r")
        end
        killsStr:SetShadowOffset(1, -1)
        killsStr:SetShadowColor(0, 0, 0, 1)

        local targetBtn = UI:CreateButton(card, 120, 20, "|cff38bdf8Target Macro|r")
        targetBtn:SetPoint("BOTTOMRIGHT", -14, 10)
        local targetName = wm.name
        local targetZone = wm.zone
        targetBtn:SetScript("OnClick", function()
            if InCombatLockdown and InCombatLockdown() then
                SafePrint("|cffff3838[WoWKB]|r Cannot create or edit macros while in combat.")
                return
            end
            local macroBody = string.format("/cleartarget\n/tar %s\n/script SetRaidTarget(\"target\", 8)", targetName)
            local macroIdx = GetMacroIndexByName and GetMacroIndexByName("KB_Target")
            if macroIdx and macroIdx > 0 then
                if EditMacro then
                    EditMacro(macroIdx, "KB_Target", "INV_Misc_QuestionMark", macroBody)
                    SafePrint(string.format("|cff00ccff[WoWKB]|r Updated macro |cffffd100KB_Target|r to target |cffff5533%s|r.", targetName))
                end
            else
                if CreateMacro then
                    local numGlobal, numChar = GetNumMacros and GetNumMacros() or 0, 0
                    if numGlobal < 120 or (numChar and numChar < 18) then
                        CreateMacro("KB_Target", "INV_Misc_QuestionMark", macroBody, nil)
                        SafePrint(string.format("|cff00ccff[WoWKB]|r Created macro |cffffd100KB_Target|r to target |cffff5533%s|r (Skull marked).", targetName))
                    else
                        SafePrint("|cffff3838[WoWKB]|r Macro list full. Could not create KB_Target macro.")
                    end
                end
            end
        end)

        yOffset = yOffset - 76
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 20)
end

-- 4B. Render PvE Zones Tab (Zone Mortality & Danger Index)
function UI:RenderPveZones()
    local theme = UI:GetTheme()

    local title = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 10, -8)
    title:SetText("|cff00e5ffZONE MORTALITY & DANGER INDEX|r")
    title:SetShadowOffset(1, -1)
    title:SetShadowColor(0, 0, 0, 1)

    local sub = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    sub:SetText("|cffb8a080Geographical threat analysis and fatal encounter density across Azeroth.|r")
    sub:SetShadowOffset(1, -1)
    sub:SetShadowColor(0, 0, 0, 1)

    local topZones = KB.Leaderboard:GetTopPveZones(15) or {}
    local fallbackZones = {
        { zone = "Duskwood", deaths = 0 },
        { zone = "Westfall", deaths = 0 },
        { zone = "Silverpine Forest", deaths = 0 },
        { zone = "Hillsbrad Foothills", deaths = 0 },
        { zone = "Elwynn Forest", deaths = 0 },
        { zone = "The Barrens", deaths = 0 },
        { zone = "Stranglethorn Vale", deaths = 0 },
        { zone = "Un'Goro Crater", deaths = 0 },
        { zone = "Eastern Plaguelands", deaths = 0 },
        { zone = "Western Plaguelands", deaths = 0 },
    }
    local displayZones = {}
    for _, z in ipairs(topZones) do table.insert(displayZones, z) end
    for _, fb in ipairs(fallbackZones) do
        if #displayZones >= 12 then break end
        local already = false
        for _, dz in ipairs(displayZones) do
            if dz.zone == fb.zone then already = true; break end
        end
        if not already then table.insert(displayZones, fb) end
    end

    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, z in ipairs(displayZones) do
            local zN = (z.zone or ""):lower()
            if zN:find(q, 1, true) then
                table.insert(filtered, z)
            end
        end
        displayZones = filtered
    end

    local yOffset = -52
    for idx, z in ipairs(displayZones) do
        local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        row:SetSize(820, 36)
        row:SetPoint("TOPLEFT", 0, yOffset)
        local isEven = (idx % 2 == 0)
        local baseBg = isEven and theme.rowBgAlt or theme.rowBg
        row:SetBackdrop(theme.rowBackdrop)
        row:SetBackdropColor(unpack(baseBg))
        row:SetBackdropBorderColor(unpack(theme.rowBorder))

        local rNum = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        rNum:SetPoint("LEFT", 12, 0)
        local rColor = (idx == 1) and "|cffffd100" or ((idx == 2) and "|cffe2e8f0" or ((idx == 3) and "|cffcd7f32" or "|cff64748b"))
        rNum:SetText(string.format("%s#%d|r", rColor, idx))

        local zName = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        zName:SetPoint("LEFT", 50, 0)
        zName:SetText(string.format("|cffffffff%s|r", z.zone or "Unknown"))

        local dangerStr = (idx <= 3) and "|cffff2222[EXTREME DANGER]|r" or ((idx <= 6) and "|cffff8800[HIGH DANGER]|r" or "|cff00e5ff[MODERATE]|r")
        local dLabel = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        dLabel:SetPoint("LEFT", 320, 0)
        dLabel:SetText(dangerStr)

        local countStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        countStr:SetPoint("RIGHT", -16, 0)
        countStr:SetText(string.format("|cffffd100%d|r |cff94a3b8Mortal Casualties|r", z.deaths or 0))

        yOffset = yOffset - 40
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 20)
end

-- 5B. Render PvE Rallies Tab (Rescue Beacons & SOS)
function UI:RenderPveRallies()
    local theme = UI:GetTheme()

    local title = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 10, -8)
    title:SetText("|cffffaa00RESCUE BEACONS & CALL TO ARMS|r")
    title:SetShadowOffset(1, -1)
    title:SetShadowColor(0, 0, 0, 1)

    local sub = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    sub:SetText("|cffb8a080Emergency distress beacons from adventurers pinned down by elites or perilous hazards.|r")
    sub:SetShadowOffset(1, -1)
    sub:SetShadowColor(0, 0, 0, 1)

    local sosBtn = UI:CreateButton(UI.ContentFrame, 130, 22, "Broadcast SOS ->")
    sosBtn:SetPoint("TOPRIGHT", -10, -8)
    sosBtn:SetScript("OnClick", function()
        if UI.ShowRallyPrompt then
            UI:ShowRallyPrompt()
        else
            SafePrint("|cff00ccff[WoWKB]|r Type |cffffd100/kb sos|r to broadcast an emergency distress signal.")
        end
    end)

    -- Instructions Card
    local banner = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    banner:SetSize(820, 64)
    banner:SetPoint("TOPLEFT", 0, -42)
    banner:SetBackdrop(theme.rowBackdrop)
    banner:SetBackdropColor(0.08, 0.06, 0.02, 0.95)
    banner:SetBackdropBorderColor(0.85, 0.65, 0.18, 0.85)

    local bText = banner:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    bText:SetPoint("TOPLEFT", 12, -10)
    bText:SetPoint("BOTTOMRIGHT", -12, 10)
    bText:SetJustifyH("LEFT")
    bText:SetText(
        "|cffffd100* EMERGENCY WILDERNESS BEACON SYSTEM ACTIVE|r\n" ..
        "|cffcbd5e1If you are trapped by elite spawns, pinned down in high-level caves, or seeking backup for an elite quest,\n" ..
        "sound the War Horn by typing |cffffd100/kb sos|r. Nearby allies and guildmates will receive your spatial coordinates.|r"
    )

    -- List of Active Beacons (from WoWKillboardDB.distressBeacons or realm)
    local beacons = {}
    if WoWKillboardDB and WoWKillboardDB.distressBeacons then
        for _, b in pairs(WoWKillboardDB.distressBeacons) do
            table.insert(beacons, b)
        end
    end

    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, b in ipairs(beacons) do
            local bN = (b.character_name or ""):lower()
            local bZ = (b.zone or ""):lower()
            local bM = (b.message or ""):lower()
            if bN:find(q, 1, true) or bZ:find(q, 1, true) or bM:find(q, 1, true) then
                table.insert(filtered, b)
            end
        end
        beacons = filtered
    end

    local yOffset = -118
    if #beacons == 0 then
        local emptyStr = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        emptyStr:SetPoint("TOP", UI.ContentFrame, "TOP", 0, yOffset - 30)
        emptyStr:SetJustifyH("CENTER")
        emptyStr:SetText(
            "|cff64748bNo active rescue beacons in this sector.|r\n\n" ..
            "|cff94a3b8All wilderness territories currently report nominal traffic.\n" ..
            "Use |cffffd100/kb sos <message>|r to broadcast a distress signal to all allies.|r"
        )
        UI.ContentFrame:SetHeight(320)
        return
    end

    for idx, b in ipairs(beacons) do
        local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        row:SetSize(820, 40)
        row:SetPoint("TOPLEFT", 0, yOffset)
        row:SetBackdrop(theme.rowBackdrop)
        row:SetBackdropColor(0.06, 0.05, 0.03, 0.95)
        row:SetBackdropBorderColor(0.85, 0.45, 0.15, 0.75)

        local bIcon = row:CreateTexture(nil, "ARTWORK")
        bIcon:SetSize(24, 24)
        bIcon:SetPoint("LEFT", 10, 0)
        bIcon:SetTexture("Interface\\Icons\\Spell_Holy_SealOfProtection")

        local bName = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        bName:SetPoint("LEFT", bIcon, "RIGHT", 8, 0)
        bName:SetText(string.format("|cffffaa00%s|r |cffcbd5e1in %s|r", b.character_name or "Ally", b.zone or "Wilderness"))

        local bNote = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        bNote:SetPoint("LEFT", 300, 0)
        bNote:SetPoint("RIGHT", -120, 0)
        bNote:SetJustifyH("LEFT")
        bNote:SetText(string.format("|cff94a3b8\"%s\"|r", b.message or "Requesting immediate backup!"))

        local bTime = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        bTime:SetPoint("RIGHT", -12, 0)
        bTime:SetText(KB.Utils and KB.Utils.FormatTimeAgo and KB.Utils.FormatTimeAgo(b.timestamp) or "Recently")

        yOffset = yOffset - 46
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 20)
end

-- PvE Casualty Detail Dialog
function UI:ShowPveDeathDetail(pd)
    if not UI.DetailModal or not pd then return end
    local m = UI.DetailModal
    m.currentKillmail = nil
    m.currentPveDeath = pd

    if m.Title then m.Title:SetText("|cffff4444WILDERNESS CASUALTY DOSSIER|r") end
    if m.KillerCard and m.KillerCard.CardTitle then m.KillerCard.CardTitle:SetText("|cffff5533EXECUTIONER|r") end
    if m.VictimCard and m.VictimCard.CardTitle then m.VictimCard.CardTitle:SetText("|cffff4444FALLEN MORTAL|r") end
    if m.KillerCard and m.KillerCard.WebBtn then m.KillerCard.WebBtn:Hide() end
    if m.VictimCard and m.VictimCard.WebBtn then m.VictimCard.WebBtn:Show() end

    local nName = (pd.npc and pd.npc.name) or "Unknown Entity"
    local nSpell = (pd.npc and pd.npc.spell) or "Combat Strike"
    local nDmg = tonumber((pd.npc and pd.npc.damage) or 0) or 0
    local nId = tonumber((pd.npc and pd.npc.id) or 0) or 0

    local vName = (pd.victim and pd.victim.name) or "Unknown"
    local vClass = (pd.victim and pd.victim.class) or "WARRIOR"
    local vLevel = tonumber((pd.victim and pd.victim.level) or 0) or 0
    local vGuild = (pd.victim and pd.victim.guild) or "None"
    local vFaction = (pd.victim and pd.victim.faction) or "Unknown"

    local zName = (pd.location and pd.location.zone) or "Azeroth"
    local subZone = (pd.location and pd.location.subZone) or ""
    local ts = pd.timestamp or time()
    local dId = pd.deathId or "PVE-DEATH"

    -- Executioner Monster Card (Left)
    m.KillerCard.Icon:SetTexture("Interface\\Icons\\INV_Misc_MonsterHead_02")
    m.KillerCard.Icon:SetTexCoord(0, 1, 0, 1)
    m.KillerCard.Name:SetText(string.format("|cffff5533%s|r", nName))
    m.KillerCard.Info:SetText(string.format(
        "Wilderness Executioner\nStrike: %s\nFatal Damage: %s\nCreature ID: %s",
        nSpell,
        (nDmg > 0) and (KB.Utils and KB.Utils.FormatNumber and KB.Utils.FormatNumber(nDmg) or tostring(nDmg)) or "Lethal",
        (nId > 0) and tostring(nId) or "World Hazard"
    ))

    -- Victim Card (Right)
    local vCoords = CLASS_COORDS[(vClass or ""):upper()] or {0, 0.25, 0, 0.25}
    m.VictimCard.Icon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
    m.VictimCard.Icon:SetTexCoord(vCoords[1], vCoords[2], vCoords[3], vCoords[4])
    local colorName = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(vName, vClass) or vName
    m.VictimCard.Name:SetText(colorName)
    local vLvlStr = (vLevel > 0) and tostring(vLevel) or "??"
    local vGuildStr = (vGuild and vGuild ~= "None") and ("<" .. vGuild .. ">") or "Guildless"
    m.VictimCard.Info:SetText(string.format(
        "Level %s %s\n%s\nCasualty Status: Slain\nFaction: %s",
        vLvlStr, vClass or "UNKNOWN", vGuildStr, vFaction or "Unknown"
    ))

    -- Details Text
    local subzoneStr = (subZone ~= "") and (" (" .. subZone .. ")") or ""
    local timeAgoStr = KB.Utils and KB.Utils.FormatTimeAgo and KB.Utils.FormatTimeAgo(ts) or "Recently"
    local gpsStr = ""
    if pd.location and pd.location.x and pd.location.x > 0 then
        gpsStr = string.format("  (GPS: %.1f, %.1f | MapID: %s)", pd.location.x, pd.location.y, tostring(pd.location.mapId or 0))
    end
    local dmgStr = (nDmg > 0) and (KB.Utils and KB.Utils.FormatNumber and KB.Utils.FormatNumber(nDmg) or tostring(nDmg)) or "Lethal"

    m.DetailsText:SetText(string.format(
        "|cffffd100Engagement:|r |cffff4444Wilderness PvE Casualty|r  |  |cffef4444Fatal Strike: %s (%s dmg)|r\n" ..
        "|cffffd100Location:|r %s%s%s\n" ..
        "|cffffd100Timestamp:|r %s  (|cff888888%s|r)\n" ..
        "|cffffd100Casualty Record ID:|r %s",
        nSpell, dmgStr, zName, subzoneStr, gpsStr,
        date("%Y-%m-%d %H:%M:%S", ts), timeAgoStr, dId
    ))

    UI:ApplyTheme()

    local vFac = (vFaction or ""):lower()
    if vFac == "" and vClass then
        local cls = vClass:upper()
        if cls == "PALADIN" then vFac = "alliance"
        elseif cls == "SHAMAN" then vFac = "horde" end
    end
    if vFac == "alliance" then
        m.VictimCard:SetBackdropColor(0.04, 0.08, 0.16, 0.96)
        m.VictimCard:SetBackdropBorderColor(0.22, 0.52, 0.88, 0.95)
    elseif vFac == "horde" then
        m.VictimCard:SetBackdropColor(0.16, 0.04, 0.04, 0.96)
        m.VictimCard:SetBackdropBorderColor(0.85, 0.24, 0.20, 0.95)
    end
    m.KillerCard:SetBackdropColor(0.16, 0.05, 0.04, 0.96)
    m.KillerCard:SetBackdropBorderColor(0.85, 0.35, 0.15, 0.95)

    m:Show()
    if m.Raise then m:Raise() end
end

function UI:RenderLeaderboard()
    local activeMode = (WoWKillboardDB and WoWKillboardDB.combatFilter) or currentMode or "WORLD"
    currentMode = activeMode
    local theme = UI:GetTheme()
    local aR, aG, aB = WoWKB.AccentColor()

    local cWidth = (UI.ContentFrame and UI.ContentFrame:GetWidth()) or 620

    -- Flat Section Header (18px height, #181818 background, 1px border)
    local headerBar = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    headerBar:SetSize(cWidth, 18)
    headerBar:SetPoint("TOPLEFT", 0, -4)
    headerBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    headerBar:SetBackdropColor(24/255, 24/255, 24/255, 1.0) -- #181818
    headerBar:SetBackdropBorderColor(0, 0, 0, 1.0)

    local headerTitle = headerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    headerTitle:SetPoint("LEFT", headerBar, "LEFT", 8, 0)
    headerTitle:SetTextColor(aR, aG, aB, 1.0)
    headerTitle:SetText("PVP LEADERBOARDS")
    if headerTitle.SetFont then local f, s = headerTitle:GetFont(); headerTitle:SetFont(f, s or 10, "OUTLINE") end
    headerTitle:SetShadowOffset(0, 0)

    -- Sub-navigation Pills: [Players] | [Guilds] | [Last 24 Hours]
    local function CreatePill(parent, x, w, text, isActive, onClick)
        local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
        btn:SetSize(w, 20)
        btn:SetPoint("TOPLEFT", x, -28)
        btn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        if isActive then
            btn:SetBackdropColor(0.20, 0.20, 0.20, 1.0)
            btn:SetBackdropBorderColor(aR, aG, aB, 1.0)
        else
            btn:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
            btn:SetBackdropBorderColor(0, 0, 0, 1.0)
        end
        local lbl = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        lbl:SetPoint("CENTER", 0, 0)
        if isActive then
            lbl:SetTextColor(aR, aG, aB, 1.0)
        else
            lbl:SetTextColor(136/255, 136/255, 136/255, 1.0)
        end
        lbl:SetText(text)
        if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
        lbl:SetShadowOffset(0, 0)
        btn.Label = lbl

        btn:SetScript("OnClick", onClick)
        btn:SetScript("OnEnter", function(self)
            if not isActive then
                self:SetBackdropColor(38/255, 38/255, 38/255, 1.0)
                self.Label:SetTextColor(1.0, 1.0, 1.0, 1.0)
            end
        end)
        btn:SetScript("OnLeave", function(self)
            if not isActive then
                self:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
                self.Label:SetTextColor(136/255, 136/255, 136/255, 1.0)
            end
        end)
        return btn
    end

    CreatePill(UI.ContentFrame, 0, 80, "Players", hlSubTab == "PLAYERS", function()
        hlSubTab = "PLAYERS"
        UI:Refresh()
    end)
    CreatePill(UI.ContentFrame, 86, 74, "Guilds", hlSubTab == "GUILDS", function()
        hlSubTab = "GUILDS"
        UI:Refresh()
    end)
    CreatePill(UI.ContentFrame, 166, 106, "Last 24 Hours", hlSubTab == "GANKERS_24H", function()
        hlSubTab = "GANKERS_24H"
        UI:Refresh()
    end)

    -- Compact Share Button on Right
    local shareBtn = CreateFrame("Button", nil, UI.ContentFrame, "BackdropTemplate")
    shareBtn:SetSize(60, 20)
    shareBtn:SetPoint("TOPRIGHT", 0, -28)
    shareBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    shareBtn:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
    shareBtn:SetBackdropBorderColor(0, 0, 0, 1.0)
    local shareLbl = shareBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    shareLbl:SetPoint("CENTER", 0, 0)
    shareLbl:SetTextColor(136/255, 136/255, 136/255, 1.0)
    shareLbl:SetText("Share")
    if shareLbl.SetFont then local f, s = shareLbl:GetFont(); shareLbl:SetFont(f, s or 10, "OUTLINE") end
    shareLbl:SetShadowOffset(0, 0)
    shareBtn.Label = shareLbl
    shareBtn:SetScript("OnClick", function()
        if hlSubTab == "PLAYERS" then
            UI:ShareChampionsToChat()
        elseif hlSubTab == "GUILDS" then
            UI:ShareGuildsToChat()
        else
            UI:ShareGankersToChat()
        end
    end)
    shareBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(38/255, 38/255, 38/255, 1.0)
        self.Label:SetTextColor(1.0, 1.0, 1.0, 1.0)
        local tipTitle = (hlSubTab == "PLAYERS") and "Share Champions" or ((hlSubTab == "GUILDS") and "Share Guilds" or "Share Gankers")
        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, tipTitle, "Broadcasts realm rankings to group or guild chat.")
    end)
    shareBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
        self.Label:SetTextColor(136/255, 136/255, 136/255, 1.0)
        UI:HidePrivateTooltip()
    end)

    local yOffset = -54

    local function CreateColHeader(labels)
        local colHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        colHeader:SetSize(cWidth, 18)
        colHeader:SetPoint("TOPLEFT", 0, yOffset)
        colHeader:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        colHeader:SetBackdropColor(22/255, 22/255, 22/255, 1.0) -- #161616
        colHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

        for _, col in ipairs(labels) do
            local lbl = colHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            lbl:SetPoint("LEFT", colHeader, "LEFT", col.x, 0)
            if col.w then lbl:SetWidth(col.w) end
            if col.rightAnchor then lbl:SetPoint("RIGHT", colHeader, "RIGHT", col.rightAnchor, 0) end
            lbl:SetJustifyH(col.justify or "LEFT")
            lbl:SetTextColor(119/255, 119/255, 119/255, 1.0) -- #777777
            lbl:SetText(col.text)
            if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
            lbl:SetShadowOffset(0, 0)
        end
        yOffset = yOffset - 20
    end

    if hlSubTab == "PLAYERS" then
        CreateColHeader({
            { x = 6, w = 34, text = "RANK" },
            { x = 44, w = 135, text = "PLAYER" },
            { x = 184, w = 115, text = "GUILD" },
            { x = 304, w = 60, text = "FACTION" },
            { x = 370, w = 45, text = "KILLS" },
            { x = 422, w = 55, text = "SOLO KILLS" },
            { x = 485, rightAnchor = -8, text = "PERCENTILE" },
        })

        local topKillers = KB.Leaderboard:GetTopKillers(currentMode, 25)
        if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
            local q = UI.activeSearchQuery
            local filtered = {}
            for _, p in ipairs(topKillers) do
                local pN = (p.name or ""):lower()
                local pG = (p.guild or ""):lower()
                local pC = (p.class or ""):lower()
                local pF = (p.faction or ""):lower()
                if pN:find(q, 1, true) or pG:find(q, 1, true) or pC:find(q, 1, true) or pF:find(q, 1, true) then
                    table.insert(filtered, p)
                end
            end
            topKillers = filtered
        end

        local pName = UnitName("player")
        local pRank, pStats, totalPlayers = KB.Leaderboard:GetPlayerRankAndStats(pName, currentMode)
        local myClass = select(2, UnitClass("player")) or "WARRIOR"
        local myGuild = GetGuildInfo("player") or "-"
        local myFaction = UnitFactionGroup("player") or "Alliance"

        -- Sticky Top Row: Your Standing (#1E1A10 fill, WoWKB.AccentColor 1px border)
        local stickyRow = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        stickyRow:SetSize(cWidth, 24)
        stickyRow:SetPoint("TOPLEFT", 0, yOffset)
        stickyRow:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        stickyRow:SetBackdropColor(30/255, 26/255, 16/255, 1.0) -- #1E1A10
        stickyRow:SetBackdropBorderColor(0, 0, 0, 1.0)

        local sRank = stickyRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sRank:SetPoint("LEFT", stickyRow, "LEFT", 6, 0)
        sRank:SetWidth(34)
        sRank:SetJustifyH("LEFT")
        sRank:SetTextColor(aR, aG, aB, 1.0)
        sRank:SetText((pRank and pRank > 0) and string.format("#%d", pRank) or "#-")
        if sRank.SetFont then local f, s = sRank:GetFont(); sRank:SetFont(f, s or 10, "OUTLINE") end
        sRank:SetShadowOffset(0, 0)

        local sIconFrame = CreateFrame("Frame", nil, stickyRow, "BackdropTemplate")
        sIconFrame:SetSize(16, 16)
        sIconFrame:SetPoint("LEFT", stickyRow, "LEFT", 44, 0)
        sIconFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        sIconFrame:SetBackdropColor(0, 0, 0, 1.0)
        sIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)
        local sIcon = UI:CreateClassIcon(sIconFrame, myClass, 16)
        sIcon:SetAllPoints(sIconFrame)

        local sName = stickyRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sName:SetPoint("LEFT", sIconFrame, "RIGHT", 4, 0)
        sName:SetPoint("RIGHT", stickyRow, "LEFT", 180, 0)
        sName:SetJustifyH("LEFT")
        sName:SetWordWrap(false)
        sName:SetText(KB.Utils.ColorizeByClass(pName or "Player", myClass) .. " |cffffd100[YOU]|r")
        if sName.SetFont then local f, s = sName:GetFont(); sName:SetFont(f, s or 10, "OUTLINE") end
        sName:SetShadowOffset(0, 0)

        local sGuild = stickyRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sGuild:SetPoint("LEFT", stickyRow, "LEFT", 184, 0)
        sGuild:SetWidth(115)
        sGuild:SetJustifyH("LEFT")
        sGuild:SetWordWrap(false)
        sGuild:SetTextColor(136/255, 136/255, 136/255, 1.0)
        sGuild:SetText((myGuild and myGuild ~= "" and myGuild ~= "None" and myGuild ~= "-") and string.format("<%s>", myGuild) or "-")
        if sGuild.SetFont then local f, s = sGuild:GetFont(); sGuild:SetFont(f, s or 10, "OUTLINE") end
        sGuild:SetShadowOffset(0, 0)

        local sFactionBadge = CreateFactionBadge(stickyRow, myFaction, 60, 16)
        sFactionBadge:SetPoint("LEFT", stickyRow, "LEFT", 304, 0)
        ApplyPlayerRowHighlight(stickyRow, myFaction)

        local sKills = stickyRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sKills:SetPoint("LEFT", stickyRow, "LEFT", 370, 0)
        sKills:SetWidth(45)
        sKills:SetJustifyH("LEFT")
        sKills:SetTextColor(1.0, 1.0, 1.0, 1.0)
        sKills:SetText(tostring((pStats and pStats.kills) or 0))
        if sKills.SetFont then local f, s = sKills:GetFont(); sKills:SetFont(f, s or 10, "OUTLINE") end
        sKills:SetShadowOffset(0, 0)

        local sSolo = stickyRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sSolo:SetPoint("LEFT", stickyRow, "LEFT", 422, 0)
        sSolo:SetWidth(55)
        sSolo:SetJustifyH("LEFT")
        sSolo:SetTextColor(74/255, 222/255, 128/255, 1.0) -- #4ADE80
        sSolo:SetText(tostring((pStats and pStats.soloKills) or 0))
        if sSolo.SetFont then local f, s = sSolo:GetFont(); sSolo:SetFont(f, s or 10, "OUTLINE") end
        sSolo:SetShadowOffset(0, 0)

        local sPct = stickyRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sPct:SetPoint("LEFT", stickyRow, "LEFT", 485, 0)
        sPct:SetPoint("RIGHT", stickyRow, "RIGHT", -8, 0)
        sPct:SetJustifyH("LEFT")
        sPct:SetTextColor(136/255, 136/255, 136/255, 1.0)
        local myPctStr = "Top 50%"
        if (pRank and pRank == 1) or (totalPlayers and totalPlayers <= 1 and pStats and pStats.kills and pStats.kills > 0) then
            myPctStr = "Top 0.1%"
        elseif not pRank or pRank == 0 then
            myPctStr = "Unranked"
        else
            local pct = ((pRank - 0.5) / math.max(1, totalPlayers or 1)) * 100
            myPctStr = string.format("Top %.1f%%", math.max(0.1, pct))
        end
        sPct:SetText(myPctStr)
        if sPct.SetFont then local f, s = sPct:GetFont(); sPct:SetFont(f, s or 10, "OUTLINE") end
        sPct:SetShadowOffset(0, 0)

        yOffset = yOffset - 26

        if #topKillers == 0 then
            local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            empty:SetPoint("TOPLEFT", 8, yOffset - 4)
            empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
            empty:SetText("No player combat records logged for this filter mode yet.")
            if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
            empty:SetShadowOffset(0, 0)
            yOffset = yOffset - 26
        else
            for idx, p in ipairs(topKillers) do
                local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
                row:SetSize(cWidth, 24)
                row:SetPoint("TOPLEFT", 0, yOffset)
                local isEven = (idx % 2 == 0)
                local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

                row:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(unpack(rowBg))
                row:SetBackdropBorderColor(0, 0, 0, 1.0)

                local div = row:CreateTexture(nil, "OVERLAY")
                div:SetPoint("BOTTOMLEFT", 0, 0)
                div:SetPoint("BOTTOMRIGHT", 0, 0)
                div:SetHeight(1)
                div:SetColorTexture(0, 0, 0, 1.0)

                -- Rank: WoWKB.AccentColor
                local rFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                rFs:SetPoint("LEFT", row, "LEFT", 6, 0)
                rFs:SetWidth(34)
                rFs:SetJustifyH("LEFT")
                rFs:SetTextColor(aR, aG, aB, 1.0)
                rFs:SetText(string.format("#%d", idx))
                if rFs.SetFont then local f, s = rFs:GetFont(); rFs:SetFont(f, s or 10, "OUTLINE") end
                rFs:SetShadowOffset(0, 0)

                -- Player: [Class Icon 16x16, 1px border] Name (Class Color)
                local pIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
                pIconFrame:SetSize(16, 16)
                pIconFrame:SetPoint("LEFT", row, "LEFT", 44, 0)
                pIconFrame:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                pIconFrame:SetBackdropColor(0, 0, 0, 1.0)
                pIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)
                local pIcon = UI:CreateClassIcon(pIconFrame, p.class or "WARRIOR", 16)
                pIcon:SetAllPoints(pIconFrame)

                local isLocalPlayer = pName and (p.name:lower() == pName:lower())
                local pNameStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                pNameStr:SetPoint("LEFT", pIconFrame, "RIGHT", 4, 0)
                pNameStr:SetPoint("RIGHT", row, "LEFT", 180, 0)
                pNameStr:SetJustifyH("LEFT")
                pNameStr:SetWordWrap(false)
                local pDisplayName = KB.Utils.ColorizeByClass(p.name or "Unknown", p.class or "WARRIOR")
                if isLocalPlayer then
                    pDisplayName = pDisplayName .. " |cffffd100[YOU]|r"
                end
                pNameStr:SetText(pDisplayName)
                if pNameStr.SetFont then local f, s = pNameStr:GetFont(); pNameStr:SetFont(f, s or 10, "OUTLINE") end
                pNameStr:SetShadowOffset(0, 0)

                -- Guild: <Guild> (#888888)
                local gFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                gFs:SetPoint("LEFT", row, "LEFT", 184, 0)
                gFs:SetWidth(115)
                gFs:SetJustifyH("LEFT")
                gFs:SetWordWrap(false)
                gFs:SetTextColor(136/255, 136/255, 136/255, 1.0)
                gFs:SetText((p.guild and p.guild ~= "" and p.guild ~= "None") and string.format("<%s>", p.guild) or "-")
                if gFs.SetFont then local f, s = gFs:GetFont(); gFs:SetFont(f, s or 10, "OUTLINE") end
                gFs:SetShadowOffset(0, 0)

                -- Faction: Alliance (Blue) / Horde (Red) Badge
                local fBadge = CreateFactionBadge(row, p.faction, 60, 16)
                fBadge:SetPoint("LEFT", row, "LEFT", 304, 0)

                if isLocalPlayer then
                    ApplyPlayerRowHighlight(row, p.faction)
                end

                -- Kills: White #FFFFFF
                local kFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                kFs:SetPoint("LEFT", row, "LEFT", 370, 0)
                kFs:SetWidth(45)
                kFs:SetJustifyH("LEFT")
                kFs:SetTextColor(1.0, 1.0, 1.0, 1.0)
                kFs:SetText(tostring(p.kills or 0))
                if kFs.SetFont then local f, s = kFs:GetFont(); kFs:SetFont(f, s or 10, "OUTLINE") end
                kFs:SetShadowOffset(0, 0)

                -- Solo Kills: Green #4ADE80
                local sKFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                sKFs:SetPoint("LEFT", row, "LEFT", 422, 0)
                sKFs:SetWidth(55)
                sKFs:SetJustifyH("LEFT")
                sKFs:SetTextColor(74/255, 222/255, 128/255, 1.0)
                sKFs:SetText(tostring(p.soloKills or 0))
                if sKFs.SetFont then local f, s = sKFs:GetFont(); sKFs:SetFont(f, s or 10, "OUTLINE") end
                sKFs:SetShadowOffset(0, 0)

                -- Percentile: #888888
                local pctFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                pctFs:SetPoint("LEFT", row, "LEFT", 485, 0)
                pctFs:SetPoint("RIGHT", row, "RIGHT", -8, 0)
                pctFs:SetJustifyH("LEFT")
                pctFs:SetTextColor(136/255, 136/255, 136/255, 1.0)
                local rowPctStr = "Top 50%"
                if idx == 1 or totalPlayers <= 1 then
                    rowPctStr = "Top 0.1%"
                else
                    local pct = ((idx - 0.5) / math.max(1, totalPlayers)) * 100
                    rowPctStr = string.format("Top %.1f%%", math.max(0.1, pct))
                end
                pctFs:SetText(rowPctStr)
                if pctFs.SetFont then local f, s = pctFs:GetFont(); pctFs:SetFont(f, s or 10, "OUTLINE") end
                pctFs:SetShadowOffset(0, 0)

                row:EnableMouse(true)
                row:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
                end)
                row:SetScript("OnLeave", function(self)
                    self:SetBackdropBorderColor(0, 0, 0, 1.0)
                    self:SetBackdropColor(unpack(rowBg))
                end)

                yOffset = yOffset - 24
            end
        end

    elseif hlSubTab == "GUILDS" then
        CreateColHeader({
            { x = 8, w = 40, text = "RANK" },
            { x = 52, w = 240, text = "GUILD" },
            { x = 300, w = 110, text = "FACTION" },
            { x = 430, rightAnchor = -8, text = "KILLS", justify = "LEFT" },
        })

        local topGuilds = KB.Leaderboard:GetTopGuilds(currentMode, 25)
        if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
            local q = UI.activeSearchQuery
            local filtered = {}
            for _, g in ipairs(topGuilds) do
                local gN = (g.guild or ""):lower()
                local gF = (g.faction or ""):lower()
                if gN:find(q, 1, true) or gF:find(q, 1, true) then
                    table.insert(filtered, g)
                end
            end
            topGuilds = filtered
        end

        local myGuild = GetGuildInfo("player")
        local gRank, gStats = KB.Leaderboard:GetGuildRankAndStats(myGuild, currentMode)
        local myFaction = UnitFactionGroup("player") or "Alliance"

        if myGuild and myGuild ~= "" and myGuild ~= "None" then
            local stickyGuild = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
            stickyGuild:SetSize(cWidth, 24)
            stickyGuild:SetPoint("TOPLEFT", 0, yOffset)
            stickyGuild:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            stickyGuild:SetBackdropColor(30/255, 26/255, 16/255, 1.0)
            stickyGuild:SetBackdropBorderColor(0, 0, 0, 1.0)

            local rFs = stickyGuild:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            rFs:SetPoint("LEFT", stickyGuild, "LEFT", 8, 0)
            rFs:SetWidth(40)
            rFs:SetJustifyH("LEFT")
            rFs:SetTextColor(aR, aG, aB, 1.0)
            rFs:SetText((gRank and gRank > 0) and string.format("#%d", gRank) or "#-")
            if rFs.SetFont then local f, s = rFs:GetFont(); rFs:SetFont(f, s or 10, "OUTLINE") end
            rFs:SetShadowOffset(0, 0)

            local gFs = stickyGuild:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            gFs:SetPoint("LEFT", stickyGuild, "LEFT", 52, 0)
            gFs:SetWidth(240)
            gFs:SetJustifyH("LEFT")
            gFs:SetWordWrap(false)
            gFs:SetText(string.format("|cffffd700<%s>|r |cffffd100[YOUR GUILD]|r", myGuild))
            if gFs.SetFont then local f, s = gFs:GetFont(); gFs:SetFont(f, s or 10, "OUTLINE") end
            gFs:SetShadowOffset(0, 0)

            local fBadge = CreateFactionBadge(stickyGuild, myFaction, 70, 16)
            fBadge:SetPoint("LEFT", stickyGuild, "LEFT", 300, 0)
            ApplyPlayerRowHighlight(stickyGuild, myFaction)

            local kFs = stickyGuild:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            kFs:SetPoint("LEFT", stickyGuild, "LEFT", 430, 0)
            kFs:SetTextColor(1.0, 1.0, 1.0, 1.0)
            kFs:SetText(string.format("%d Kills", (gStats and gStats.kills) or 0))
            if kFs.SetFont then local f, s = kFs:GetFont(); kFs:SetFont(f, s or 10, "OUTLINE") end
            kFs:SetShadowOffset(0, 0)

            yOffset = yOffset - 26
        end

        if #topGuilds == 0 then
            local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            empty:SetPoint("TOPLEFT", 8, yOffset - 4)
            empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
            empty:SetText("No guild PvP records logged for this filter mode yet.")
            if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
            empty:SetShadowOffset(0, 0)
            yOffset = yOffset - 26
        else
            for idx, g in ipairs(topGuilds) do
                local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
                row:SetSize(cWidth, 24)
                row:SetPoint("TOPLEFT", 0, yOffset)
                local isEven = (idx % 2 == 0)
                local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

                row:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(unpack(rowBg))
                row:SetBackdropBorderColor(0, 0, 0, 1.0)

                local div = row:CreateTexture(nil, "OVERLAY")
                div:SetPoint("BOTTOMLEFT", 0, 0)
                div:SetPoint("BOTTOMRIGHT", 0, 0)
                div:SetHeight(1)
                div:SetColorTexture(0, 0, 0, 1.0)

                local rFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                rFs:SetPoint("LEFT", row, "LEFT", 8, 0)
                rFs:SetWidth(40)
                rFs:SetJustifyH("LEFT")
                rFs:SetTextColor(aR, aG, aB, 1.0)
                rFs:SetText(string.format("#%d", idx))
                if rFs.SetFont then local f, s = rFs:GetFont(); rFs:SetFont(f, s or 10, "OUTLINE") end
                rFs:SetShadowOffset(0, 0)

                local isMyGuild = myGuild and myGuild ~= "" and myGuild ~= "None" and (g.guild:lower() == myGuild:lower())
                local gFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                gFs:SetPoint("LEFT", row, "LEFT", 52, 0)
                gFs:SetWidth(240)
                gFs:SetJustifyH("LEFT")
                gFs:SetWordWrap(false)
                local guildDisplayName = string.format("<%s>", g.guild or "Unknown")
                if isMyGuild then
                    guildDisplayName = guildDisplayName .. " |cffffd100[YOUR GUILD]|r"
                end
                gFs:SetTextColor(1.0, 0.84, 0.0, 1.0)
                gFs:SetText(guildDisplayName)
                if gFs.SetFont then local f, s = gFs:GetFont(); gFs:SetFont(f, s or 10, "OUTLINE") end
                gFs:SetShadowOffset(0, 0)

                local fBadge = CreateFactionBadge(row, g.faction, 70, 16)
                fBadge:SetPoint("LEFT", row, "LEFT", 300, 0)

                if isMyGuild then
                    ApplyPlayerRowHighlight(row, g.faction)
                end

                local kFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                kFs:SetPoint("LEFT", row, "LEFT", 430, 0)
                kFs:SetTextColor(1.0, 1.0, 1.0, 1.0)
                kFs:SetText(string.format("%d Kills", g.kills or 0))
                if kFs.SetFont then local f, s = kFs:GetFont(); kFs:SetFont(f, s or 10, "OUTLINE") end
                kFs:SetShadowOffset(0, 0)

                row:EnableMouse(true)
                row:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
                end)
                row:SetScript("OnLeave", function(self)
                    self:SetBackdropBorderColor(0, 0, 0, 1.0)
                    self:SetBackdropColor(unpack(rowBg))
                end)

                yOffset = yOffset - 24
            end
        end

    elseif hlSubTab == "GANKERS_24H" then
        CreateColHeader({
            { x = 8, w = 40, text = "RANK" },
            { x = 52, w = 220, text = "PLAYER" },
            { x = 276, w = 100, text = "FACTION" },
            { x = 380, w = 180, text = "GUILD" },
            { x = 570, rightAnchor = -8, text = "24H KILLS", justify = "LEFT" },
        })

        local gankers = (WoWKillboard_RealmData and WoWKillboard_RealmData.TopGankers24h) or (WoWKillboardDB and WoWKillboardDB.RealmData and WoWKillboardDB.RealmData.TopGankers24h) or {}
        if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
            local q = UI.activeSearchQuery
            local filtered = {}
            for _, gk in ipairs(gankers) do
                local gkN = (gk.name or ""):lower()
                local gkC = (gk.class or ""):lower()
                local gkZ = (gk.zone or ""):lower()
                local gkG = (gk.guild or ""):lower()
                if gkN:find(q, 1, true) or gkC:find(q, 1, true) or gkZ:find(q, 1, true) or gkG:find(q, 1, true) then
                    table.insert(filtered, gk)
                end
            end
            gankers = filtered
        end

        if #gankers == 0 then
            local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            empty:SetPoint("TOPLEFT", 8, yOffset - 4)
            empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
            empty:SetText("No active gankers recorded in the last 24 hours. Sync data to refresh.")
            if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
            empty:SetShadowOffset(0, 0)
            yOffset = yOffset - 26
        else
            for idx, g in ipairs(gankers) do
                local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
                row:SetSize(cWidth, 24)
                row:SetPoint("TOPLEFT", 0, yOffset)
                local isEven = (idx % 2 == 0)
                local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

                row:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(unpack(rowBg))
                row:SetBackdropBorderColor(0, 0, 0, 1.0)

                local div = row:CreateTexture(nil, "OVERLAY")
                div:SetPoint("BOTTOMLEFT", 0, 0)
                div:SetPoint("BOTTOMRIGHT", 0, 0)
                div:SetHeight(1)
                div:SetColorTexture(0, 0, 0, 1.0)

                local rLabel = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                rLabel:SetPoint("LEFT", row, "LEFT", 8, 0)
                rLabel:SetWidth(40)
                rLabel:SetJustifyH("LEFT")
                rLabel:SetTextColor(aR, aG, aB, 1.0)
                rLabel:SetText(string.format("#%d", idx))
                if rLabel.SetFont then local f, s = rLabel:GetFont(); rLabel:SetFont(f, s or 10, "OUTLINE") end
                rLabel:SetShadowOffset(0, 0)

                local cls = (g.class or "WARRIOR"):upper()
                local cIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
                cIconFrame:SetSize(16, 16)
                cIconFrame:SetPoint("LEFT", row, "LEFT", 52, 0)
                cIconFrame:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                cIconFrame:SetBackdropColor(0, 0, 0, 1.0)
                cIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)
                local cIcon = UI:CreateClassIcon(cIconFrame, cls, 16)
                cIcon:SetAllPoints(cIconFrame)

                local isLocalPlayer = pName and (g.name:lower() == pName:lower())
                local nameTxt = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                nameTxt:SetPoint("LEFT", cIconFrame, "RIGHT", 6, 0)
                nameTxt:SetPoint("RIGHT", row, "LEFT", 272, 0)
                nameTxt:SetJustifyH("LEFT")
                nameTxt:SetWordWrap(false)
                local gDisplayName = KB.Utils.ColorizeByClass(g.name or "Unknown", cls)
                if isLocalPlayer then
                    gDisplayName = gDisplayName .. " |cffffd100[YOU]|r"
                end
                nameTxt:SetText(gDisplayName)
                if nameTxt.SetFont then local f, s = nameTxt:GetFont(); nameTxt:SetFont(f, s or 10, "OUTLINE") end
                nameTxt:SetShadowOffset(0, 0)

                local fac = g.faction or "Alliance"
                local facBadge = CreateFactionBadge(row, fac, 70, 16)
                facBadge:SetPoint("LEFT", row, "LEFT", 276, 0)

                if isLocalPlayer then
                    ApplyPlayerRowHighlight(row, fac)
                end

                local gldTxt = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                gldTxt:SetPoint("LEFT", row, "LEFT", 380, 0)
                gldTxt:SetWidth(180)
                gldTxt:SetJustifyH("LEFT")
                gldTxt:SetWordWrap(false)
                local gld = (g.guild and g.guild ~= "" and g.guild ~= "None") and string.format("<%s>", g.guild) or "-"
                gldTxt:SetTextColor(136/255, 136/255, 136/255, 1.0)
                gldTxt:SetText(gld)
                if gldTxt.SetFont then local f, s = gldTxt:GetFont(); gldTxt:SetFont(f, s or 10, "OUTLINE") end
                gldTxt:SetShadowOffset(0, 0)

                local killsTxt = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                killsTxt:SetPoint("LEFT", row, "LEFT", 570, 0)
                killsTxt:SetTextColor(1.0, 56/255, 56/255, 1.0) -- #FF3838
                killsTxt:SetText(string.format("%d Kills", g.kills or 0))
                if killsTxt.SetFont then local f, s = killsTxt:GetFont(); killsTxt:SetFont(f, s or 10, "OUTLINE") end
                killsTxt:SetShadowOffset(0, 0)

                row:EnableMouse(true)
                row:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
                end)
                row:SetScript("OnLeave", function(self)
                    self:SetBackdropBorderColor(0, 0, 0, 1.0)
                    self:SetBackdropColor(unpack(rowBg))
                end)

                yOffset = yOffset - 24
            end
        end
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
end

-- 3. Render Bounties & Debt Ledger (ACTIVE BOUNTIES)
function UI:RenderBounties()
    local theme = UI:GetTheme()
    local aR, aG, aB = WoWKB.AccentColor()

    local cWidth = (UI.ContentFrame and UI.ContentFrame:GetWidth()) or 620

    -- Flat Section Header (18px height, #181818 background, 1px border)
    local headerBar = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    headerBar:SetSize(cWidth, 18)
    headerBar:SetPoint("TOPLEFT", 0, -4)
    headerBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    headerBar:SetBackdropColor(24/255, 24/255, 24/255, 1.0) -- #181818
    headerBar:SetBackdropBorderColor(0, 0, 0, 1.0)

    local headerTitle = headerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    headerTitle:SetPoint("LEFT", headerBar, "LEFT", 8, 0)
    headerTitle:SetTextColor(aR, aG, aB, 1.0)
    headerTitle:SetText("ACTIVE BOUNTIES")
    if headerTitle.SetFont then local f, s = headerTitle:GetFont(); headerTitle:SetFont(f, s or 10, "OUTLINE") end
    headerTitle:SetShadowOffset(0, 0)

    -- Compact Share Button on Right (Bounties can only be declared upon open-world death prompt)
    local shareBtn = CreateFrame("Button", nil, UI.ContentFrame, "BackdropTemplate")
    shareBtn:SetSize(60, 20)
    shareBtn:SetPoint("TOPRIGHT", 0, -28)
    shareBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    shareBtn:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
    shareBtn:SetBackdropBorderColor(0, 0, 0, 1.0)
    local shareLbl = shareBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    shareLbl:SetPoint("CENTER", 0, 0)
    shareLbl:SetTextColor(136/255, 136/255, 136/255, 1.0)
    shareLbl:SetText("Share")
    if shareLbl.SetFont then local f, s = shareLbl:GetFont(); shareLbl:SetFont(f, s or 10, "OUTLINE") end
    shareLbl:SetShadowOffset(0, 0)
    shareBtn.Label = shareLbl
    shareBtn:SetScript("OnClick", function()
        UI:ShareWantedToChat()
    end)
    shareBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(38/255, 38/255, 38/255, 1.0)
        self.Label:SetTextColor(1.0, 1.0, 1.0, 1.0)
        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "Share Bounties", "Broadcasts active bounties to chat.")
    end)
    shareBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
        self.Label:SetTextColor(136/255, 136/255, 136/255, 1.0)
        UI:HidePrivateTooltip()
    end)

    -- Sub-navigation Pills: [Active] | [Hall of Fame] | [Debts]
    local function CreatePill(parent, x, w, text, isActive, onClick)
        local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
        btn:SetSize(w, 20)
        btn:SetPoint("TOPLEFT", x, -28)
        btn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        if isActive then
            btn:SetBackdropColor(0.20, 0.20, 0.20, 1.0)
            btn:SetBackdropBorderColor(aR, aG, aB, 1.0)
        else
            btn:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
            btn:SetBackdropBorderColor(0, 0, 0, 1.0)
        end
        local lbl = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        lbl:SetPoint("CENTER", 0, 0)
        if isActive then
            lbl:SetTextColor(aR, aG, aB, 1.0)
        else
            lbl:SetTextColor(136/255, 136/255, 136/255, 1.0)
        end
        lbl:SetText(text)
        if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
        lbl:SetShadowOffset(0, 0)
        btn.Label = lbl

        btn:SetScript("OnClick", onClick)
        btn:SetScript("OnEnter", function(self)
            if not isActive then
                self:SetBackdropColor(38/255, 38/255, 38/255, 1.0)
                self.Label:SetTextColor(1.0, 1.0, 1.0, 1.0)
            end
        end)
        btn:SetScript("OnLeave", function(self)
            if not isActive then
                self:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
                self.Label:SetTextColor(136/255, 136/255, 136/255, 1.0)
            end
        end)
        return btn
    end

    CreatePill(UI.ContentFrame, 0, 70, "Active", marksSubTab == "ACTIVE", function()
        marksSubTab = "ACTIVE"
        UI:Refresh()
    end)
    CreatePill(UI.ContentFrame, 76, 96, "Hall of Fame", marksSubTab == "RECORDS", function()
        marksSubTab = "RECORDS"
        UI:Refresh()
    end)
    CreatePill(UI.ContentFrame, 178, 64, "Debts", marksSubTab == "DEBTORS", function()
        marksSubTab = "DEBTORS"
        UI:Refresh()
    end)

    local yOffset = -54

    local function CreateColHeader(labels)
        local colHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        colHeader:SetSize(cWidth, 18)
        colHeader:SetPoint("TOPLEFT", 0, yOffset)
        colHeader:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        colHeader:SetBackdropColor(22/255, 22/255, 22/255, 1.0) -- #161616
        colHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

        for _, col in ipairs(labels) do
            local lbl = colHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            lbl:SetPoint("LEFT", colHeader, "LEFT", col.x, 0)
            if col.w then lbl:SetWidth(col.w) end
            if col.rightAnchor then lbl:SetPoint("RIGHT", colHeader, "RIGHT", col.rightAnchor, 0) end
            lbl:SetJustifyH(col.justify or "LEFT")
            lbl:SetTextColor(119/255, 119/255, 119/255, 1.0) -- #777777
            lbl:SetText(col.text)
            if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
            lbl:SetShadowOffset(0, 0)
        end
        yOffset = yOffset - 20
    end

    if marksSubTab == "ACTIVE" then
        CreateColHeader({
            { x = 8, w = 150, text = "TARGET" },
            { x = 164, w = 110, text = "BOUNTY / REWARD" },
            { x = 280, w = 100, text = "ISSUED BY" },
            { x = 386, w = 145, text = "ZONE / LAST SEEN" },
            { x = 538, rightAnchor = -8, text = "ACTION", justify = "RIGHT" },
        })

        if KB.BountyEngine and KB.BountyEngine.InitDB then KB.BountyEngine:InitDB() end
        local bountyMap = {}
        local targetOrder = {}

        local function AddBountyEntry(b)
            if not b or (KB.Leaderboard and not KB.Leaderboard:MatchesRealm(b)) then return end
            local bId = b.id or b.bountyId
            local bStatus = b.status or "ACTIVE"
            local tName = b.targetName or b.target_name
            if (bStatus == "ACTIVE" or bStatus == (KB.STATUS and KB.STATUS.ACTIVE or "ACTIVE")) and bId and tName and tName ~= "" and tName:lower() ~= "unknown" then
                local tKey = tName:lower()
                local copper = tonumber(b.amountCopper or b.amount_copper or 0) or 0
                local gold = tonumber(b.amountGold or b.amount_gold or math.floor(copper / 10000)) or 0
                if copper <= 0 and gold > 0 then copper = gold * 10000 end

                local pName = b.placerName or b.placer_name or "Unknown"

                if not bountyMap[tKey] then
                    bountyMap[tKey] = {
                        targetName = tName,
                        targetClass = b.targetClass or b.target_class or "UNKNOWN",
                        targetFaction = b.targetFaction or b.target_faction or "Unknown",
                        targetGuild = b.targetGuild or b.target_guild or nil,
                        amountCopper = copper,
                        placers = { pName },
                        ids = { bId },
                        bounties = { b },
                        latestTime = b.timestamp or 0,
                    }
                    table.insert(targetOrder, tKey)
                else
                    local entry = bountyMap[tKey]
                    entry.amountCopper = entry.amountCopper + copper
                    table.insert(entry.ids, bId)
                    table.insert(entry.bounties, b)
                    local foundPlacer = false
                    for _, p in ipairs(entry.placers) do
                        if p:lower() == pName:lower() then foundPlacer = true break end
                    end
                    if not foundPlacer then table.insert(entry.placers, pName) end
                    if (b.timestamp or 0) > entry.latestTime then
                        entry.latestTime = b.timestamp or 0
                    end
                    if (not entry.targetGuild or entry.targetGuild == "None") and (b.targetGuild or b.target_guild) then
                        entry.targetGuild = b.targetGuild or b.target_guild
                    end
                    if (entry.targetClass == "UNKNOWN" or not entry.targetClass) and (b.targetClass or b.target_class) then
                        entry.targetClass = b.targetClass or b.target_class
                    end
                    if (entry.targetFaction == "Unknown" or not entry.targetFaction) and (b.targetFaction or b.target_faction) then
                        entry.targetFaction = b.targetFaction or b.target_faction
                    end
                end
            end
        end

        if WoWKillboardBounties then
            for _, b in pairs(WoWKillboardBounties) do
                AddBountyEntry(b)
            end
        end
        local rData = WoWKillboard_RealmData or (WoWKillboardDB and WoWKillboardDB.RealmData)
        if rData and rData.ActiveBounties then
            for _, b in ipairs(rData.ActiveBounties) do
                AddBountyEntry(b)
            end
        end

        local activeList = {}
        for _, key in ipairs(targetOrder) do
            local entry = bountyMap[key]
            local tName = entry.targetName

            -- Enrich missing guild, faction, class from character database
            if WoWKillboardDB and WoWKillboardDB.characters and WoWKillboardDB.characters[tName] then
                local c = WoWKillboardDB.characters[tName]
                if c.guild and c.guild ~= "None" and not entry.targetGuild then entry.targetGuild = c.guild end
                if c.class and entry.targetClass == "UNKNOWN" then entry.targetClass = c.class end
                if c.faction and entry.targetFaction == "Unknown" then entry.targetFaction = c.faction end
            end

            -- Enrich from combat records
            if WoWKillboardDB and WoWKillboardDB.kills and (not entry.targetGuild or entry.targetClass == "UNKNOWN" or entry.targetFaction == "Unknown") then
                for _, km in pairs(WoWKillboardDB.kills) do
                    if km.victim and km.victim.name and km.victim.name:lower() == key then
                        if km.victim.guild and km.victim.guild ~= "None" and not entry.targetGuild then entry.targetGuild = km.victim.guild end
                        if km.victim.class and entry.targetClass == "UNKNOWN" then entry.targetClass = km.victim.class end
                        if km.victim.faction and entry.targetFaction == "Unknown" then entry.targetFaction = km.victim.faction end
                    elseif km.killer and km.killer.name and km.killer.name:lower() == key then
                        if km.killer.guild and km.killer.guild ~= "None" and not entry.targetGuild then entry.targetGuild = km.killer.guild end
                        if km.killer.class and entry.targetClass == "UNKNOWN" then entry.targetClass = km.killer.class end
                        if km.killer.faction and entry.targetFaction == "Unknown" then entry.targetFaction = km.killer.faction end
                    end
                end
            end

            table.insert(activeList, entry)
        end

        table.sort(activeList, function(a, b)
            return (a.amountCopper or 0) > (b.amountCopper or 0)
        end)

        if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
            local q = UI.activeSearchQuery
            local filtered = {}
            for _, b in ipairs(activeList) do
                local tN = (b.targetName or ""):lower()
                local tF = (b.targetFaction or ""):lower()
                local tC = (b.targetClass or ""):lower()
                local tG = (b.targetGuild or ""):lower()
                local matchPlacer = false
                for _, p in ipairs(b.placers or {}) do
                    if p:lower():find(q, 1, true) then matchPlacer = true break end
                end
                if tN:find(q, 1, true) or matchPlacer or tF:find(q, 1, true) or tC:find(q, 1, true) or tG:find(q, 1, true) then
                    table.insert(filtered, b)
                end
            end
            activeList = filtered
        end

        if #activeList == 0 then
            local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            empty:SetPoint("TOPLEFT", 8, yOffset - 4)
            empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
            empty:SetText("No active bounties posted on this realm.")
            if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
            empty:SetShadowOffset(0, 0)
            yOffset = yOffset - 26
        else
            for idx, b in ipairs(activeList) do
                local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
                row:SetSize(cWidth, 34)
                row:SetPoint("TOPLEFT", 0, yOffset)
                local isEven = (idx % 2 == 0)
                local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

                row:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(unpack(rowBg))
                row:SetBackdropBorderColor(0, 0, 0, 1.0)

                local div = row:CreateTexture(nil, "OVERLAY")
                div:SetPoint("BOTTOMLEFT", 0, 0)
                div:SetPoint("BOTTOMRIGHT", 0, 0)
                div:SetHeight(1)
                div:SetColorTexture(0, 0, 0, 1.0)

                local bClass = b.targetClass or "UNKNOWN"
                local tName = b.targetName or "Target"
                local tGuild = b.targetGuild or "No Guild"
                local tFaction = b.targetFaction or "Unknown"
                local copper = b.amountCopper or 0

                -- Col 1 (Target): Class Icon 20x20 + [Line 1: Target Name (Class Color) + Faction Badge] + [Line 2: <Guild>]
                local iconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
                iconFrame:SetSize(22, 22)
                iconFrame:SetPoint("LEFT", row, "LEFT", 8, 0)
                iconFrame:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                iconFrame:SetBackdropColor(0, 0, 0, 1.0)
                iconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)
                local bIcon = UI:CreateClassIcon(iconFrame, bClass, 22)
                bIcon:SetAllPoints(iconFrame)

                local factionBadge = ""
                if tFaction == "Alliance" then
                    factionBadge = " |cff0070de[A]|r"
                elseif tFaction == "Horde" then
                    factionBadge = " |cffc41e3a[H]|r"
                end

                local pName = UnitName and UnitName("player")
                local isLocalPlayer = pName and (tName:lower() == pName:lower())

                local targetStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                targetStr:SetPoint("TOPLEFT", iconFrame, "TOPRIGHT", 8, -1)
                targetStr:SetPoint("RIGHT", row, "LEFT", 160, 0)
                targetStr:SetJustifyH("LEFT")
                targetStr:SetWordWrap(false)
                local targetColored = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(tName, bClass) or string.format("|cffff3838%s|r", tName)
                if isLocalPlayer then
                    targetColored = targetColored .. " |cffffd100[YOU]|r"
                    ApplyPlayerRowHighlight(row, tFaction)
                end
                local classDisplay = (bClass ~= "UNKNOWN") and string.format(" |cff888888(%s)|r", bClass:sub(1,1):upper() .. bClass:sub(2):lower()) or ""
                targetStr:SetText(targetColored .. classDisplay .. factionBadge)
                if targetStr.SetFont then local f, s = targetStr:GetFont(); targetStr:SetFont(f, s or 11, "OUTLINE") end
                targetStr:SetShadowOffset(0, 0)

                local guildStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                guildStr:SetPoint("BOTTOMLEFT", iconFrame, "BOTTOMRIGHT", 8, 1)
                guildStr:SetPoint("RIGHT", row, "LEFT", 160, 0)
                guildStr:SetJustifyH("LEFT")
                guildStr:SetWordWrap(false)
                guildStr:SetTextColor(148/255, 163/255, 184/255, 1.0) -- #94A3B8 Muted Slate
                guildStr:SetText(tGuild ~= "No Guild" and string.format("<%s>", tGuild) or "|cff666666<No Guild>|r")
                if guildStr.SetFont then local f, s = guildStr:GetFont(); guildStr:SetFont(f, (s or 10) - 1, "OUTLINE") end
                guildStr:SetShadowOffset(0, 0)

                -- Col 2 (Bounty / Reward): Gold / Silver / Copper
                local g = math.floor(copper / 10000)
                local s = math.floor((copper % 10000) / 100)
                local c = copper % 100
                local moneyDisplay = string.format("|cffffd100%dg|r |cffe2e8f0%ds|r |cffd97706%dc|r", g, s, c)

                local rewardStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                rewardStr:SetPoint("LEFT", row, "LEFT", 164, 0)
                rewardStr:SetWidth(110)
                rewardStr:SetJustifyH("LEFT")
                rewardStr:SetText(moneyDisplay)
                if rewardStr.SetFont then local f, sz = rewardStr:GetFont(); rewardStr:SetFont(f, sz or 11, "OUTLINE") end
                rewardStr:SetShadowOffset(0, 0)

                -- Col 3 (Issued By): Placers with multi-stack counter
                local pCount = #(b.placers or {})
                local placerText = b.placers and b.placers[1] or "Unknown"
                if pCount > 1 then
                    placerText = string.format("%s |cff00e5ff(+%d)|r", placerText, pCount - 1)
                end

                local placerStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                placerStr:SetPoint("LEFT", row, "LEFT", 280, 0)
                placerStr:SetWidth(100)
                placerStr:SetJustifyH("LEFT")
                placerStr:SetWordWrap(false)
                placerStr:SetTextColor(180/255, 180/255, 180/255, 1.0)
                placerStr:SetText(placerText)
                if placerStr.SetFont then local f, sz = placerStr:GetFont(); placerStr:SetFont(f, sz or 10, "OUTLINE") end
                placerStr:SetShadowOffset(0, 0)

                -- Col 4 (Zone / Last Seen): Zone Name (#D4A359)
                local lastSeenStr = "Azeroth"
                if WoWKillboardDB and WoWKillboardDB.kills then
                    local latestTime = 0
                    local latestZone = nil
                    for _, km in pairs(WoWKillboardDB.kills) do
                        if km.killer and km.victim and (km.killer.name == tName or km.victim.name == tName) then
                            if (km.timestamp or 0) > latestTime then
                                latestTime = km.timestamp
                                latestZone = km.location and km.location.zone
                            end
                        end
                    end
                    if latestZone and latestTime > 0 then
                        local diffMin = math.max(1, math.floor((time() - latestTime) / 60))
                        lastSeenStr = string.format("%s (%dm ago)", latestZone, diffMin)
                    end
                end

                local locStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                locStr:SetPoint("LEFT", row, "LEFT", 386, 0)
                locStr:SetWidth(145)
                locStr:SetJustifyH("LEFT")
                locStr:SetWordWrap(false)
                locStr:SetTextColor(212/255, 163/255, 89/255, 1.0) -- #D4A359
                locStr:SetText(lastSeenStr)
                if locStr.SetFont then local f, sz = locStr:GetFont(); locStr:SetFont(f, sz or 10, "OUTLINE") end
                locStr:SetShadowOffset(0, 0)

                -- Col 5 (Action): Compact Button: Accept or Track
                local ids = b.ids or {}
                local isAccepted = false
                for _, bId in ipairs(ids) do
                    if KB.BountyEngine and KB.BountyEngine.IsBountyAccepted and KB.BountyEngine:IsBountyAccepted(bId) then
                        isAccepted = true
                        break
                    end
                end

                local actionBtn = CreateFrame("Button", nil, row, "BackdropTemplate")
                actionBtn:SetSize(72, 22)
                actionBtn:SetPoint("RIGHT", row, "RIGHT", -8, 0)
                actionBtn:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                actionBtn:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
                actionBtn:SetBackdropBorderColor(0, 0, 0, 1.0)
                local aLbl = actionBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                aLbl:SetPoint("CENTER", 0, 0)
                if isAccepted then
                    aLbl:SetTextColor(74/255, 222/255, 128/255, 1.0)
                    aLbl:SetText("Track")
                    actionBtn:SetBackdropBorderColor(74/255, 222/255, 128/255, 0.6)
                else
                    aLbl:SetTextColor(aR, aG, aB, 1.0)
                    aLbl:SetText("Accept")
                    actionBtn:SetBackdropBorderColor(aR, aG, aB, 0.6)
                end
                if aLbl.SetFont then local f, sz = aLbl:GetFont(); aLbl:SetFont(f, sz or 10, "OUTLINE") end
                aLbl:SetShadowOffset(0, 0)
                actionBtn.Label = aLbl

                if not isAccepted then
                    actionBtn:SetScript("OnClick", function()
                        if KB.BountyEngine and KB.BountyEngine.AcceptBounty then
                            for _, bId in ipairs(ids) do
                                KB.BountyEngine:AcceptBounty(bId)
                            end
                            UI:Refresh()
                        end
                    end)
                end
                actionBtn:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(38/255, 38/255, 38/255, 1.0)
                end)
                actionBtn:SetScript("OnLeave", function(self)
                    self:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
                end)

                row:EnableMouse(true)
                row:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
                    if pCount > 1 then
                        local tipBody = "Declared Placers:\n"
                        for _, p in ipairs(b.placers or {}) do
                            tipBody = tipBody .. string.format(" - |cffffffff%s|r\n", p)
                        end
                        tipBody = tipBody .. string.format("\nTotal Combined Reward: |cffffd100%s|r", KB.Utils.FormatMoney(copper))
                        UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Stacked Marks of Spite|r", tipBody)
                    end
                end)
                row:SetScript("OnLeave", function(self)
                    self:SetBackdropBorderColor(0, 0, 0, 1.0)
                    self:SetBackdropColor(unpack(rowBg))
                    if pCount > 1 then UI:HidePrivateTooltip() end
                end)

                yOffset = yOffset - 36
            end
        end

    elseif marksSubTab == "RECORDS" then
        CreateColHeader({
            { x = 8, w = 40, text = "RANK" },
            { x = 52, w = 240, text = "RECORD HOLDER" },
            { x = 300, rightAnchor = -8, text = "ACHIEVEMENT / REWARD", justify = "LEFT" },
        })

        local records = (KB.BountyEngine and KB.BountyEngine.GetBountyRecords) and KB.BountyEngine:GetBountyRecords() or { topHunters = {}, highestRewards = {}, longestSurviving = {} }

        if not records.topHunters or #records.topHunters == 0 then
            local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            empty:SetPoint("TOPLEFT", 8, yOffset - 4)
            empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
            empty:SetText("No bounty records recorded in realm history.")
            if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
            empty:SetShadowOffset(0, 0)
            yOffset = yOffset - 26
        else
            for idx = 1, math.min(#records.topHunters, 10) do
                local h = records.topHunters[idx]
                local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
                row:SetSize(cWidth, 24)
                row:SetPoint("TOPLEFT", 0, yOffset)
                local isEven = (idx % 2 == 0)
                local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

                row:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(unpack(rowBg))
                row:SetBackdropBorderColor(0, 0, 0, 1.0)

                local div = row:CreateTexture(nil, "OVERLAY")
                div:SetPoint("BOTTOMLEFT", 0, 0)
                div:SetPoint("BOTTOMRIGHT", 0, 0)
                div:SetHeight(1)
                div:SetColorTexture(0, 0, 0, 1.0)

                local rText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                rText:SetPoint("LEFT", row, "LEFT", 8, 0)
                rText:SetWidth(40)
                rText:SetJustifyH("LEFT")
                rText:SetTextColor(aR, aG, aB, 1.0)
                rText:SetText(string.format("#%d", idx))
                if rText.SetFont then local f, s = rText:GetFont(); rText:SetFont(f, s or 10, "OUTLINE") end
                rText:SetShadowOffset(0, 0)

                local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                nameText:SetPoint("LEFT", row, "LEFT", 52, 0)
                nameText:SetWidth(240)
                nameText:SetJustifyH("LEFT")
                nameText:SetWordWrap(false)
                nameText:SetTextColor(1.0, 1.0, 1.0, 1.0)
                nameText:SetText(h.name or "Hunter")
                if nameText.SetFont then local f, s = nameText:GetFont(); nameText:SetFont(f, s or 10, "OUTLINE") end
                nameText:SetShadowOffset(0, 0)

                local countText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                countText:SetPoint("LEFT", row, "LEFT", 300, 0)
                countText:SetTextColor(74/255, 222/255, 128/255, 1.0)
                countText:SetText(string.format("%d Contracts Claimed", h.count or 0))
                if countText.SetFont then local f, s = countText:GetFont(); countText:SetFont(f, s or 10, "OUTLINE") end
                countText:SetShadowOffset(0, 0)

                yOffset = yOffset - 24
            end
        end

    elseif marksSubTab == "DEBTORS" then
        CreateColHeader({
            { x = 8, w = 150, text = "DEBTOR" },
            { x = 164, w = 110, text = "AMOUNT OWED" },
            { x = 280, w = 140, text = "CREDITOR" },
            { x = 426, rightAnchor = -8, text = "STATUS", justify = "LEFT" },
        })

        WoWKillboardDebtLedger = WoWKillboardDebtLedger or {}
        local debtList = {}
        for playerName, debt in pairs(WoWKillboardDebtLedger) do
            if debt.status == (KB.STATUS and KB.STATUS.OATHBREAKER or "OATHBREAKER") then
                table.insert(debtList, { name = playerName, debt = debt })
            end
        end

        if #debtList == 0 then
            local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            empty:SetPoint("TOPLEFT", 8, yOffset - 4)
            empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
            empty:SetText("No defaulted debtors on this realm. All wagers intact.")
            if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
            empty:SetShadowOffset(0, 0)
            yOffset = yOffset - 26
        else
            for idx, item in ipairs(debtList) do
                local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
                row:SetSize(cWidth, 24)
                row:SetPoint("TOPLEFT", 0, yOffset)
                local isEven = (idx % 2 == 0)
                local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

                row:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                    insets = { left = 0, right = 0, top = 0, bottom = 0 }
                })
                row:SetBackdropColor(unpack(rowBg))
                row:SetBackdropBorderColor(0, 0, 0, 1.0)

                local div = row:CreateTexture(nil, "OVERLAY")
                div:SetPoint("BOTTOMLEFT", 0, 0)
                div:SetPoint("BOTTOMRIGHT", 0, 0)
                div:SetHeight(1)
                div:SetColorTexture(0, 0, 0, 1.0)

                local nameStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                nameStr:SetPoint("LEFT", row, "LEFT", 8, 0)
                nameStr:SetWidth(150)
                nameStr:SetJustifyH("LEFT")
                nameStr:SetTextColor(1.0, 56/255, 56/255, 1.0)
                nameStr:SetText(item.name)
                if nameStr.SetFont then local f, s = nameStr:GetFont(); nameStr:SetFont(f, s or 10, "OUTLINE") end
                nameStr:SetShadowOffset(0, 0)

                local moneyStr = (KB.Utils and KB.Utils.FormatMoney) and KB.Utils.FormatMoney(item.debt.amountOwedCopper) or "0g"
                local amtStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                amtStr:SetPoint("LEFT", row, "LEFT", 164, 0)
                amtStr:SetWidth(110)
                amtStr:SetJustifyH("LEFT")
                amtStr:SetTextColor(1.0, 0.84, 0.0, 1.0)
                amtStr:SetText(moneyStr)
                if amtStr.SetFont then local f, s = amtStr:GetFont(); amtStr:SetFont(f, s or 10, "OUTLINE") end
                amtStr:SetShadowOffset(0, 0)

                local credStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                credStr:SetPoint("LEFT", row, "LEFT", 280, 0)
                credStr:SetWidth(140)
                credStr:SetJustifyH("LEFT")
                credStr:SetTextColor(136/255, 136/255, 136/255, 1.0)
                credStr:SetText(item.debt.creditor or "Creditor")
                if credStr.SetFont then local f, s = credStr:GetFont(); credStr:SetFont(f, s or 10, "OUTLINE") end
                credStr:SetShadowOffset(0, 0)

                local statStr = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                statStr:SetPoint("LEFT", row, "LEFT", 426, 0)
                statStr:SetPoint("RIGHT", row, "RIGHT", -8, 0)
                statStr:SetJustifyH("LEFT")
                statStr:SetTextColor(1.0, 56/255, 56/255, 1.0)
                statStr:SetText("DEFAULTED")
                if statStr.SetFont then local f, s = statStr:GetFont(); statStr:SetFont(f, s or 10, "OUTLINE") end
                statStr:SetShadowOffset(0, 0)

                yOffset = yOffset - 24
            end
        end
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
end

-- 4. Render Battleground Gladiator Telemetry
function UI:RenderBGMetrics()
    local gladiators = KB.Leaderboard:GetBattlegroundGladiators(15)
    local yOffset = -10

    local title = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 10, yOffset)
    title:SetText("Battleground Gladiators  -  Damage, Healing, and Efficiency")

    yOffset = yOffset - 40
    for rank, g in ipairs(gladiators) do
        local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        row:SetSize(820, 30)
        row:SetPoint("TOPLEFT", 0, yOffset)
        local theme = UI:GetTheme()
        local isEven = (rank % 2 == 0)
        local baseBg = isEven and theme.rowBgAlt or theme.rowBg
        row:SetBackdrop(theme.rowBackdrop)
        row:SetBackdropColor(unpack(baseBg))
        row:SetBackdropBorderColor(unpack(theme.rowBorder))

        local rankColor = (rank == 1 and "ffd700") or (rank == 2 and "c0c0c0") or (rank == 3 and "cd7f32") or "8899aa"
        local rankText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        rankText:SetPoint("LEFT", 12, 0)
        rankText:SetText(string.format("|cff%s#%d|r", rankColor, rank))

        local icon = UI:CreateClassIcon(row, g.class, 20)
        icon:SetPoint("LEFT", rankText, "RIGHT", 10, 0)

        local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        nameText:SetPoint("LEFT", icon, "RIGHT", 8, 0)
        nameText:SetText(KB.Utils.ColorizeByClass(g.name, g.class))

        local statsText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        statsText:SetPoint("RIGHT", -15, 0)
        statsText:SetText(string.format("Damage: |cffff7700%s|r  |  Healing: |cff00ff00%s|r  |  Score: |cffffd100%s|r",
            KB.Utils.FormatNumber(g.damageDone), KB.Utils.FormatNumber(g.healingDone), KB.Utils.FormatNumber(g.bgScore)))

        yOffset = yOffset - 34
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 30)
end

-- 5. Render Zone Intel
-- 5. Render Danger Zones Tab (ZONE CONFLICT ACTIVITY)
function UI:RenderZones()
    local theme = UI:GetTheme()
    local aR, aG, aB = WoWKB.AccentColor()

    local cWidth = (UI.ContentFrame and UI.ContentFrame:GetWidth()) or 620

    -- Flat Section Header (18px height, #181818 background, 1px border)
    local headerBar = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    headerBar:SetSize(cWidth, 18)
    headerBar:SetPoint("TOPLEFT", 0, -4)
    headerBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    headerBar:SetBackdropColor(24/255, 24/255, 24/255, 1.0) -- #181818
    headerBar:SetBackdropBorderColor(0, 0, 0, 1.0)

    local headerTitle = headerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    headerTitle:SetPoint("LEFT", headerBar, "LEFT", 8, 0)
    headerTitle:SetTextColor(aR, aG, aB, 1.0)
    headerTitle:SetText("ZONE CONFLICT ACTIVITY")
    if headerTitle.SetFont then local f, s = headerTitle:GetFont(); headerTitle:SetFont(f, s or 10, "OUTLINE") end
    headerTitle:SetShadowOffset(0, 0)

    local yOffset = -26

    local function CreateSectionHeader(titleText)
        local secHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        secHeader:SetSize(cWidth, 18)
        secHeader:SetPoint("TOPLEFT", 0, yOffset)
        secHeader:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        secHeader:SetBackdropColor(24/255, 24/255, 24/255, 1.0)
        secHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

        local title = secHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        title:SetPoint("LEFT", secHeader, "LEFT", 8, 0)
        title:SetTextColor(224/255, 224/255, 224/255, 1.0)
        title:SetText(titleText)
        if title.SetFont then local f, s = title:GetFont(); title:SetFont(f, s or 10, "OUTLINE") end
        title:SetShadowOffset(0, 0)
        yOffset = yOffset - 20
    end

    local function CreateColHeader(labels)
        local colHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
        colHeader:SetSize(cWidth, 18)
        colHeader:SetPoint("TOPLEFT", 0, yOffset)
        colHeader:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        colHeader:SetBackdropColor(22/255, 22/255, 22/255, 1.0)
        colHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

        for _, col in ipairs(labels) do
            local lbl = colHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            lbl:SetPoint("LEFT", colHeader, "LEFT", col.x, 0)
            if col.w then lbl:SetWidth(col.w) end
            if col.rightAnchor then lbl:SetPoint("RIGHT", colHeader, "RIGHT", col.rightAnchor, 0) end
            lbl:SetJustifyH(col.justify or "LEFT")
            lbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
            lbl:SetText(col.text)
            if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
            lbl:SetShadowOffset(0, 0)
        end
        yOffset = yOffset - 20
    end

    -- =========================================================================
    -- Table A: REALM ACTIVITY (LAST 24 HOURS)
    -- =========================================================================
    CreateSectionHeader("REALM ACTIVITY (LAST 24 HOURS)")
    CreateColHeader({
        { x = 8, w = 40, text = "RANK" },
        { x = 52, w = 360, text = "ZONE" },
        { x = 430, rightAnchor = -12, text = "CONFIRMED KILLS", justify = "RIGHT" },
    })

    local realmZones = (WoWKillboard_RealmData and WoWKillboard_RealmData.DeadliestZones) or (WoWKillboardDB and WoWKillboardDB.RealmData and WoWKillboardDB.RealmData.DeadliestZones) or {}
    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, rz in ipairs(realmZones) do
            local zN = (rz.zone or ""):lower()
            if zN:find(q, 1, true) then
                table.insert(filtered, rz)
            end
        end
        realmZones = filtered
    end

    if #realmZones == 0 then
        local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        empty:SetPoint("TOPLEFT", 8, yOffset - 4)
        empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
        empty:SetText("No realm conflict activity recorded in the last 24 hours. Sync data to refresh.")
        if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
        empty:SetShadowOffset(0, 0)
        yOffset = yOffset - 26
    else
        for idx, rz in ipairs(realmZones) do
            local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
            row:SetSize(cWidth, 24)
            row:SetPoint("TOPLEFT", 0, yOffset)
            local isEven = (idx % 2 == 0)
            local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

            row:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            row:SetBackdropColor(unpack(rowBg))
            row:SetBackdropBorderColor(0, 0, 0, 1.0)

            local div = row:CreateTexture(nil, "OVERLAY")
            div:SetPoint("BOTTOMLEFT", 0, 0)
            div:SetPoint("BOTTOMRIGHT", 0, 0)
            div:SetHeight(1)
            div:SetColorTexture(0, 0, 0, 1.0)

            local rFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            rFs:SetPoint("LEFT", row, "LEFT", 8, 0)
            rFs:SetWidth(40)
            rFs:SetJustifyH("LEFT")
            rFs:SetTextColor(aR, aG, aB, 1.0)
            rFs:SetText(string.format("#%d", idx))
            if rFs.SetFont then local f, s = rFs:GetFont(); rFs:SetFont(f, s or 10, "OUTLINE") end
            rFs:SetShadowOffset(0, 0)

            local zFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            zFs:SetPoint("LEFT", row, "LEFT", 52, 0)
            zFs:SetWidth(360)
            zFs:SetJustifyH("LEFT")
            zFs:SetWordWrap(false)
            zFs:SetTextColor(1.0, 1.0, 1.0, 1.0)
            zFs:SetText(rz.zone or "Unknown")
            if zFs.SetFont then local f, s = zFs:GetFont(); zFs:SetFont(f, s or 10, "OUTLINE") end
            zFs:SetShadowOffset(0, 0)

            local kFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            kFs:SetPoint("RIGHT", row, "RIGHT", -12, 0)
            kFs:SetJustifyH("RIGHT")
            kFs:SetTextColor(1.0, 56/255, 56/255, 1.0) -- #FF3838
            kFs:SetText(string.format("%d Kills", rz.kills or 0))
            if kFs.SetFont then local f, s = kFs:GetFont(); kFs:SetFont(f, s or 10, "OUTLINE") end
            kFs:SetShadowOffset(0, 0)

            row:EnableMouse(true)
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(unpack(rowBg))
            end)

            yOffset = yOffset - 24
        end
    end

    yOffset = yOffset - 10

    -- =========================================================================
    -- Table B: SESSION ACTIVITY (YOUR VICINITY)
    -- =========================================================================
    CreateSectionHeader("SESSION ACTIVITY (YOUR VICINITY)")
    CreateColHeader({
        { x = 8, w = 40, text = "RANK" },
        { x = 52, w = 360, text = "ZONE" },
        { x = 430, rightAnchor = -12, text = "LOCAL KILLS", justify = "RIGHT" },
    })

    local zones = (KB.Leaderboard.GetTopZones and KB.Leaderboard:GetTopZones(currentMode, 15))
               or (KB.Leaderboard.GetDeadliestZones and KB.Leaderboard:GetDeadliestZones(15))
               or {}

    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, z in ipairs(zones) do
            local zN = (z.zone or ""):lower()
            if zN:find(q, 1, true) then
                table.insert(filtered, z)
            end
        end
        zones = filtered
    end

    if #zones == 0 then
        local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        empty:SetPoint("TOPLEFT", 8, yOffset - 4)
        empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
        empty:SetText("No local zone combat recorded this session. Engage in combat to populate.")
        if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
        empty:SetShadowOffset(0, 0)
        yOffset = yOffset - 26
    else
        for idx, z in ipairs(zones) do
            local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
            row:SetSize(cWidth, 24)
            row:SetPoint("TOPLEFT", 0, yOffset)
            local isEven = (idx % 2 == 0)
            local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

            row:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            row:SetBackdropColor(unpack(rowBg))
            row:SetBackdropBorderColor(0, 0, 0, 1.0)

            local div = row:CreateTexture(nil, "OVERLAY")
            div:SetPoint("BOTTOMLEFT", 0, 0)
            div:SetPoint("BOTTOMRIGHT", 0, 0)
            div:SetHeight(1)
            div:SetColorTexture(0, 0, 0, 1.0)

            local rFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            rFs:SetPoint("LEFT", row, "LEFT", 8, 0)
            rFs:SetWidth(40)
            rFs:SetJustifyH("LEFT")
            rFs:SetTextColor(aR, aG, aB, 1.0)
            rFs:SetText(string.format("#%d", idx))
            if rFs.SetFont then local f, s = rFs:GetFont(); rFs:SetFont(f, s or 10, "OUTLINE") end
            rFs:SetShadowOffset(0, 0)

            local zFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            zFs:SetPoint("LEFT", row, "LEFT", 52, 0)
            zFs:SetWidth(360)
            zFs:SetJustifyH("LEFT")
            zFs:SetWordWrap(false)
            zFs:SetTextColor(1.0, 1.0, 1.0, 1.0)
            zFs:SetText(z.zone or "Unknown")
            if zFs.SetFont then local f, s = zFs:GetFont(); zFs:SetFont(f, s or 10, "OUTLINE") end
            zFs:SetShadowOffset(0, 0)

            local kFs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            kFs:SetPoint("RIGHT", row, "RIGHT", -12, 0)
            kFs:SetJustifyH("RIGHT")
            kFs:SetTextColor(aR, aG, aB, 1.0)
            kFs:SetText(string.format("%d Kills", z.kills or 0))
            if kFs.SetFont then local f, s = kFs:GetFont(); kFs:SetFont(f, s or 10, "OUTLINE") end
            kFs:SetShadowOffset(0, 0)

            row:EnableMouse(true)
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(unpack(rowBg))
            end)

            yOffset = yOffset - 24
        end
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
end

-- 6. Render Faction War Rallies & Call to Arms
function UI:RenderRallies()
    local theme = UI:GetTheme()
    local aR, aG, aB = WoWKB.AccentColor()
    local cWidth = (UI.ContentFrame and UI.ContentFrame:GetWidth()) or 620

    -- Flat Section Header (18px height, #181818 background, 1px border)
    local headerBar = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    headerBar:SetSize(cWidth, 18)
    headerBar:SetPoint("TOPLEFT", 0, -4)
    headerBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    headerBar:SetBackdropColor(24/255, 24/255, 24/255, 1.0) -- #181818
    headerBar:SetBackdropBorderColor(0, 0, 0, 1.0)

    local headerTitle = headerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    headerTitle:SetPoint("LEFT", headerBar, "LEFT", 8, 0)
    headerTitle:SetTextColor(aR, aG, aB, 1.0)
    headerTitle:SetText("OPEN DEFENSE CALLS")
    if headerTitle.SetFont then local f, s = headerTitle:GetFont(); headerTitle:SetFont(f, s or 10, "OUTLINE") end
    headerTitle:SetShadowOffset(0, 0)

    -- Top Broadcast Action: Single compact banner (26px height, #161616, 1px border)
    local isMyBeaconActive = KB.Reinforcements and KB.Reinforcements.IsBeaconActive and KB.Reinforcements:IsBeaconActive()
    local bannerFrame = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    bannerFrame:SetSize(cWidth, 26)
    bannerFrame:SetPoint("TOPLEFT", 0, -26)
    bannerFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    bannerFrame:SetBackdropColor(22/255, 22/255, 22/255, 1.0)
    bannerFrame:SetBackdropBorderColor(0, 0, 0, 1.0)

    local bannerText = bannerFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    bannerText:SetPoint("LEFT", bannerFrame, "LEFT", 10, 0)
    if isMyBeaconActive then
        local locStr = (KB.Reinforcements and KB.Reinforcements.GetBeaconLocationStr) and KB.Reinforcements:GetBeaconLocationStr() or "Frontline"
        bannerText:SetText(string.format("|cff4ade80Active Defense Broadcast:|r %s", locStr))
    else
        bannerText:SetTextColor(224/255, 224/255, 224/255, 1.0)
        bannerText:SetText("Need assistance with open world PvP?")
    end
    if bannerText.SetFont then local f, s = bannerText:GetFont(); bannerText:SetFont(f, s or 10, "OUTLINE") end
    bannerText:SetShadowOffset(0, 0)

    local bcastBtn = CreateFrame("Button", nil, bannerFrame, "BackdropTemplate")
    bcastBtn:SetSize(130, 20)
    bcastBtn:SetPoint("RIGHT", bannerFrame, "RIGHT", -3, 0)
    bcastBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    bcastBtn:SetBackdropColor(30/255, 30/255, 30/255, 1.0)
    bcastBtn:SetBackdropBorderColor(isMyBeaconActive and 0.85 or aR, isMyBeaconActive and 0.2 or aG, isMyBeaconActive and 0.2 or aB, 1.0)

    local bcastLbl = bcastBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    bcastLbl:SetPoint("CENTER", 0, 0)
    if isMyBeaconActive then
        bcastLbl:SetTextColor(1.0, 56/255, 56/255, 1.0)
        bcastLbl:SetText("Cancel Broadcast")
    else
        bcastLbl:SetTextColor(aR, aG, aB, 1.0)
        bcastLbl:SetText("Broadcast Location")
    end
    if bcastLbl.SetFont then local f, s = bcastLbl:GetFont(); bcastLbl:SetFont(f, s or 10, "OUTLINE") end
    bcastLbl:SetShadowOffset(0, 0)
    bcastBtn.Label = bcastLbl

    bcastBtn:SetScript("OnClick", function()
        if isMyBeaconActive then
            if KB.Reinforcements and KB.Reinforcements.ResolveBeacon then
                KB.Reinforcements:ResolveBeacon(false)
            end
            UI:Refresh()
        else
            UI:ShowRallyDialog()
        end
    end)
    bcastBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(42/255, 42/255, 42/255, 1.0)
    end)
    bcastBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(30/255, 30/255, 30/255, 1.0)
    end)

    local yOffset = -56

    -- Table Column Header Strip (18px height, #161616, 1px border)
    local colHeader = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
    colHeader:SetSize(cWidth, 18)
    colHeader:SetPoint("TOPLEFT", 0, yOffset)
    colHeader:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    colHeader:SetBackdropColor(22/255, 22/255, 22/255, 1.0)
    colHeader:SetBackdropBorderColor(0, 0, 0, 1.0)

    local function CreateColHeaderLabel(x, w, text, rightAnchor)
        local lbl = colHeader:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        lbl:SetPoint("LEFT", colHeader, "LEFT", x, 0)
        if rightAnchor then lbl:SetPoint("RIGHT", colHeader, "RIGHT", rightAnchor, 0) end
        if w then lbl:SetWidth(w) end
        lbl:SetJustifyH("LEFT")
        lbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
        lbl:SetText(text)
        if lbl.SetFont then local f, s = lbl:GetFont(); lbl:SetFont(f, s or 10, "OUTLINE") end
        lbl:SetShadowOffset(0, 0)
    end

    CreateColHeaderLabel(8, 48, "TIME")
    CreateColHeaderLabel(58, 55, "FACTION")
    CreateColHeaderLabel(116, 125, "REQUESTER")
    CreateColHeaderLabel(246, 270, "ZONE / COORDINATES")
    CreateColHeaderLabel(540, nil, "ACTION", -8)

    yOffset = yOffset - 20

    local rallies = (KB.Reinforcements and KB.Reinforcements.GetOpenRallies) and KB.Reinforcements:GetOpenRallies() or {}
    if UI.activeSearchQuery and UI.activeSearchQuery ~= "" then
        local q = UI.activeSearchQuery
        local filtered = {}
        for _, r in ipairs(rallies) do
            local rN = (r.character_name or ""):lower()
            local rG = (r.guild_name or ""):lower()
            local rZ = (r.zone or ""):lower()
            local rNote = (r.note or r.message or ""):lower()
            if rN:find(q, 1, true) or rG:find(q, 1, true) or rZ:find(q, 1, true) or rNote:find(q, 1, true) then
                table.insert(filtered, r)
            end
        end
        rallies = filtered
    end

    if #rallies == 0 then
        local empty = UI.ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        empty:SetPoint("TOPLEFT", 8, yOffset - 4)
        empty:SetTextColor(119/255, 119/255, 119/255, 1.0)
        empty:SetText("No active defense requests on this realm.")
        if empty.SetFont then local f, s = empty:GetFont(); empty:SetFont(f, s or 10, "OUTLINE") end
        empty:SetShadowOffset(0, 0)
        yOffset = yOffset - 26
    else
        for idx, r in ipairs(rallies) do
            local row = CreateFrame("Frame", nil, UI.ContentFrame, "BackdropTemplate")
            row:SetSize(cWidth, 24)
            row:SetPoint("TOPLEFT", 0, yOffset)
            local isEven = (idx % 2 == 0)
            local rowBg = isEven and { 22/255, 22/255, 22/255, 1.0 } or { 20/255, 20/255, 20/255, 1.0 }

            row:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            row:SetBackdropColor(unpack(rowBg))
            row:SetBackdropBorderColor(0, 0, 0, 1.0)

            local div = row:CreateTexture(nil, "OVERLAY")
            div:SetPoint("BOTTOMLEFT", 0, 0)
            div:SetPoint("BOTTOMRIGHT", 0, 0)
            div:SetHeight(1)
            div:SetColorTexture(0, 0, 0, 1.0)

            -- Col 1: Time
            local diffMin = math.max(1, math.floor((time() - (r.timestamp or time())) / 60))
            local timeLbl = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            timeLbl:SetPoint("LEFT", row, "LEFT", 8, 0)
            timeLbl:SetWidth(48)
            timeLbl:SetJustifyH("LEFT")
            timeLbl:SetTextColor(119/255, 119/255, 119/255, 1.0)
            timeLbl:SetText(string.format("%dm ago", diffMin))
            if timeLbl.SetFont then local f, s = timeLbl:GetFont(); timeLbl:SetFont(f, s or 10, "OUTLINE") end
            timeLbl:SetShadowOffset(0, 0)

            -- Col 2: Faction Badge
            local facBadge = CreateFactionBadge(row, r.faction, 54, 16)
            facBadge:SetPoint("LEFT", row, "LEFT", 58, 0)

            if r.isSelf then
                ApplyPlayerRowHighlight(row, r.faction)
            end

            -- Col 3: Requester Name
            local cIconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
            cIconFrame:SetSize(16, 16)
            cIconFrame:SetPoint("LEFT", row, "LEFT", 116, 0)
            cIconFrame:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            cIconFrame:SetBackdropColor(0, 0, 0, 1.0)
            cIconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)
            local cIcon = UI:CreateClassIcon(cIconFrame, r.character_class or "WARRIOR", 16)
            cIcon:SetAllPoints(cIconFrame)

            local reqLbl = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            reqLbl:SetPoint("LEFT", cIconFrame, "RIGHT", 4, 0)
            reqLbl:SetPoint("RIGHT", row, "LEFT", 242, 0)
            reqLbl:SetJustifyH("LEFT")
            reqLbl:SetWordWrap(false)
            local selfTag = r.isSelf and " |cffffd100[YOU]|r" or ""
            reqLbl:SetText(KB.Utils.ColorizeByClass(r.character_name or "Commander", r.character_class) .. selfTag)
            if reqLbl.SetFont then local f, s = reqLbl:GetFont(); reqLbl:SetFont(f, s or 10, "OUTLINE") end
            reqLbl:SetShadowOffset(0, 0)

            -- Col 4: Zone / Coordinates
            local zoneStr = r.zone or "Wilderness"
            if r.coords and r.coords ~= "" then
                zoneStr = string.format("%s (%s)", zoneStr, r.coords)
            end
            local zoneLbl = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            zoneLbl:SetPoint("LEFT", row, "LEFT", 246, 0)
            zoneLbl:SetPoint("RIGHT", row, "RIGHT", -86, 0)
            zoneLbl:SetJustifyH("LEFT")
            zoneLbl:SetWordWrap(false)
            zoneLbl:SetTextColor(212/255, 163/255, 89/255, 1.0)
            zoneLbl:SetText(zoneStr)
            if zoneLbl.SetFont then local f, s = zoneLbl:GetFont(); zoneLbl:SetFont(f, s or 10, "OUTLINE") end
            zoneLbl:SetShadowOffset(0, 0)

            -- Col 5: Action Button
            local actBtn = CreateFrame("Button", nil, row, "BackdropTemplate")
            actBtn:SetSize(74, 18)
            actBtn:SetPoint("RIGHT", row, "RIGHT", -8, 0)
            actBtn:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            actBtn:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
            actBtn:SetBackdropBorderColor(0, 0, 0, 1.0)

            local actLbl = actBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            actLbl:SetPoint("CENTER", 0, 0)
            if r.isSelf then
                actLbl:SetTextColor(1.0, 56/255, 56/255, 1.0)
                actLbl:SetText("Cancel")
            else
                actLbl:SetTextColor(aR, aG, aB, 1.0)
                actLbl:SetText("Join")
            end
            if actLbl.SetFont then local f, s = actLbl:GetFont(); actLbl:SetFont(f, s or 10, "OUTLINE") end
            actLbl:SetShadowOffset(0, 0)
            actBtn.Label = actLbl

            actBtn:SetScript("OnClick", function(self)
                if r.isSelf then
                    if KB.Reinforcements and KB.Reinforcements.ResolveBeacon then
                        KB.Reinforcements:ResolveBeacon(false)
                    end
                    UI:Refresh()
                else
                    if KB.Reinforcements and KB.Reinforcements.RequestJoinRally then
                        local ok = KB.Reinforcements:RequestJoinRally(r.character_name)
                        if ok then
                            self.Label:SetTextColor(74/255, 222/255, 128/255, 1.0)
                            self.Label:SetText("Joined")
                            self:Disable()
                        end
                    end
                end
            end)
            actBtn:SetScript("OnEnter", function(self)
                self:SetBackdropColor(38/255, 38/255, 38/255, 1.0)
            end)
            actBtn:SetScript("OnLeave", function(self)
                self:SetBackdropColor(26/255, 26/255, 26/255, 1.0)
            end)

            row:EnableMouse(true)
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(36/255, 36/255, 36/255, 1.0)
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropBorderColor(0, 0, 0, 1.0)
                self:SetBackdropColor(unpack(rowBg))
            end)

            yOffset = yOffset - 24
        end
    end

    UI.ContentFrame:SetHeight(math.abs(yOffset) + 16)
end

-- Detail Modal Frame: Classified Killmail Dossier (Anonymous, 100% template-free)
function UI:CreateDetailModal()
    -- Full Backdrop Dimmer / Scrim covering the mainFrame behind the modal
    local scrim = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    scrim:SetAllPoints(mainFrame)
    scrim:SetFrameStrata("DIALOG")
    scrim:SetFrameLevel(mainFrame:GetFrameLevel() + 40)
    scrim:EnableMouse(true)
    scrim:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = nil,
    })
    scrim:SetBackdropColor(0, 0, 0, 0.78)
    scrim:Hide()

    local modal = CreateFrame("Frame", nil, mainFrame, "BackdropTemplate")
    UI.DetailModal = modal
    modal.Scrim = scrim
    modal:SetSize(540, 410)
    modal:SetPoint("CENTER", mainFrame, "CENTER", 0, 0)
    modal:SetFrameStrata("DIALOG")
    modal:SetFrameLevel(mainFrame:GetFrameLevel() + 50)
    modal:EnableMouse(true)
    modal:SetClampedToScreen(true)

    scrim:SetScript("OnMouseDown", function()
        modal:Hide()
    end)

    modal:HookScript("OnShow", function()
        if modal.Scrim then modal.Scrim:Show() end
    end)
    modal:HookScript("OnHide", function()
        if modal.Scrim then modal.Scrim:Hide() end
    end)

    local theme = UI:GetTheme()
    local modalSolid = modal:CreateTexture(nil, "BACKGROUND", nil, -8)
    modalSolid:SetAllPoints(modal)
    modalSolid:SetColorTexture(0.04, 0.05, 0.07, 1.0)
    modal.SolidBg = modalSolid

    modal:SetBackdrop(theme.modalBackdrop or {
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    modal:SetBackdropColor(unpack(theme.modalBg or {0.05, 0.05, 0.05, 1.0}))
    modal:SetBackdropBorderColor(unpack(theme.modalBorder or {0.0, 0.0, 0.0, 1.0}))
    modal:Hide()

    -- Title Bar
    local title = modal:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    local mColor = (theme.id == "classic") and "|cffffd100" or "|cffffffff"
    title:SetText(mColor .. "KILLMAIL COMBAT RECORD|r")
    modal.Title = title

    -- Top-Right Close Button
    local closeBtn = CreateFrame("Button", nil, modal, "BackdropTemplate")
    closeBtn:SetSize(18, 18)
    closeBtn:SetPoint("TOPRIGHT", -8, -8)
    closeBtn:SetFrameStrata("DIALOG")
    closeBtn:SetFrameLevel(modal:GetFrameLevel() + 10)
    closeBtn:EnableMouse(true)
    local closeLabel = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    closeLabel:SetPoint("CENTER", 0, 0)
    closeBtn.Label = closeLabel
    closeBtn:SetScript("OnClick", function()
        modal:Hide()
    end)
    modal.CloseBtn = closeBtn

    -- Left Card: Killer Dossier
    local killerCard = CreateFrame("Frame", nil, modal, "BackdropTemplate")
    killerCard:SetSize(246, 118)
    killerCard:SetPoint("TOPLEFT", 16, -38)
    killerCard:SetFrameStrata("DIALOG")
    killerCard:SetFrameLevel(modal:GetFrameLevel() + 2)
    killerCard:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    killerCard:SetBackdropColor(0.08, 0.12, 0.10, 0.95)
    killerCard:SetBackdropBorderColor(0.1, 0.7, 0.3, 0.8)

    local kCardTitle = killerCard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    kCardTitle:SetPoint("TOPLEFT", 8, -6)
    kCardTitle:SetText("|cff00ff66KILLER|r")
    killerCard.CardTitle = kCardTitle

    local kIcon = UI:CreateClassIcon(killerCard, "WARRIOR", 28)
    kIcon:SetPoint("TOPLEFT", 8, -24)
    killerCard.Icon = kIcon

    local kIconBorder = killerCard:CreateTexture(nil, "OVERLAY")
    kIconBorder:SetTexture("Interface\\AchievementFrame\\UI-Achievement-IconFrame")
    kIconBorder:SetTexCoord(0, 0.5625, 0, 0.5625)
    kIconBorder:SetSize(36, 36)
    kIconBorder:SetPoint("CENTER", kIcon, "CENTER", 0, 0)
    killerCard.IconBorder = kIconBorder

    local kName = killerCard:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    kName:SetPoint("TOPLEFT", kIcon, "TOPRIGHT", 8, 0)
    killerCard.Name = kName

    local kInfo = killerCard:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    kInfo:SetPoint("TOPLEFT", kName, "BOTTOMLEFT", 0, -3)
    killerCard.Info = kInfo

    local kWebBtn = UI:CreateButton(killerCard, 76, 18, "Web Profile", "GameFontHighlightSmall")
    kWebBtn:SetPoint("BOTTOMRIGHT", -6, 6)
    kWebBtn:SetScript("OnClick", function()
        if modal.currentKillmail and modal.currentKillmail.killer and modal.currentKillmail.killer.name then
            local k = modal.currentKillmail.killer
            UI:ShowCharacterWebLink(k.name, k.class, k.level, k.faction)
        end
    end)
    killerCard.WebBtn = kWebBtn
    modal.KillerCard = killerCard

    -- Right Card: Victim Dossier
    local victimCard = CreateFrame("Frame", nil, modal, "BackdropTemplate")
    victimCard:SetSize(246, 118)
    victimCard:SetPoint("TOPRIGHT", -16, -38)
    victimCard:SetFrameStrata("DIALOG")
    victimCard:SetFrameLevel(modal:GetFrameLevel() + 2)
    victimCard:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    victimCard:SetBackdropColor(0.14, 0.08, 0.08, 0.95)
    victimCard:SetBackdropBorderColor(0.8, 0.2, 0.2, 0.8)

    local vCardTitle = victimCard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    vCardTitle:SetPoint("TOPLEFT", 8, -6)
    vCardTitle:SetText("|cffff4444VICTIM|r")
    victimCard.CardTitle = vCardTitle

    local vIcon = UI:CreateClassIcon(victimCard, "WARRIOR", 28)
    vIcon:SetPoint("TOPLEFT", 8, -24)
    victimCard.Icon = vIcon

    local vIconBorder = victimCard:CreateTexture(nil, "OVERLAY")
    vIconBorder:SetTexture("Interface\\AchievementFrame\\UI-Achievement-IconFrame")
    vIconBorder:SetTexCoord(0, 0.5625, 0, 0.5625)
    vIconBorder:SetSize(36, 36)
    vIconBorder:SetPoint("CENTER", vIcon, "CENTER", 0, 0)
    victimCard.IconBorder = vIconBorder

    local vName = victimCard:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    vName:SetPoint("TOPLEFT", vIcon, "TOPRIGHT", 8, 0)
    victimCard.Name = vName

    local vInfo = victimCard:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    vInfo:SetPoint("TOPLEFT", vName, "BOTTOMLEFT", 0, -3)
    victimCard.Info = vInfo

    local vWebBtn = UI:CreateButton(victimCard, 76, 18, "Web Profile", "GameFontHighlightSmall")
    vWebBtn:SetPoint("BOTTOMRIGHT", -6, 6)
    vWebBtn:SetScript("OnClick", function()
        if modal.currentKillmail and modal.currentKillmail.victim and modal.currentKillmail.victim.name then
            local v = modal.currentKillmail.victim
            UI:ShowCharacterWebLink(v.name, v.class, v.level, v.faction)
        end
    end)
    victimCard.WebBtn = vWebBtn
    modal.VictimCard = victimCard

    -- Context & GPS Info Bar
    local infoPanel = CreateFrame("Frame", nil, modal, "BackdropTemplate")
    infoPanel:SetPoint("TOPLEFT", 16, -164)
    infoPanel:SetPoint("BOTTOMRIGHT", -16, 48)
    infoPanel:SetFrameStrata("DIALOG")
    infoPanel:SetFrameLevel(modal:GetFrameLevel() + 2)
    infoPanel:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    infoPanel:SetBackdropColor(0.08, 0.09, 0.12, 0.9)
    infoPanel:SetBackdropBorderColor(0.18, 0.22, 0.28, 0.8)

    local details = infoPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    details:SetPoint("TOPLEFT", 10, -8)
    details:SetPoint("BOTTOMRIGHT", -10, 8)
    details:SetJustifyH("LEFT")
    details:SetJustifyV("TOP")
    modal.DetailsText = details
    modal.InfoPanel = infoPanel

    -- Dismiss Button (Elevated frame level and strata so it's impossible to intercept)
    local dismiss = UI:CreateButton(modal, 120, 26, "Dismiss")
    dismiss:SetPoint("BOTTOM", 0, 14)
    dismiss:SetFrameStrata("DIALOG")
    dismiss:SetFrameLevel(modal:GetFrameLevel() + 10)
    dismiss:EnableMouse(true)
    dismiss:SetScript("OnClick", function()
        modal:Hide()
    end)
    modal.DismissBtn = dismiss

    -- Apply current theme styling
    UI:ApplyTheme()
end

function UI:ShowKillDetail(km)
    if not UI.DetailModal or not km then return end
    local m = UI.DetailModal
    m.currentKillmail = km
    m.currentPveDeath = nil

    if m.Title then m.Title:SetText("|cffffd100KILLMAIL COMBAT RECORD|r") end
    if m.KillerCard.CardTitle then m.KillerCard.CardTitle:SetText("|cff00ff66KILLER|r") end
    if m.VictimCard.CardTitle then m.VictimCard.CardTitle:SetText("|cffff4444VICTIM|r") end
    if m.KillerCard.WebBtn then m.KillerCard.WebBtn:Show() end
    if m.VictimCard.WebBtn then m.VictimCard.WebBtn:Show() end
    m.KillerCard.Icon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
    m.VictimCard.Icon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")

    -- Update Killer Card
    local kCoords = CLASS_COORDS[(km.killer.class or ""):upper()] or {0, 0.25, 0, 0.25}
    m.KillerCard.Icon:SetTexCoord(kCoords[1], kCoords[2], kCoords[3], kCoords[4])
    m.KillerCard.Name:SetText(KB.Utils.ColorizeByClass(km.killer.name, km.killer.class))
    local kLvlStr = (km.killer.level and km.killer.level > 0) and tostring(km.killer.level) or "??"
    local kGuildStr = (km.killer.guild and km.killer.guild ~= "None") and ("<" .. km.killer.guild .. ">") or "Guildless"
    m.KillerCard.Info:SetText(string.format("Level %s %s\n%s\nParty Size: %d\nDamage: %s",
        kLvlStr, km.killer.class or "UNKNOWN", kGuildStr, km.killer.partySize or 1, KB.Utils.FormatNumber(km.killer.damageDone or 0)))

    -- Update Victim Card
    local vCoords = CLASS_COORDS[(km.victim.class or ""):upper()] or {0, 0.25, 0, 0.25}
    m.VictimCard.Icon:SetTexCoord(vCoords[1], vCoords[2], vCoords[3], vCoords[4])
    m.VictimCard.Name:SetText(KB.Utils.ColorizeByClass(km.victim.name, km.victim.class))
    local vLvlStr = (km.victim.level and km.victim.level > 0) and tostring(km.victim.level) or "??"
    local vGuildStr = (km.victim.guild and km.victim.guild ~= "None") and ("<" .. km.victim.guild .. ">") or "Guildless"
    m.VictimCard.Info:SetText(string.format("Level %s %s\n%s\nHostile Gang: %d\nVictim Faction: %s",
        vLvlStr, km.victim.class or "UNKNOWN", vGuildStr, km.victim.partySize or 1, km.victim.faction or "Unknown"))

    -- Engagement and GPS Info
    local modeStr
    if km.isDuel then
        modeStr = "|cffffd7001v1 Duel Match|r"
    elseif km.isBattleground then
        modeStr = string.format("|cff69ccf0Battleground [%s]|r", km.battlegroundName or "BG")
    else
        modeStr = "|cff00ff66Open World PvP|r"
    end

    local soloStr = km.isSolo and "|cff00ff66Certified Solo Kill|r" or (((km.attackersCount or 1) > 1) and string.format("|cffffaa00Gang Engagement (%d Attackers)|r", km.attackersCount) or "|cffffaa00Assisted Engagement|r")
    local subzoneStr = (km.location.subZone and km.location.subZone ~= "") and (" (" .. km.location.subZone .. ")") or ""

    local fatalSpell = km.finalSpell or (km.killer and km.killer.spell)
    local fatalSpellStr = (fatalSpell and fatalSpell ~= "" and fatalSpell ~= "Combat Strike") and fatalSpell or "Melee Swing"
    local fatalLine = string.format("\n|cffffd100Fatal Strike:|r |cffff5533%s|r", fatalSpellStr)

    local attackersStr = ""
    if km.attackers and #km.attackers > 1 then
        attackersStr = "\n|cffffd100Attackers Breakdown:|r "
        local attParts = {}
        for _, att in ipairs(km.attackers) do
            local aName = att.name or "Attacker"
            local aClass = att.class or "UNKNOWN"
            local aDmg = tonumber(att.damage or 0) or 0
            local aStr = KB.Utils.ColorizeByClass(aName, aClass)
            if aDmg > 0 then
                aStr = aStr .. string.format(" (|cffffd100%s|r)", KB.Utils.FormatNumber(aDmg))
            end
            table.insert(attParts, aStr)
        end
        attackersStr = attackersStr .. table.concat(attParts, ", ")
    elseif km.isSolo then
        attackersStr = "\n|cffffd100Combat Purity:|r |cff00ff66100% Certified Solo Execution|r"
    end

    m.DetailsText:SetText(string.format(
        "|cffffd100Engagement:|r %s  |  %s%s%s\n|cffffd100Location:|r %s%s  (GPS: %.1f, %.1f | MapID: %s)\n|cffffd100Timestamp:|r %s  (|cff888888%s|r)\n|cffffd100Kill ID:|r %s",
        modeStr, soloStr, fatalLine, attackersStr, km.location.zone or "Unknown", subzoneStr, km.location.x or 0, km.location.y or 0, tostring(km.location.mapId or 0),
        date("%Y-%m-%d %H:%M:%S", km.timestamp), KB.Utils.FormatTimeAgo(km.timestamp), km.killId
    ))

    UI:ApplyTheme()

    -- Skin cards based on faction
    local kFaction = (km.killer and km.killer.faction or ""):lower()
    if kFaction == "" and km.killer and km.killer.class then
        local cls = km.killer.class:upper()
        if cls == "PALADIN" then kFaction = "alliance"
        elseif cls == "SHAMAN" then kFaction = "horde" end
    end
    if kFaction == "" and km.victim and km.victim.faction and not km.isDuel then
        local vf = km.victim.faction:lower()
        if vf == "alliance" then kFaction = "horde"
        elseif vf == "horde" then kFaction = "alliance" end
    end

    if kFaction == "alliance" then
        m.KillerCard:SetBackdropColor(0.04, 0.08, 0.16, 0.96)
        m.KillerCard:SetBackdropBorderColor(0.22, 0.52, 0.88, 0.95)
    elseif kFaction == "horde" then
        m.KillerCard:SetBackdropColor(0.16, 0.04, 0.04, 0.96)
        m.KillerCard:SetBackdropBorderColor(0.85, 0.24, 0.20, 0.95)
    end

    local vFaction = (km.victim and km.victim.faction or ""):lower()
    if vFaction == "" and km.victim and km.victim.class then
        local cls = km.victim.class:upper()
        if cls == "PALADIN" then vFaction = "alliance"
        elseif cls == "SHAMAN" then vFaction = "horde" end
    end
    if vFaction == "" and kFaction ~= "" and not km.isDuel then
        if kFaction == "alliance" then vFaction = "horde"
        elseif kFaction == "horde" then vFaction = "alliance" end
    end

    if vFaction == "alliance" then
        m.VictimCard:SetBackdropColor(0.04, 0.08, 0.16, 0.96)
        m.VictimCard:SetBackdropBorderColor(0.22, 0.52, 0.88, 0.95)
    elseif vFaction == "horde" then
        m.VictimCard:SetBackdropColor(0.16, 0.04, 0.04, 0.96)
        m.VictimCard:SetBackdropBorderColor(0.85, 0.24, 0.20, 0.95)
    end

    m:Show()
    if m.Raise then m:Raise() end
end

-- Template-Free External Web Profile Link Dialog (Anonymous, 100% Zero Blizzard Taint)
function UI:ShowCharacterWebLink(charName, className, level, faction)
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open web profile link dialog during combat.")
        return
    end

    local validClasses = {
        WARRIOR = true, PALADIN = true, HUNTER = true, ROGUE = true, PRIEST = true,
        DEATHKNIGHT = true, SHAMAN = true, MAGE = true, WARLOCK = true, MONK = true,
        DRUID = true, DEMONHUNTER = true, EVOKER = true,
    }

    local pName = (UnitName("player"))
    local isPlayer = (not charName) or (charName == pName)

    if charName then
        charName = (charName:match("^([^- %s]+)") or charName)
    else
        charName = pName or "Player"
    end

    if isPlayer then
        local _, classFilename = UnitClass("player")
        if not className or not validClasses[tostring(className):upper()] then
            className = classFilename or "WARRIOR"
        end
        level = level or UnitLevel("player") or 60
        faction = faction or UnitFactionGroup("player") or "Alliance"
    elseif UnitExists("target") and (UnitName("target")) == charName then
        local _, classFilename = UnitClass("target")
        if not className or not validClasses[tostring(className):upper()] then
            className = classFilename or "WARRIOR"
        end
        level = level or UnitLevel("target") or 60
        faction = faction or UnitFactionGroup("target") or "Alliance"
    else
        if not className or not validClasses[tostring(className):upper()] then
            className = "WARRIOR"
        end
        level = level or 60
        faction = faction or "Alliance"
    end

    local domain = (KB.Config and KB.Config.WebDomain) or KB.WebDomain or "wowkillboard.com"
    local rawUrl = string.format("https://%s/character?name=%s&character=%s&class=%s&level=%d&faction=%s", domain, charName, charName, className, level, faction)

    if not UI.WebLinkDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(480, 160)
        dlg:SetPoint("CENTER")
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(UIParent:GetFrameLevel() + 60)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)

        -- Theme-aware backdrop
        local theme = UI:GetTheme()
        if theme.id == "classic" then
            dlg:SetBackdrop({
                bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
                tile = true, tileSize = 32, edgeSize = 24,
                insets = { left = 6, right = 6, top = 6, bottom = 6 }
            })
            dlg:SetBackdropColor(1.0, 1.0, 1.0, 1.0)
            dlg:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0)
        else
            dlg:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            dlg:SetBackdropColor(0.06, 0.07, 0.10, 0.98)
            dlg:SetBackdropBorderColor(0.0, 0.85, 1.0, 0.8)
        end

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -18)
        title:SetText("|cff00e5ffExternal Web Profile Link|r")
        dlg.Title = title

        local desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        desc:SetPoint("TOP", 0, -44)
        desc:SetText("Press |cffffd100Ctrl+C|r to copy your public combat profile URL to view or share online:")
        dlg.Desc = desc

        -- EditBox container plate
        local ebPlate = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        ebPlate:SetSize(430, 30)
        ebPlate:SetPoint("TOP", 0, -68)
        ebPlate:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebPlate:SetBackdropColor(0.02, 0.03, 0.05, 0.95)
        ebPlate:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.9)

        local eb = CreateFrame("EditBox", nil, ebPlate)
        eb:SetPoint("LEFT", ebPlate, "LEFT", 10, 0)
        eb:SetPoint("RIGHT", ebPlate, "RIGHT", -10, 0)
        eb:SetHeight(24)
        eb:SetMaxLetters(1024)
        eb:SetAutoFocus(false)
        eb:SetFontObject("GameFontHighlight")
        eb:SetScript("OnEscapePressed", function() dlg:Hide() end)
        eb:SetScript("OnEnterPressed", function() dlg:Hide() end)
        eb:SetScript("OnEditFocusLost", function(self) self:HighlightText(0, 0) end)
        eb:SetScript("OnChar", function(self)
            if dlg.currentUrl then
                self:SetText(dlg.currentUrl)
                self:HighlightText()
            end
        end)
        dlg.EditBox = eb

        -- Bottom Done Button
        local doneBtn = UI:CreateButton(dlg, 90, 24, "Done")
        doneBtn:SetPoint("BOTTOM", 0, 16)
        doneBtn:SetScript("OnClick", function()
            dlg:Hide()
        end)
        dlg.DoneBtn = doneBtn

        -- Safe ESC key listener without UISpecialFrames (Zero Taint Standard)
        dlg:EnableKeyboard(true)
        dlg:SetPropagateKeyboardInput(true)
        dlg:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        UI.WebLinkDialog = dlg
    end

    local dlg = UI.WebLinkDialog
    dlg.currentUrl = rawUrl
    dlg.Title:SetText(string.format("|cff00e5ffWeb Profile: %s|r", charName))
    dlg.EditBox:SetText(rawUrl)
    dlg:Show()
    dlg.EditBox:SetFocus()
    dlg.EditBox:SetCursorPosition(0)
    dlg.EditBox:HighlightText()
    if dlg.Raise then dlg:Raise() end
end

-- Template-Free In-Game Combat Export Dialog (Anonymous, 100% Zero Blizzard Taint)
function UI:ShowExportDialog()
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open combat export dialog during combat.")
        return
    end

    if not UI.ExportDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(520, 340)
        dlg:SetPoint("CENTER")
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(100)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        dlg:SetBackdropColor(0.06, 0.07, 0.10, 0.98)
        dlg:SetBackdropBorderColor(0.85, 0.65, 0.15, 1.0)

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText("|cffffd100WoW Killboard  -  Combat Data Export|r")
        dlg.Title = title

        local desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        desc:SetPoint("TOP", 0, -40)
        desc:SetText("Press |cffffd100Ctrl+A|r then |cffffd100Ctrl+C|r to copy. Paste into the web uploader at |cff00e5ff/upload|r:")
        dlg.Desc = desc

        local inset = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        inset:SetPoint("TOPLEFT", dlg, "TOPLEFT", 18, -62)
        inset:SetPoint("BOTTOMRIGHT", dlg, "BOTTOMRIGHT", -18, 52)
        inset:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        inset:SetBackdropColor(0.02, 0.03, 0.05, 0.95)
        inset:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.9)

        local scrollFrame = CreateFrame("ScrollFrame", nil, inset)
        scrollFrame:SetPoint("TOPLEFT", inset, "TOPLEFT", 8, -8)
        scrollFrame:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -8, 8)
        scrollFrame:EnableMouseWheel(true)

        local eb = CreateFrame("EditBox", nil, scrollFrame)
        eb:SetMultiLine(true)
        eb:SetMaxLetters(999999)
        eb:EnableMouse(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject("ChatFontNormal")
        eb:SetWidth(460)
        eb:SetScript("OnEscapePressed", function() dlg:Hide() end)
        scrollFrame:SetScrollChild(eb)
        scrollFrame:SetScript("OnMouseWheel", function(self, delta)
            local current = self:GetVerticalScroll()
            local maxScroll = math.max(0, eb:GetHeight() - self:GetHeight())
            local newScroll = math.max(0, math.min(maxScroll, current - (delta * 30)))
            self:SetVerticalScroll(newScroll)
        end)
        dlg.EditBox = eb

        -- Safe ESC key listener without UISpecialFrames (Zero Taint Standard)
        dlg:EnableKeyboard(true)
        dlg:SetPropagateKeyboardInput(true)
        dlg:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        local selectBtn = UI:CreateButton(dlg, 110, 24, "Select All")
        selectBtn:SetPoint("BOTTOMLEFT", 24, 16)
        selectBtn:SetScript("OnClick", function()
            dlg.EditBox:SetFocus()
            dlg.EditBox:HighlightText()
        end)

        local doneBtn = UI:CreateButton(dlg, 90, 24, "Close")
        doneBtn:SetPoint("BOTTOMRIGHT", -24, 16)
        doneBtn:SetScript("OnClick", function() dlg:Hide() end)

        UI.ExportDialog = dlg
    end

    local dlg = UI.ExportDialog
    -- Serialize WoWKillboardDB combat records
    local lines = {}
    table.insert(lines, "WoWKillboardDB = {")
    table.insert(lines, "  [\"kills\"] = {")
    if WoWKillboardDB and WoWKillboardDB.kills then
        for kId, kData in pairs(WoWKillboardDB.kills) do
            table.insert(lines, string.format("    [%q] = {", tostring(kId)))
            table.insert(lines, string.format("      [\"killId\"] = %q,", tostring(kData.killId or kId)))
            table.insert(lines, string.format("      [\"timestamp\"] = %s,", tostring(kData.timestamp or 0)))
            table.insert(lines, string.format("      [\"isSolo\"] = %s,", tostring(kData.isSolo and true or false)))
            table.insert(lines, string.format("      [\"attackersCount\"] = %s,", tostring(kData.attackersCount or 1)))
            table.insert(lines, string.format("      [\"totalDamage\"] = %s,", tostring(kData.totalDamage or 0)))
            if kData.killer then
                table.insert(lines, string.format("      [\"killer\"] = { [\"name\"] = %q, [\"guid\"] = %q, [\"class\"] = %q, [\"level\"] = %s, [\"guild\"] = %q, [\"faction\"] = %q, [\"damageDone\"] = %s },",
                    kData.killer.name or "Unknown", kData.killer.guid or "UNKNOWN", kData.killer.class or "UNKNOWN", tostring(kData.killer.level or 0), kData.killer.guild or "None", kData.killer.faction or "Unknown", tostring(kData.killer.damageDone or 0)))
            end
            if kData.victim then
                table.insert(lines, string.format("      [\"victim\"] = { [\"name\"] = %q, [\"guid\"] = %q, [\"class\"] = %q, [\"level\"] = %s, [\"guild\"] = %q, [\"faction\"] = %q },",
                    kData.victim.name or "Unknown", kData.victim.guid or "UNKNOWN", kData.victim.class or "UNKNOWN", tostring(kData.victim.level or 0), kData.victim.guild or "None", kData.victim.faction or "Unknown"))
            end
            if kData.location then
                table.insert(lines, string.format("      [\"location\"] = { [\"zone\"] = %q, [\"subZone\"] = %q, [\"x\"] = %s, [\"y\"] = %s, [\"mapId\"] = %s },",
                    kData.location.zone or "Wilderness", kData.location.subZone or "", tostring(kData.location.x or 0), tostring(kData.location.y or 0), tostring(kData.location.mapId or 0)))
            end
            table.insert(lines, "    },")
        end
    end
    table.insert(lines, "  },")
    table.insert(lines, "}")

    local exportStr = table.concat(lines, "\n")
    dlg.EditBox:SetText(exportStr)
    dlg:Show()
    dlg.EditBox:SetFocus()
    dlg.EditBox:HighlightText()
    if dlg.Raise then dlg:Raise() end
end

-- ============================================================================
-- Template-Free First-Time Early Beta & Feedback Welcome Dialog
-- ============================================================================
function UI:ShowWelcomeModal(isManual)
    if InCombatLockdown and InCombatLockdown() then
        if isManual then
            SafePrint("|cffff9900[WoWKB]|r Cannot open Welcome dialog during combat.")
        end
        return
    end

    if not UI.WelcomeDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(620, 520)
        dlg:SetPoint("CENTER", 0, 30)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(110)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        dlg:SetBackdropColor(0.06, 0.08, 0.12, 0.98)
        dlg:SetBackdropBorderColor(0.85, 0.68, 0.22, 1.0)

        -- Header Drag Bar
        local header = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        header:SetPoint("TOPLEFT", 1, -1)
        header:SetPoint("TOPRIGHT", -1, -1)
        header:SetHeight(28)
        header:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
        })
        header:SetBackdropColor(0.12, 0.09, 0.06, 0.98)
        header:EnableMouse(true)
        header:RegisterForDrag("LeftButton")
        header:SetScript("OnDragStart", function() if not InCombatLockdown() then dlg:StartMoving() end end)
        header:SetScript("OnDragStop", function() dlg:StopMovingOrSizing() end)
        dlg.Header = header

        local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("LEFT", 12, 0)
        title:SetText("|cffffd100WoW KILLBOARD  -  EARLY BETA PREVIEW|r")
        dlg.Title = title

        -- Close [X] Button on header
        local closeX = CreateFrame("Button", nil, header)
        closeX:SetSize(22, 22)
        closeX:SetPoint("RIGHT", -4, 0)
        local closeXText = closeX:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        closeXText:SetPoint("CENTER", 0, 0)
        closeXText:SetText("|cffff4444X|r")
        closeX:SetScript("OnClick", function()
            if dlg.DoNotShowAgain then
                WoWKillboardSettings = WoWKillboardSettings or {}
                WoWKillboardSettings.hasSeenBetaWelcome = true
            end
            dlg:Hide()
        end)

        -- Subtitle
        local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sub:SetPoint("TOPLEFT", 16, -34)
        sub:SetText("|cff38bdf8Community Playtest, Feedback & Battle Intelligence Protocol|r")

        -- Inset Content Box
        local inset = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        inset:SetPoint("TOPLEFT", 16, -54)
        inset:SetPoint("TOPRIGHT", -16, -54)
        inset:SetHeight(250)
        inset:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        inset:SetBackdropColor(0.02, 0.03, 0.05, 0.95)
        inset:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.9)

        local function AddNotice(parent, yOffset, tag, tagColor, body)
            local tagFs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            tagFs:SetPoint("TOPLEFT", 12, yOffset)
            tagFs:SetText(string.format("|c%s%s|r", tagColor, tag))

            local bodyFs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            bodyFs:SetPoint("TOPLEFT", 12, yOffset - 18)
            bodyFs:SetPoint("RIGHT", parent, "RIGHT", -12, 0)
            bodyFs:SetJustifyH("LEFT")
            bodyFs:SetWordWrap(true)
            bodyFs:SetText(string.format("|cffb8a080%s|r", body))
            return bodyFs
        end

        AddNotice(inset, -10, "1. Local Combat Tracking (100% In-Game)", "ff10b981",
            "WoW Killboard automatically records all your PvP kills, 1v1 duels, battlegrounds, bounties, and PvE deaths directly in-game. Zero external dependencies are needed for your personal battle log!")

        AddNotice(inset, -82, "2. Global Web Sync Requires WoWKillboardSync.exe", "ffffd100",
            "To stream kills to the web leaderboard (wowkillboard.com) and download rival bounties, run our companion app: WoWKillboardSync.exe. Place it anywhere (Desktop or WoW folder) and double-click to run while playing!")

        AddNotice(inset, -158, "3. Promote & Share With Guild & Realm (/kb promo)", "ff00e5ff",
            "Want to track duels or world PvP with friends and rivals? Search 'wkb' on the CurseForge App, visit https://www.curseforge.com/wow/addons/wkb, or click [📢 Promo Macros] below for ready-to-use macros!")

        -- Web Download & Feedback Link Section
        local linkTitle = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        linkTitle:SetPoint("TOPLEFT", 16, -314)
        linkTitle:SetText("|cffffd100Companion Sync Download & Web Link (Click & press Ctrl+C to copy):|r")

        local linkBox = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        linkBox:SetPoint("TOPLEFT", 16, -334)
        linkBox:SetPoint("TOPRIGHT", -16, -334)
        linkBox:SetHeight(24)
        linkBox:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        linkBox:SetBackdropColor(0.02, 0.04, 0.08, 0.95)
        linkBox:SetBackdropBorderColor(0.25, 0.35, 0.50, 0.9)

        local eb = CreateFrame("EditBox", nil, linkBox)
        eb:SetPoint("TOPLEFT", 6, 0)
        eb:SetPoint("BOTTOMRIGHT", -6, 0)
        eb:SetFontObject("GameFontHighlightSmall")
        eb:SetAutoFocus(false)
        eb:EnableMouse(true)
        eb:SetText("https://wowkillboard.com/download")
        eb:SetScript("OnEditFocusGained", function(self)
            self:HighlightText()
        end)
        eb:SetScript("OnMouseUp", function(self)
            self:HighlightText()
        end)
        eb:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        dlg.DownloadUrlEditBox = eb

        -- Buttons Row: Feedback, Promo Macros, Open Dashboard
        local inGameFbBtn = UI:CreateButton(dlg, 180, 26, "|cff00e5ff[+] Feedback (/kb bug)|r", "GameFontHighlightSmall")
        inGameFbBtn:SetPoint("TOPLEFT", 16, -368)
        inGameFbBtn:SetScript("OnClick", function()
            if dlg.DoNotShowAgain then
                WoWKillboardSettings = WoWKillboardSettings or {}
                WoWKillboardSettings.hasSeenBetaWelcome = true
            end
            dlg:Hide()
            if UI.ShowBugReportModal then
                UI:ShowBugReportModal()
            end
        end)

        local promoBtn = UI:CreateButton(dlg, 200, 26, "|cffffd100[📢] Promo Macros (/kb promo)|r", "GameFontHighlightSmall")
        promoBtn:SetPoint("LEFT", inGameFbBtn, "RIGHT", 8, 0)
        promoBtn:SetScript("OnClick", function()
            if UI.ShowPromoModal then
                UI:ShowPromoModal()
            end
        end)

        local openKbBtn = UI:CreateButton(dlg, 180, 26, "|cff10b981Open Killboard (/kb)|r", "GameFontHighlightSmall")
        openKbBtn:SetPoint("LEFT", promoBtn, "RIGHT", 8, 0)
        openKbBtn:SetScript("OnClick", function()
            if dlg.DoNotShowAgain then
                WoWKillboardSettings = WoWKillboardSettings or {}
                WoWKillboardSettings.hasSeenBetaWelcome = true
            end
            dlg:Hide()
            UI:Toggle()
        end)

        -- Bottom Row: Checkbox & Dismiss Button
        local s = WoWKillboardSettings or {}
        dlg.DoNotShowAgain = (s.hasSeenBetaWelcome == true)

        local chkBtn = CreateFrame("Button", nil, dlg)
        chkBtn:SetSize(320, 22)
        chkBtn:SetPoint("BOTTOMLEFT", 16, 14)
        chkBtn:EnableMouse(true)

        local chkText = chkBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        chkText:SetPoint("LEFT", 0, 0)
        chkText:SetText(dlg.DoNotShowAgain and "|cff00ff00[X]|r |cffccccccDo not show again on login|r" or "|cff64748b[  ]|r |cff888888Show on login (Will appear on next login)|r")
        chkBtn.Label = chkText
        dlg.ChkBtn = chkBtn

        chkBtn:SetScript("OnClick", function()
            dlg.DoNotShowAgain = not dlg.DoNotShowAgain
            WoWKillboardSettings = WoWKillboardSettings or {}
            WoWKillboardSettings.hasSeenBetaWelcome = dlg.DoNotShowAgain
            if dlg.DoNotShowAgain then
                chkText:SetText("|cff00ff00[X]|r |cffccccccDo not show again on login|r")
            else
                chkText:SetText("|cff64748b[  ]|r |cff888888Show on login (Will appear on next login)|r")
            end
        end)

        local closeBtn = UI:CreateButton(dlg, 100, 26, "Got It!", "GameFontHighlightSmall")
        closeBtn:SetPoint("BOTTOMRIGHT", -16, 12)
        closeBtn:SetScript("OnClick", function()
            WoWKillboardSettings = WoWKillboardSettings or {}
            WoWKillboardSettings.hasSeenBetaWelcome = (dlg.DoNotShowAgain == true)
            dlg:Hide()
        end)

        -- ESC handler
        dlg:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                WoWKillboardSettings = WoWKillboardSettings or {}
                WoWKillboardSettings.hasSeenBetaWelcome = (dlg.DoNotShowAgain == true)
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        UI.WelcomeDialog = dlg
    end

    local dlg = UI.WelcomeDialog
    local currentSettings = WoWKillboardSettings or {}
    dlg.DoNotShowAgain = (currentSettings.hasSeenBetaWelcome == true)
    if dlg.ChkBtn and dlg.ChkBtn.Label then
        if dlg.DoNotShowAgain then
            dlg.ChkBtn.Label:SetText("|cff00ff00[X]|r |cffccccccDo not show again on login|r")
        else
            dlg.ChkBtn.Label:SetText("|cff64748b[  ]|r |cff888888Show on login (Will appear on next login)|r")
        end
    end

    local domain = (KB.WebDomain and KB.WebDomain ~= "") and KB.WebDomain or "wowkillboard.com"
    if dlg.DownloadUrlEditBox then
        dlg.DownloadUrlEditBox:SetText(string.format("https://%s/download", domain))
    end
    dlg:Show()
    if dlg.Raise then dlg:Raise() end
end

-- Promotional Macros & Community Sharing Modal (100% Taint-Free)
function UI:ShowPromoModal()
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open Promotional Macros window during combat.")
        return
    end

    if not UI.PromoDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(680, 620)
        dlg:SetPoint("CENTER", 0, 20)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(115)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        dlg:SetBackdropColor(0.06, 0.08, 0.12, 0.98)
        dlg:SetBackdropBorderColor(0.85, 0.68, 0.22, 1.0)

        -- Header Drag Bar
        local header = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        header:SetPoint("TOPLEFT", 1, -1)
        header:SetPoint("TOPRIGHT", -1, -1)
        header:SetHeight(28)
        header:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
        header:SetBackdropColor(0.12, 0.09, 0.06, 0.98)
        header:EnableMouse(true)
        header:RegisterForDrag("LeftButton")
        header:SetScript("OnDragStart", function() if not InCombatLockdown() then dlg:StartMoving() end end)
        header:SetScript("OnDragStop", function() dlg:StopMovingOrSizing() end)
        dlg.Header = header

        local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("LEFT", 12, 0)
        title:SetText("|cffffd100WoW KILLBOARD  -  COMMUNITY SHARING & MACROS|r")
        dlg.Title = title

        local closeX = CreateFrame("Button", nil, header)
        closeX:SetSize(22, 22)
        closeX:SetPoint("RIGHT", -4, 0)
        local closeXText = closeX:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        closeXText:SetPoint("CENTER", 0, 0)
        closeXText:SetText("|cffff4444X|r")
        closeX:SetScript("OnClick", function() dlg:Hide() end)

        local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sub:SetPoint("TOPLEFT", 16, -34)
        sub:SetText("|cff38bdf8Click inside any macro box to select, press Ctrl+C, then paste into your WoW Macro panel (/m)!|r")

        local function CreateMacroEntry(parent, yOffset, labelText, labelColor, boxHeight, postType, postLabel)
            local h = boxHeight or 44
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            lbl:SetPoint("TOPLEFT", 16, yOffset)
            lbl:SetText(string.format("|c%s%s|r", labelColor, labelText))

            local box = CreateFrame("Frame", nil, parent, "BackdropTemplate")
            box:SetPoint("TOPLEFT", 16, yOffset - 18)
            box:SetPoint("TOPRIGHT", -16, yOffset - 18)
            box:SetHeight(h)
            box:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            box:SetBackdropColor(0.02, 0.04, 0.08, 0.95)
            box:SetBackdropBorderColor(0.25, 0.35, 0.50, 0.9)

            local eb = CreateFrame("EditBox", nil, box)
            eb:SetPoint("TOPLEFT", 8, -4)
            eb:SetPoint("BOTTOMRIGHT", -8, 4)
            eb:SetFontObject("GameFontHighlightSmall")
            eb:SetMultiLine(true)
            eb:SetAutoFocus(false)
            eb:EnableMouse(true)
            eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
            eb:SetScript("OnMouseUp", function(self) self:HighlightText() end)
            eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

            if postType and postLabel then
                local postBtn = UI:CreateButton(parent, 120, 18, postLabel, "GameFontHighlightSmall")
                postBtn:SetPoint("TOPRIGHT", -16, yOffset)
                postBtn:SetScript("OnClick", function()
                    if InCombatLockdown and InCombatLockdown() then
                        SafePrint("|cffff3838[WoWKB]|r Cannot send chat messages during combat.")
                        return
                    end
                    local rawText = eb:GetText() or ""
                    if rawText == "" then return end
                    if postType == "GENERAL" then
                        local chanId = GetChannelName and (GetChannelName("General - ") or GetChannelName("General"))
                        if not chanId or chanId == 0 then chanId = 1 end
                        local clean = rawText:gsub("^/%d+%s*", "")
                        SendChatMessage(clean, "CHANNEL", nil, chanId)
                        SafePrint("|cff00ccff[WoWKB]|r Posted to General channel.")
                    elseif postType == "GUILD" then
                        if IsInGuild and IsInGuild() then
                            local clean = rawText:gsub("^/[gp]%s*", "")
                            SendChatMessage(clean, "GUILD")
                            SafePrint("|cff00ccff[WoWKB]|r Posted to Guild chat.")
                        else
                            SafePrint("|cffff9900[WoWKB]|r You are not in a guild.")
                        end
                    elseif postType == "SAY" then
                        local clean = rawText:gsub("^/s%s*", "")
                        SendChatMessage(clean, "SAY")
                        SafePrint("|cff00ccff[WoWKB]|r Posted to Say chat.")
                    end
                end)
            end

            return eb
        end

        dlg.GeneralEb = CreateMacroEntry(dlg, -56, "1. General & Zone Chat (/1 or /2):", "ffffd100", 44, "GENERAL", "|cffffd100Post to General|r")
        dlg.DuelEb = CreateMacroEntry(dlg, -126, "2. Post-Duel (Say or Whisper):", "ff00e5ff", 44, "SAY", "|cff00e5ffPost to Say|r")
        dlg.GuildEb = CreateMacroEntry(dlg, -196, "3. Guild & Group Chat (/g or /p):", "ff10b981", 44, "GUILD", "|cff10b981Post to Guild|r")
        dlg.CalloutEb = CreateMacroEntry(dlg, -266, "4. World PvP Callout (/s or /y):", "ffff4444", 44, "SAY", "|cffff4444Post to Say|r")
        dlg.LinkEb = CreateMacroEntry(dlg, -336, "5. Direct CurseForge Link (Search 'wkb' in CurseForge App):", "ff38bdf8", 30)

        -- Tip Note Box
        local tipBox = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        tipBox:SetPoint("TOPLEFT", 16, -412)
        tipBox:SetPoint("TOPRIGHT", -16, -412)
        tipBox:SetHeight(92)
        tipBox:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        tipBox:SetBackdropColor(0.04, 0.05, 0.08, 0.95)
        tipBox:SetBackdropBorderColor(0.85, 0.68, 0.22, 0.6)

        local tipText = tipBox:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        tipText:SetPoint("TOPLEFT", 10, -8)
        tipText:SetPoint("BOTTOMRIGHT", -10, 8)
        tipText:SetJustifyH("LEFT")
        tipText:SetJustifyV("TOP")
        tipText:SetWordWrap(true)
        tipText:SetText("|cffffd100How to use in-game macros:|r\n1. Type |cffffff00/macro|r or |cffffff00/m|r in chat to open your Macro panel, click |cff00e5ffNew|r, and paste with |cffffff00Ctrl+V|r.\n2. Drag the macro icon directly to your action bar for 1-click chat sharing!\n3. Search |cffffff00wkb|r in the |cff38bdf8CurseForge Desktop App|r or visit |cffffff00https://www.curseforge.com/wow/addons/wkb|r.")

        local closeBtn = UI:CreateButton(dlg, 120, 26, "Got It!", "GameFontHighlightSmall")
        closeBtn:SetPoint("BOTTOMRIGHT", -16, 14)
        closeBtn:SetScript("OnClick", function() dlg:Hide() end)

        -- ESC handler
        dlg:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        UI.PromoDialog = dlg
    end

    local enemy = "the Horde"
    if UnitFactionGroup then
        local f = UnitFactionGroup("player")
        if f == "Alliance" then
            enemy = "the Horde"
        elseif f == "Horde" then
            enemy = "the Alliance"
        end
    end

    if UI.PromoDialog.GeneralEb then
        UI.PromoDialog.GeneralEb:SetText(string.format("/1 Hey if you like world pvp, check out 'wkb' on CurseForge. Tracks your kills and stats against %s (wowkillboard.com)", enemy))
    end
    if UI.PromoDialog.DuelEb then
        UI.PromoDialog.DuelEb:SetText("/s gg! Tracking duels and world pvp kills with 'wkb' on CurseForge (wowkillboard.com)")
    end
    if UI.PromoDialog.GuildEb then
        UI.PromoDialog.GuildEb:SetText("/g Hey grab 'wkb' on CurseForge if you do world pvp. Tracks our kills, duels, and bounties in guild (wowkillboard.com)")
    end
    if UI.PromoDialog.CalloutEb then
        UI.PromoDialog.CalloutEb:SetText(string.format("/s Anyone hunting around here? Grab 'wkb' on CurseForge so we can track kills and bounties against %s (wowkillboard.com)", enemy))
    end
    if UI.PromoDialog.LinkEb then
        UI.PromoDialog.LinkEb:SetText("https://www.curseforge.com/wow/addons/wkb")
    end

    UI.PromoDialog:Show()
    if UI.PromoDialog.Raise then UI.PromoDialog:Raise() end
end

-- ============================================================================
-- Template-Free "What's New" & In-Game Changelog Dialog (100% Taint-Free)
-- ============================================================================
function UI:ShowChangelogModal(isManual)
    if InCombatLockdown and InCombatLockdown() then
        if isManual then
            SafePrint("|cffff9900[WoWKB]|r Cannot open Changelog window during combat.")
        end
        return
    end

    if not UI.ChangelogDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(660, 540)
        dlg:SetPoint("CENTER", 0, 20)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(118)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        dlg:SetBackdropColor(0.06, 0.08, 0.12, 0.98)
        dlg:SetBackdropBorderColor(0.85, 0.68, 0.22, 1.0)

        -- Header Drag Bar
        local header = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        header:SetPoint("TOPLEFT", 1, -1)
        header:SetPoint("TOPRIGHT", -1, -1)
        header:SetHeight(28)
        header:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
        header:SetBackdropColor(0.12, 0.09, 0.06, 0.98)
        header:EnableMouse(true)
        header:RegisterForDrag("LeftButton")
        header:SetScript("OnDragStart", function() if not InCombatLockdown() then dlg:StartMoving() end end)
        header:SetScript("OnDragStop", function() dlg:StopMovingOrSizing() end)
        dlg.Header = header

        local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("LEFT", 12, 0)
        title:SetText("|cffffd100WoW KILLBOARD  -  WHAT'S NEW & UPDATE LOG|r")
        dlg.Title = title

        -- Close [X] Button
        local closeX = CreateFrame("Button", nil, header)
        closeX:SetSize(22, 22)
        closeX:SetPoint("RIGHT", -4, 0)
        local closeXText = closeX:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        closeXText:SetPoint("CENTER", 0, 0)
        closeXText:SetText("|cffff4444X|r")
        closeX:SetScript("OnClick", function() dlg:Hide() end)

        -- Subtitle: Version Indicator
        local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sub:SetPoint("TOPLEFT", 16, -34)
        dlg.VersionSub = sub

        -- Inset Content Box (Scrollable / Structured text)
        local inset = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        inset:SetPoint("TOPLEFT", 16, -56)
        inset:SetPoint("TOPRIGHT", -16, -56)
        inset:SetHeight(320)
        inset:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        inset:SetBackdropColor(0.02, 0.03, 0.05, 0.95)
        inset:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.9)
        dlg.Inset = inset

        local scrollFrame = CreateFrame("ScrollFrame", nil, inset)
        scrollFrame:SetPoint("TOPLEFT", inset, "TOPLEFT", 4, -4)
        scrollFrame:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -4, 4)
        scrollFrame:EnableMouseWheel(true)
        dlg.LogScrollFrame = scrollFrame

        local content = CreateFrame("Frame", nil, scrollFrame)
        content:SetSize(618, 980)
        scrollFrame:SetScrollChild(content)

        scrollFrame:SetScript("OnMouseWheel", function(self, delta)
            local current = self:GetVerticalScroll()
            local maxScroll = math.max(0, (content:GetHeight() or 980) - self:GetHeight())
            local newScroll = math.max(0, math.min(maxScroll, current - (delta * 32)))
            self:SetVerticalScroll(newScroll)
        end)

        local function AddLogHeader(parent, yOffset, text, color)
            local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            fs:SetPoint("TOPLEFT", 14, yOffset)
            fs:SetText(string.format("|c%s%s|r", color or "ffffd100", text))
            return fs
        end

        local function AddLogBullet(parent, yOffset, tag, body)
            local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            fs:SetPoint("TOPLEFT", 18, yOffset)
            fs:SetPoint("RIGHT", parent, "RIGHT", -14, 0)
            fs:SetJustifyH("LEFT")
            fs:SetWordWrap(true)
            fs:SetText(string.format("|cff38bdf8* %s:|r |cffcbd5e1%s|r", tag, body))
            return fs
        end

        -- Version 1.0.5 (Current Release)
        AddLogHeader(content, -8, "Version 1.0.5  (Current Release)", "ffffd100")
        AddLogBullet(content, -26, "Zero UI Taint Hardening", "Strict InCombatLockdown gating on player deaths, chat broadcasts, and guild info checks eliminates Action Blocked popups.")
        AddLogBullet(content, -62, "Responsive Navigation Suite", "Fluid flex layout, mobile drawer, unclipped tactile controls, and 1180px adaptive navigation breakpoint.")
        AddLogBullet(content, -98, "Multi-Character Realm Roster", "Seamless operative switching, custom realm mains (⭐ Main), and dedicated stats tracking across all characters.")
        AddLogBullet(content, -134, "Instance Leaderboard Parity", "Dedicated combat columns for World (Kills, Solo, K/D), BGs, Duels (W/L), and Arenas.")
        AddLogBullet(content, -170, "Economy & Currency Displays", "Universal Gold / Silver / Copper (G/S/C) reward formatting and unified Marked contract highlights.")

        -- Version 1.0.4 (Release Update)
        AddLogHeader(content, -210, "Version 1.0.4  (Release Update)", "ff38bdf8")
        AddLogBullet(content, -228, "Cross-Faction Intel Parity", "Identical real-time Intel feed and leaderboard aggregates on active realm across Alliance and Horde.")
        AddLogBullet(content, -264, "Faction-Wide Mark of Spite Alerts", "Realm channel broadcast, floating on-screen banner & audio warhorn on bounty declarations.")
        AddLogBullet(content, -300, "Frontline Alert Delivery Presets", "Both Displays, Heads-Up Only, Silent Chat Log Only, and Muted (/kb alerts).")
        AddLogBullet(content, -336, "Interactive PvE vs. PvP Stats Toggle", "Seamlessly switch between Wilderness Bestiary and PvP War Room.")

        -- Version 1.0.3 (Release Update)
        AddLogHeader(content, -376, "Version 1.0.3  (Release Update)", "ffa855f7")
        AddLogBullet(content, -394, "Dynamic Accent Color Engine", "Configure classic gold, player class color, or custom hex color across headers, rank badges, toasts, and sticky standings.")
        AddLogBullet(content, -430, "ElvUI Minimalist Overhaul", "Universal 1px solid black borders, flat slate backdrops, elevated tooltip strata, and compact 3-segment top stat strip.")
        AddLogBullet(content, -466, "Cross-Realm & Ruleset Isolation", "Filters leaderboards, recent kills, bounties, and deaths strictly to your active realm ruleset (PvP, PvE, RP, HC).")
        AddLogBullet(content, -502, "Automated Theme Migration", "Existing player profiles automatically upgraded to clean modern aesthetics with zero manual resets required.")

        -- Version 1.0.2 (Release Update)
        AddLogHeader(content, -542, "Version 1.0.2  (Release Update)", "ff38bdf8")
        AddLogBullet(content, -560, "PvE Casualty Realm Broadcasts", "Cross-computer casualty alerts broadcast via dedicated 'WoWKillboard' realm channel with audio alerts.")
        AddLogBullet(content, -596, "On-Screen Casualty Toasts", "Real-time toast popups on death alerts even for unaffiliated realm players outside your party or guild.")
        AddLogBullet(content, -632, "Resilient NPC Attribution", "Automated fallback target resolution ensures wilderness executions and lethal mob strikes are never dropped.")

        -- Version 1.0.1 (Release Update)
        AddLogHeader(content, -672, "Version 1.0.1  (Release Update)", "ffa855f7")
        AddLogBullet(content, -690, "Interactive Share Modal", "Share buttons open a preview modal (like /kb promo) so you can review broadcasts before posting to /guild, /party, or /say.")
        AddLogBullet(content, -726, "Concise 1-Line Leaderboards", "Broadcasts output top 3 players with explicit [Horde] / [Alliance] tags and web CTA, strictly under 200 characters.")
        AddLogBullet(content, -762, "Live Peer Version Discovery", "Silently discovers newer versions via P2P gossip in guild & groups without touching external web sockets.")
        AddLogBullet(content, -798, "PvE Apex Predator Telemetry", "Deadliest wilderness creatures and hazard casualties tracked seamlessly on PvE realms.")
        AddLogBullet(content, -834, "Windows 11 SAC Guidance", "Full instructions for Smart App Control 'Unblock' in File Properties for zero-barrier desktop sync.")

        -- Version 1.0.0 (Launch Foundation)
        AddLogHeader(content, -874, "Version 1.0.0  (Launch Foundation)", "ff10b981")
        local baseFs = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        baseFs:SetPoint("TOPLEFT", 18, -892)
        baseFs:SetPoint("RIGHT", content, "RIGHT", -14, 0)
        baseFs:SetJustifyH("LEFT")
        baseFs:SetWordWrap(true)
        baseFs:SetText("|cff94a3b8* Dual UI themes (Classic Stone & ElvUI Dark via /kb theme)\n* Certified 1v1 solo kill engine with 15s gang-clustering\n* Cross-client parity across Forever Beta, Era, Anniversary & Retail\n* Blood Ledger in-game bounties & KOS debtor blacklists|r")

        -- Links Box: CurseForge & GitHub Releases
        local linkTitle = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        linkTitle:SetPoint("TOPLEFT", 16, -386)
        linkTitle:SetText("|cffffd100Download & Update Links (Click inside & press Ctrl+C to copy):|r")

        local function CreateCopyLink(parent, x, y, width, label, url)
            local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            lbl:SetPoint("TOPLEFT", x, y)
            lbl:SetText(string.format("|cff38bdf8%s|r", label))

            local box = CreateFrame("Frame", nil, parent, "BackdropTemplate")
            box:SetPoint("TOPLEFT", x, y - 16)
            box:SetSize(width, 22)
            box:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            box:SetBackdropColor(0.02, 0.04, 0.08, 0.95)
            box:SetBackdropBorderColor(0.25, 0.35, 0.50, 0.9)

            local eb = CreateFrame("EditBox", nil, box)
            eb:SetPoint("TOPLEFT", 6, 0)
            eb:SetPoint("BOTTOMRIGHT", -6, 0)
            eb:SetFontObject("GameFontHighlightSmall")
            eb:SetAutoFocus(false)
            eb:EnableMouse(true)
            eb:SetText(url)
            eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
            eb:SetScript("OnMouseUp", function(self) self:HighlightText() end)
            eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
            return eb
        end

        dlg.CfEditBox = CreateCopyLink(dlg, 16, -406, 305, "CurseForge App (Search 'wkb'):", "https://www.curseforge.com/wow/addons/wkb")
        dlg.WebEditBox = CreateCopyLink(dlg, 335, -406, 305, "GitHub Releases & Direct Download:", "https://github.com/dagariane-commits/WoW_Killboard/releases")

        -- Bottom Row Buttons
        local promoBtn = UI:CreateButton(dlg, 180, 26, "|cffffd100Promo Macros (/kb promo)|r", "GameFontHighlightSmall")
        promoBtn:SetPoint("BOTTOMLEFT", 16, 14)
        promoBtn:SetScript("OnClick", function()
            dlg:Hide()
            if UI.ShowPromoModal then UI:ShowPromoModal() end
        end)

        local openKbBtn = UI:CreateButton(dlg, 180, 26, "|cff10b981Open Killboard (/kb)|r", "GameFontHighlightSmall")
        openKbBtn:SetPoint("LEFT", promoBtn, "RIGHT", 10, 0)
        openKbBtn:SetScript("OnClick", function()
            dlg:Hide()
            if UI.Toggle then UI:Toggle() end
        end)

        local gotItBtn = UI:CreateButton(dlg, 100, 26, "Got It!", "GameFontHighlightSmall")
        gotItBtn:SetPoint("BOTTOMRIGHT", -16, 14)
        gotItBtn:SetScript("OnClick", function() dlg:Hide() end)

        local bcastTestBtn = UI:CreateButton(dlg, 200, 26, "|cff38bdf8Test Broadcast (Party/Net)|r", "GameFontHighlightSmall")
        bcastTestBtn:SetPoint("RIGHT", gotItBtn, "LEFT", -10, 0)
        bcastTestBtn:SetScript("OnClick", function()
            if KB.Sync and KB.Sync.BroadcastTestCasualty then
                KB.Sync:BroadcastTestCasualty("pve")
            end
        end)
        bcastTestBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cff38bdf8Test Broadcast (Party/Net)|r", "Dispatches a simulated casualty across your Party, Guild, and Realm network to verify toasts on other computers. (0 database writes).")
        end)
        bcastTestBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)

        -- ESC handler
        dlg:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        UI.ChangelogDialog = dlg
    end

    local dlg = UI.ChangelogDialog
    local latest = KB.LatestKnownVersion or (WoWKillboard_RealmData and WoWKillboard_RealmData.LatestVersion) or KB.Version
    if KB.Version == latest then
        dlg.VersionSub:SetText(string.format("|cff10b981Installed: v%s (Up to date)|r  |  |cff888888Cross-Client Unified Architecture|r", KB.Version))
    else
        dlg.VersionSub:SetText(string.format("|cffff9900Installed: v%s|r  |  |cff00ff00New Version Available: v%s!|r  |  |cff38bdf8Update via CurseForge|r", KB.Version, latest))
    end

    if dlg.LogScrollFrame then
        dlg.LogScrollFrame:SetVerticalScroll(0)
    end

    dlg:Show()
    if dlg.Raise then dlg:Raise() end
end

-- ============================================================================
-- Realm Update Broadcaster & Administrative Alert Modal (100% Zero-Taint)
-- ============================================================================
function UI:ShowAnnouncementModal()
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open announcement modal during combat.")
        return
    end

    if not UI.AnnouncementDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(580, 320)
        dlg:SetPoint("CENTER", 0, 40)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(110)
        dlg:EnableMouse(true)
        dlg:SetMovable(true)
        dlg:SetClampedToScreen(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        dlg:SetBackdropColor(0.04, 0.05, 0.08, 0.98)
        dlg:SetBackdropBorderColor(0.45, 0.35, 0.18, 0.95)

        -- Header Drag Bar
        local header = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        header:SetPoint("TOPLEFT", 1, -1)
        header:SetPoint("TOPRIGHT", -1, -1)
        header:SetHeight(28)
        header:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
        header:SetBackdropColor(0.12, 0.09, 0.06, 0.98)
        header:EnableMouse(true)
        header:RegisterForDrag("LeftButton")
        header:SetScript("OnDragStart", function() if not InCombatLockdown() then dlg:StartMoving() end end)
        header:SetScript("OnDragStop", function() dlg:StopMovingOrSizing() end)

        local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("LEFT", 12, 0)
        title:SetText("|cffffd100WoW KILLBOARD  -  REALM UPDATE BROADCASTER|r")

        local closeX = CreateFrame("Button", nil, header)
        closeX:SetSize(22, 22)
        closeX:SetPoint("RIGHT", -4, 0)
        local closeXText = closeX:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        closeXText:SetPoint("CENTER", 0, 0)
        closeXText:SetText("|cffff4444X|r")
        closeX:SetScript("OnClick", function() dlg:Hide() end)

        -- Subtitle & Instructions
        local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sub:SetPoint("TOPLEFT", 16, -34)
        sub:SetText("|cff38bdf8Broadcast update warnings & system alerts across WoWKillboard realm network|r")

        local desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        desc:SetPoint("TOPLEFT", 16, -52)
        desc:SetPoint("RIGHT", -16, 0)
        desc:SetJustifyH("LEFT")
        desc:SetWordWrap(true)
        desc:SetText("|cff94a3b8Send alerts to the dedicated 'WoWKillboard' channel and party/guild network to notify active players before pushing an addon release or restart.|r")

        -- Edit Box Frame
        local ebBg = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        ebBg:SetPoint("TOPLEFT", 16, -88)
        ebBg:SetPoint("TOPRIGHT", -16, -88)
        ebBg:SetHeight(76)
        ebBg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebBg:SetBackdropColor(0.02, 0.03, 0.05, 0.95)
        ebBg:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.9)

        local eb = CreateFrame("EditBox", nil, ebBg)
        eb:SetPoint("TOPLEFT", 8, -6)
        eb:SetPoint("BOTTOMRIGHT", -8, 6)
        eb:SetFontObject("GameFontHighlight")
        eb:SetAutoFocus(false)
        eb:SetMultiLine(true)
        eb:EnableMouse(true)
        eb:SetText("Addon update releasing in 10 minutes. Please save combat records and prepare to update via CurseForge or GitHub.")
        dlg.MessageEditBox = eb

        -- Presets Row Label
        local pLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        pLabel:SetPoint("TOPLEFT", 16, -174)
        pLabel:SetText("|cffffd100Quick Presets:|r")

        -- Preset Buttons
        local btn10m = UI:CreateButton(dlg, 115, 24, "10-Min Warning", "GameFontHighlightSmall")
        btn10m:SetPoint("LEFT", pLabel, "RIGHT", 10, 0)
        btn10m:SetScript("OnClick", function()
            eb:SetText("Addon update releasing in 10 minutes. Please save combat records and prepare to update via CurseForge or GitHub.")
        end)

        local btn5m = UI:CreateButton(dlg, 115, 24, "5-Min Warning", "GameFontHighlightSmall")
        btn5m:SetPoint("LEFT", btn10m, "RIGHT", 8, 0)
        btn5m:SetScript("OnClick", function()
            eb:SetText("Addon update releasing in 5 minutes! Please prepare to exit WoW or /reload once updated.")
        end)

        local btn1m = UI:CreateButton(dlg, 115, 24, "1-Min Urgent", "GameFontHighlightSmall")
        btn1m:SetPoint("LEFT", btn5m, "RIGHT", 8, 0)
        btn1m:SetScript("OnClick", function()
            eb:SetText("Addon update releasing in 1 minute! Final warning to save combat records and /reload.")
        end)

        local btnLive = UI:CreateButton(dlg, 105, 24, "Update Live!", "GameFontHighlightSmall")
        btnLive:SetPoint("LEFT", btn1m, "RIGHT", 8, 0)
        btnLive:SetScript("OnClick", function()
            eb:SetText("New addon update is now live on CurseForge & GitHub! Please /reload or restart WoW to update.")
        end)

        -- Bottom Divider
        local bDiv = dlg:CreateTexture(nil, "ARTWORK")
        bDiv:SetHeight(1)
        bDiv:SetPoint("TOPLEFT", 16, -214)
        bDiv:SetPoint("TOPRIGHT", -16, -214)
        bDiv:SetColorTexture(0.35, 0.28, 0.16, 0.8)

        -- Action Buttons
        local bcastBtn = UI:CreateButton(dlg, 260, 30, "|cffffd100Broadcast Alert to Realm Network|r", "GameFontNormal")
        bcastBtn:SetPoint("BOTTOMLEFT", 16, 16)
        bcastBtn:SetScript("OnClick", function()
            local text = eb:GetText()
            if text and not text:match("^%s*$") then
                if KB.Sync and KB.Sync.BroadcastAdminAlert then
                    KB.Sync:BroadcastAdminAlert(text, "UPDATE")
                end
                dlg:Hide()
            end
        end)

        local testNetBtn = UI:CreateButton(dlg, 190, 30, "|cff38bdf8Test Broadcast (Party/Net)|r", "GameFontHighlightSmall")
        testNetBtn:SetPoint("LEFT", bcastBtn, "RIGHT", 10, 0)
        testNetBtn:SetScript("OnClick", function()
            if KB.Sync and KB.Sync.BroadcastTestCasualty then
                KB.Sync:BroadcastTestCasualty("pve")
            end
        end)

        local cancelBtn = UI:CreateButton(dlg, 80, 30, "Close", "GameFontHighlight")
        cancelBtn:SetPoint("BOTTOMRIGHT", -16, 16)
        cancelBtn:SetScript("OnClick", function() dlg:Hide() end)

        -- ESC handler
        dlg:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        UI.AnnouncementDialog = dlg
    end

    UI.AnnouncementDialog:Show()
    if UI.AnnouncementDialog.Raise then UI.AnnouncementDialog:Raise() end
end

-- ============================================================================
-- Template-Free Bug Report & AI Diagnostics Dispatch Dialog
-- ============================================================================
function UI:ShowBugReportModal()
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open bug report dialog during combat.")
        return
    end

    if not UI.BugReportDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(520, 360)
        dlg:SetPoint("CENTER")
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(105)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        dlg:SetBackdropColor(0.06, 0.07, 0.10, 0.98)
        dlg:SetBackdropBorderColor(0.85, 0.68, 0.22, 1.0)

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -14)
        title:SetText("|cffffd100WoW Killboard  -  Feedback & Bug Dispatch|r")
        dlg.Title = title

        local desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        desc:SetPoint("TOP", 0, -36)
        desc:SetText("Submit player feedback, balance suggestions, or report combat glitches:")
        dlg.Desc = desc

        local tStrip = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        tStrip:SetPoint("TOPLEFT", dlg, "TOPLEFT", 16, -56)
        tStrip:SetPoint("TOPRIGHT", dlg, "TOPRIGHT", -16, -56)
        tStrip:SetHeight(28)
        tStrip:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        tStrip:SetBackdropColor(0.02, 0.04, 0.08, 0.9)
        tStrip:SetBackdropBorderColor(0.2, 0.3, 0.45, 0.7)

        local tLabel = tStrip:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        tLabel:SetPoint("CENTER", 0, 0)
        dlg.TelemetryLabel = tLabel

        local inset = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        inset:SetPoint("TOPLEFT", tStrip, "BOTTOMLEFT", 0, -10)
        inset:SetPoint("BOTTOMRIGHT", dlg, "BOTTOMRIGHT", -16, 52)
        inset:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        inset:SetBackdropColor(0.02, 0.03, 0.05, 0.95)
        inset:SetBackdropBorderColor(0.35, 0.28, 0.16, 0.9)

        local scrollFrame = CreateFrame("ScrollFrame", nil, inset)
        scrollFrame:SetPoint("TOPLEFT", inset, "TOPLEFT", 8, -8)
        scrollFrame:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -8, 8)
        scrollFrame:EnableMouseWheel(true)

        local eb = CreateFrame("EditBox", nil, scrollFrame)
        eb:SetMultiLine(true)
        eb:SetMaxLetters(2000)
        eb:EnableMouse(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject("ChatFontNormal")
        eb:SetWidth(460)
        eb:SetScript("OnEscapePressed", function() dlg:Hide() end)
        scrollFrame:SetScrollChild(eb)
        scrollFrame:SetScript("OnMouseWheel", function(self, delta)
            local current = self:GetVerticalScroll()
            local maxScroll = math.max(0, eb:GetHeight() - self:GetHeight())
            local newScroll = math.max(0, math.min(maxScroll, current - (delta * 30)))
            self:SetVerticalScroll(newScroll)
        end)
        dlg.EditBox = eb

        local submitBtn = UI:CreateButton(dlg, 190, 26, "|cffffffffSubmit Feedback / Bug|r", "GameFontHighlightSmall")
        submitBtn:SetPoint("BOTTOMLEFT", 16, 14)
        submitBtn:SetScript("OnClick", function()
            local text = eb:GetText()
            if not text or text:match("^%s*$") then
                SafePrint("|cffff9900[WoWKB]|r Please describe what happened before submitting.")
                return
            end
            if KB and KB.SubmitBugReport then
                local tid = KB:SubmitBugReport(text)
                if tid then
                    dlg:Hide()
                end
            end
        end)

        local cancelBtn = UI:CreateButton(dlg, 100, 26, "Close", "GameFontHighlightSmall")
        cancelBtn:SetPoint("BOTTOMRIGHT", -16, 14)
        cancelBtn:SetScript("OnClick", function()
            dlg:Hide()
        end)

        UI.BugReportDialog = dlg
    end

    local dlg = UI.BugReportDialog
    local pName = UnitName("player") or "Player"
    local flavor = KB.ClientFlavor or "CLASSIC_ERA"
    local zName = GetRealZoneText() or "Wilderness"
    local subZ = GetSubZoneText() or ""
    local zStr = (subZ ~= "") and string.format("%s (%s)", zName, subZ) or zName

    dlg.TelemetryLabel:SetText(string.format("|cff00e5ffClient:|r %s | |cffffd100Champion:|r %s | |cff10b981Sector:|r %s", flavor, pName, zStr))
    dlg.EditBox:SetText("")
    dlg:Show()
    dlg.EditBox:SetFocus()
    if dlg.Raise then dlg:Raise() end
end

-- Isolated, Taint-Free Bounty Dialog Frame (Anonymous, 100% Template-Free)
function UI:ShowBountyPrompt()
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open Mark of Spite dialog during combat.")
        return
    end

    if IsInInstance then
        local inInst, instType = IsInInstance()
        if inInst or (instType and instType ~= "none") then
            SafePrint("|cffff0000[WoWKB Error]|r Marks of Spite can only be declared upon the open battlefields of Azeroth (Open World PvP only).")
            return
        end
    end

    if not UI.BountyDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(420, 205)
        dlg:SetPoint("CENTER")
        dlg:SetFrameStrata("DIALOG")
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        dlg:SetBackdropColor(0.08, 0.09, 0.12, 0.98)
        dlg:SetBackdropBorderColor(1.0, 0.84, 0.0, 0.8)

        local t = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        t:SetPoint("TOP", 0, -14)
        t:SetText("|cffff3333Declare Mark of Spite|r")

        local desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        desc:SetPoint("TOP", 0, -36)
        desc:SetText("Sanction an open-world hunt on a hostile adversary.")

        -- Target Name Row
        local targetLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        targetLabel:SetPoint("TOPLEFT", 28, -66)
        targetLabel:SetText("Target Name:")

        local ebName = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebName:SetSize(220, 24)
        ebName:SetPoint("LEFT", targetLabel, "RIGHT", 14, 0)
        ebName:SetAutoFocus(false)
        ebName:SetFontObject("GameFontHighlight")
        ebName:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebName:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebName:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebName:SetTextInsets(6, 6, 0, 0)
        dlg.targetBox = ebName

        -- Mark Amount Row (Gold, Silver, Copper)
        local amtLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        amtLabel:SetPoint("TOPLEFT", 28, -104)
        amtLabel:SetText("Mark Amount:")

        -- Gold Box
        local ebGold = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebGold:SetSize(54, 24)
        ebGold:SetPoint("LEFT", amtLabel, "RIGHT", 14, 0)
        ebGold:SetAutoFocus(false)
        ebGold:SetNumeric(true)
        ebGold:SetNumber(0)
        ebGold:SetFontObject("GameFontHighlight")
        ebGold:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebGold:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebGold:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebGold:SetTextInsets(4, 4, 0, 0)
        dlg.goldBox = ebGold

        local gIcon = dlg:CreateTexture(nil, "ARTWORK")
        gIcon:SetSize(14, 14)
        gIcon:SetPoint("LEFT", ebGold, "RIGHT", 4, 0)
        gIcon:SetTexture("Interface\\MoneyFrame\\UI-GoldIcon")

        -- Silver Box
        local ebSilver = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebSilver:SetSize(40, 24)
        ebSilver:SetPoint("LEFT", gIcon, "RIGHT", 8, 0)
        ebSilver:SetAutoFocus(false)
        ebSilver:SetNumeric(true)
        ebSilver:SetNumber(0)
        ebSilver:SetFontObject("GameFontHighlight")
        ebSilver:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebSilver:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebSilver:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebSilver:SetTextInsets(4, 4, 0, 0)
        dlg.silverBox = ebSilver

        local sIcon = dlg:CreateTexture(nil, "ARTWORK")
        sIcon:SetSize(14, 14)
        sIcon:SetPoint("LEFT", ebSilver, "RIGHT", 4, 0)
        sIcon:SetTexture("Interface\\MoneyFrame\\UI-SilverIcon")

        -- Copper Box
        local ebCopper = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebCopper:SetSize(40, 24)
        ebCopper:SetPoint("LEFT", sIcon, "RIGHT", 8, 0)
        ebCopper:SetAutoFocus(false)
        ebCopper:SetNumeric(true)
        ebCopper:SetNumber(1)
        ebCopper:SetFontObject("GameFontHighlight")
        ebCopper:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebCopper:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebCopper:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebCopper:SetTextInsets(4, 4, 0, 0)
        dlg.copperBox = ebCopper

        local cIcon = dlg:CreateTexture(nil, "ARTWORK")
        cIcon:SetSize(14, 14)
        cIcon:SetPoint("LEFT", ebCopper, "RIGHT", 4, 0)
        cIcon:SetTexture("Interface\\MoneyFrame\\UI-CopperIcon")

        local note = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        note:SetPoint("TOP", 0, -140)
        note:SetText("|cff888888Awarded to the hunter who delivers the final killing blow (Open World only).|r")

        -- Buttons: Declare Mark and Cancel
        local okBtn = UI:CreateButton(dlg, 130, 26, "Declare Mark")
        okBtn:SetPoint("BOTTOMLEFT", 45, 16)
        okBtn:SetScript("OnClick", function()
            local targetName = (ebName:GetText() or ""):match("^%s*(.-)%s*$")
            if not targetName or targetName == "" then
                SafePrint("|cffff0000[WoWKB Error]|r Target Name cannot be empty.")
                return
            end
            local gold = tonumber(ebGold:GetText()) or 0
            local silver = tonumber(ebSilver:GetText()) or 0
            local copper = tonumber(ebCopper:GetText()) or 0
            local totalCopper = (gold * 10000) + (silver * 100) + copper
            if totalCopper <= 0 then
                SafePrint("|cffff0000[WoWKB Error]|r Mark amount must be greater than 0.")
                return
            end

            local success = KB.BountyEngine:PlaceBounty(targetName, "UNKNOWN", "Unknown", totalCopper, nil, true)
            if success then
                dlg:Hide()
                if UI.RefreshIfVisible then UI:RefreshIfVisible() end
            end
        end)

        local cancelBtn = UI:CreateButton(dlg, 110, 26, "Cancel")
        cancelBtn:SetPoint("BOTTOMRIGHT", -45, 16)
        cancelBtn:SetScript("OnClick", function() dlg:Hide() end)

        UI.BountyDialog = dlg
    end

    UI.BountyDialog.targetBox:SetText("")
    UI.BountyDialog.goldBox:SetText("0")
    UI.BountyDialog.silverBox:SetText("0")
    UI.BountyDialog.copperBox:SetText("1")
    UI.BountyDialog:Show()
    UI.BountyDialog.targetBox:SetFocus()
end

-- Death Bounty Prompt Dialog: Triggered when player is slain in PvP (Open World Only)
function UI:ShowDeathBountyPrompt(killerData)
    if not killerData or not killerData.name then return end
    local s = WoWKillboardSettings or KB.DefaultSettings or {}
    if s.promptMarkOnDeath == false or s.promptBountyOnDeath == false or s.ignoreDeathBounties == true then
        return
    end
    if InCombatLockdown() then
        UI.PendingDeathBountyKiller = killerData
        return
    end

    if IsInInstance then
        local inInst, instType = IsInInstance()
        if inInst or (instType and (instType == "pvp" or instType == "arena" or instType ~= "none")) then return end
    end

    if not UI.DeathBountyDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(460, 224)
        dlg:SetPoint("CENTER", 0, 80)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(100)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)

        local theme = UI:GetTheme()
        dlg:SetBackdrop(theme and theme.modalBackdrop or {
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        dlg:SetBackdropColor(0.08, 0.05, 0.05, 0.98)
        dlg:SetBackdropBorderColor(1.0, 0.25, 0.25, 1.0)

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText("|cffff2222FALLEN IN BATTLE  -  THE MARKED CONTRACT|r")

        local desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        desc:SetPoint("TOP", 0, -46)
        desc:SetJustifyH("CENTER")
        dlg.DescText = desc

        local amtLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        amtLabel:SetPoint("TOPLEFT", 48, -96)
        amtLabel:SetText("Mark Amount:")

        -- Gold Box
        local ebGold = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebGold:SetSize(54, 24)
        ebGold:SetPoint("LEFT", amtLabel, "RIGHT", 14, 0)
        ebGold:SetAutoFocus(false)
        ebGold:SetNumeric(true)
        ebGold:SetNumber(0)
        ebGold:SetFontObject("GameFontHighlight")
        ebGold:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebGold:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebGold:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebGold:SetTextInsets(4, 4, 0, 0)
        dlg.goldBox = ebGold

        local gIcon = dlg:CreateTexture(nil, "ARTWORK")
        gIcon:SetSize(14, 14)
        gIcon:SetPoint("LEFT", ebGold, "RIGHT", 4, 0)
        gIcon:SetTexture("Interface\\MoneyFrame\\UI-GoldIcon")

        -- Silver Box
        local ebSilver = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebSilver:SetSize(40, 24)
        ebSilver:SetPoint("LEFT", gIcon, "RIGHT", 8, 0)
        ebSilver:SetAutoFocus(false)
        ebSilver:SetNumeric(true)
        ebSilver:SetNumber(0)
        ebSilver:SetFontObject("GameFontHighlight")
        ebSilver:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebSilver:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebSilver:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebSilver:SetTextInsets(4, 4, 0, 0)
        dlg.silverBox = ebSilver

        local sIcon = dlg:CreateTexture(nil, "ARTWORK")
        sIcon:SetSize(14, 14)
        sIcon:SetPoint("LEFT", ebSilver, "RIGHT", 4, 0)
        sIcon:SetTexture("Interface\\MoneyFrame\\UI-SilverIcon")

        -- Copper Box
        local ebCopper = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebCopper:SetSize(40, 24)
        ebCopper:SetPoint("LEFT", sIcon, "RIGHT", 8, 0)
        ebCopper:SetAutoFocus(false)
        ebCopper:SetNumeric(true)
        ebCopper:SetNumber(1)
        ebCopper:SetFontObject("GameFontHighlight")
        ebCopper:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebCopper:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebCopper:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebCopper:SetTextInsets(4, 4, 0, 0)
        dlg.copperBox = ebCopper

        local cIcon = dlg:CreateTexture(nil, "ARTWORK")
        cIcon:SetSize(14, 14)
        cIcon:SetPoint("LEFT", ebCopper, "RIGHT", 4, 0)
        cIcon:SetTexture("Interface\\MoneyFrame\\UI-CopperIcon")

        local note = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        note:SetPoint("TOP", 0, -136)
        note:SetText("|cff888888Execution contract awarded only to the hunter who lands the final blow (Open World only).|r")

        local okBtn = UI:CreateButton(dlg, 126, 26, "Declare Mark")
        okBtn:SetPoint("BOTTOMLEFT", 20, 16)
        okBtn:SetScript("OnClick", function()
            local gold = tonumber(ebGold:GetText()) or 0
            local silver = tonumber(ebSilver:GetText()) or 0
            local copper = tonumber(ebCopper:GetText()) or 0
            local totalCopper = (gold * 10000) + (silver * 100) + copper
            if totalCopper > 0 and dlg.CurrentKiller then
                local k = dlg.CurrentKiller
                local success = KB.BountyEngine:PlaceBounty(k.name, k.class or "UNKNOWN", k.faction or "Unknown", totalCopper, k.guid, true)
                if success then
                    dlg:Hide()
                    if UI.RefreshIfVisible then UI:RefreshIfVisible() end
                end
            end
        end)

        local neverBtn = UI:CreateButton(dlg, 134, 26, "Never Ask Again")
        neverBtn:SetPoint("LEFT", okBtn, "RIGHT", 8, 0)
        neverBtn:SetScript("OnClick", function()
            local curSettings = WoWKillboardSettings or KB.DefaultSettings or {}
            curSettings.ignoreDeathBounties = true
            if KB.db and KB.db.settings then KB.db.settings.ignoreDeathBounties = true end
            dlg:Hide()
            SafePrint("|cffff9900[WoWKB]|r Mark of Spite death prompts disabled. You can re-enable anytime in Settings.")
        end)

        local cancelBtn = UI:CreateButton(dlg, 110, 26, "Cancel")
        cancelBtn:SetPoint("BOTTOMRIGHT", -20, 16)
        cancelBtn:SetScript("OnClick", function()
            dlg:Hide()
        end)

        UI.DeathBountyDialog = dlg
    end

    UI.DeathBountyDialog.CurrentKiller = killerData
    UI.DeathBountyDialog.DescText:SetText(string.format("The soil drinks your blood! |cffff3333%s|r has slain you in open combat.\nDeclare a Mark of Spite for their head upon a pike!", killerData.name))
    UI.DeathBountyDialog.goldBox:SetText("0")
    UI.DeathBountyDialog.silverBox:SetText("0")
    UI.DeathBountyDialog.copperBox:SetText("1")
    UI.DeathBountyDialog:Show()
    if UI.DeathBountyDialog.Raise then UI.DeathBountyDialog:Raise() end
end

-- Reinforcement Alert Dialog: Displayed to guildmates and allies when a War Horn is sounded
function UI:ShowReinforcementAlert(beaconData)
    if not beaconData or not beaconData.character_name then return end
    if InCombatLockdown() then return end

    if not UI.ReinforcementDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(460, 230)
        dlg:SetPoint("CENTER", 0, 100)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(110)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 2,
        })
        dlg:SetBackdropColor(0.08, 0.04, 0.04, 0.98)
        dlg:SetBackdropBorderColor(1.0, 0.2, 0.2, 1.0)

        -- Safe ESC key handling (100% taint-free, only active when shown)
        dlg:EnableKeyboard(false)
        dlg:SetScript("OnShow", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(true) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnHide", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(false) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnKeyDown", function(self, key)
            if not self:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
                return
            end
            if key == "ESCAPE" then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                self:Hide()
            else
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            end
        end)

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText("|cffff2222 WAR HORN: CALL TO ARMS!|r")

        local body = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        body:SetPoint("TOP", 0, -48)
        body:SetJustifyH("CENTER")
        dlg.BodyText = body

        local threat = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        threat:SetPoint("TOP", 0, -100)
        threat:SetJustifyH("CENTER")
        dlg.ThreatText = threat

        local gps = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        gps:SetPoint("TOP", 0, -140)
        dlg.GpsText = gps

        local joinBtn = UI:CreateButton(dlg, 180, 28, " Answer the Call")
        joinBtn:SetPoint("BOTTOMLEFT", 30, 20)
        joinBtn:SetScript("OnClick", function()
            if dlg.CurrentBeacon and dlg.CurrentBeacon.character_name then
                local target = dlg.CurrentBeacon.character_name
                SendChatMessage("rally", "WHISPER", nil, target)
                SafePrint(string.format("|cff00ff00[WoWKB]|r Answering the call for |cffffd100%s|r! Marching to reinforce in %s!", target, dlg.CurrentBeacon.zone or "Wilderness"))
                dlg:Hide()
            end
        end)

        local dismissBtn = UI:CreateButton(dlg, 130, 28, "Dismiss")
        dismissBtn:SetPoint("BOTTOMRIGHT", -30, 20)
        dismissBtn:SetScript("OnClick", function()
            dlg:Hide()
        end)

        UI.ReinforcementDialog = dlg
    end

    UI.ReinforcementDialog.CurrentBeacon = beaconData
    local classColor = "00ccff"
    if KB.Config and KB.Config.ClassColors and beaconData.character_class then
        local c = KB.Config.ClassColors[beaconData.character_class:upper()]
        if c then classColor = string.format("%02x%02x%02x", math.floor(c[1]*255), math.floor(c[2]*255), math.floor(c[3]*255)) end
    end

    UI.ReinforcementDialog.BodyText:SetText(string.format(
        "Blood calls to blood! Ally |cff%s%s|r (Lvl %d %s) is taking fire in |cffffd100%s|r%s!",
        classColor,
        beaconData.character_name,
        beaconData.character_level or 60,
        beaconData.character_class or "WARRIOR",
        beaconData.zone or "Wilderness",
        (beaconData.subzone and beaconData.subzone ~= "") and string.format(" (|cffaaaaaa%s|r)", beaconData.subzone) or ""
    ))

    UI.ReinforcementDialog.ThreatText:SetText(string.format(
        "Ambushed by: |cffff4444%d Enemy Player(s)|r\n|cffffaa00%s|r",
        beaconData.hostile_count or 1,
        beaconData.hostile_names or "Unknown Hostiles"
    ))

    UI.ReinforcementDialog.GpsText:SetText(string.format(
        "Coordinates: (%.1f, %.1f) | Guild: <%s>",
        beaconData.coord_x or 0,
        beaconData.coord_y or 0,
        beaconData.guild_name or "Unaligned"
    ))

    UI.ReinforcementDialog:Show()
    if UI.ReinforcementDialog.Raise then UI.ReinforcementDialog:Raise() end
end

-- KOS Blacklist & Deserter Alert Dialog
function UI:ShowKOSAlert(targetName, guildOrFormer, alertType, reason)
    if InCombatLockdown() then return end
    if not targetName then return end

    if not UI.KOSDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(460, 210)
        dlg:SetPoint("CENTER", 0, 160)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(115)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 2,
        })
        dlg:SetBackdropColor(0.12, 0.02, 0.02, 0.98)
        dlg:SetBackdropBorderColor(1.0, 0.0, 0.0, 1.0)

        dlg:EnableKeyboard(false)
        dlg:SetScript("OnShow", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(true) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnHide", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(false) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnKeyDown", function(self, key)
            if not self:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
                return
            end
            if key == "ESCAPE" then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                self:Hide()
            else
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            end
        end)

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        dlg.TitleText = title

        local body = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        body:SetPoint("TOP", 0, -48)
        body:SetJustifyH("CENTER")
        dlg.BodyText = body

        local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        sub:SetPoint("TOP", 0, -110)
        dlg.SubText = sub

        local spotBtn = UI:CreateButton(dlg, 180, 28, " Broadcast Spot")
        spotBtn:SetPoint("BOTTOMLEFT", 30, 20)
        spotBtn:SetScript("OnClick", function()
            if KB.IntelScanner then
                KB.IntelScanner:SpotTarget("KOS Target Spotted!")
            end
            dlg:Hide()
        end)

        local dismissBtn = UI:CreateButton(dlg, 130, 28, "Dismiss")
        dismissBtn:SetPoint("BOTTOMRIGHT", -30, 20)
        dismissBtn:SetScript("OnClick", function()
            dlg:Hide()
        end)

        UI.KOSDialog = dlg
    end

    if alertType == "DESERTER" then
        UI.KOSDialog.TitleText:SetText("|cffff0000[!] KOS DESERTER DETECTED!|r")
        UI.KOSDialog.BodyText:SetText(string.format("Enemy |cffffd100%s|r is serving a |cffff333330-Day Deserter Penance|r!\nFormer Guild: |cffff5555<%s>|r", targetName, guildOrFormer or "Unknown"))
        UI.KOSDialog.SubText:SetText("Branded for deserting a defeated guild. Kill on sight with zero mercy!")
    elseif alertType == "GUILD_KOS" then
        UI.KOSDialog.TitleText:SetText("|cffff0000[!] GUILD KOS BLACKLIST!|r")
        UI.KOSDialog.BodyText:SetText(string.format("Enemy |cffffd100%s|r (<%s>) belongs to a |cffff3333Blacklisted Guild|r!\nReason: %s", targetName, guildOrFormer or "Unknown", reason or "Realm Feud Defeat"))
        UI.KOSDialog.SubText:SetText("The entire guild is marked for eradication across all territories.")
    else
        UI.KOSDialog.TitleText:SetText("|cffff0000[!] KOS BLACKLIST TARGET!|r")
        UI.KOSDialog.BodyText:SetText(string.format("Hostile |cffffd100%s|r is officially branded on the |cffff3333KOS Blacklist|r!", targetName))
        UI.KOSDialog.SubText:SetText(reason or "Realm KOS Order")
    end

    UI.KOSDialog:Show()
    if UI.KOSDialog.Raise then UI.KOSDialog:Raise() end
end

-- ----------------------------------------------------------------------------
-- RareScanner-Style Bounty Proximity Radar Alert (100% Template-Free, Zero-Taint)
-- ----------------------------------------------------------------------------
function UI:ShowBountyProximityAlert(targetName, targetClass, targetGuild, targetFaction, amountCopper, zone, bountyIds)
    if InCombatLockdown() then return end
    if not targetName then return end

    if not UI.BountyProximityDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(480, 210)
        dlg:SetPoint("CENTER", 0, 160)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(120)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)
        dlg:RegisterForDrag("LeftButton")
        dlg:SetScript("OnDragStart", function(self)
            if not InCombatLockdown() then self:StartMoving() end
        end)
        dlg:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
        end)

        dlg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 2,
        })
        dlg:SetBackdropColor(0.12, 0.08, 0.03, 0.98)
        dlg:SetBackdropBorderColor(1.0, 0.82, 0.0, 1.0)

        dlg:EnableKeyboard(false)
        dlg:SetScript("OnShow", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(true) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnHide", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(false) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnKeyDown", function(self, key)
            if not self:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
                return
            end
            if key == "ESCAPE" then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                self:Hide()
            else
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            end
        end)

        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        dlg.TitleText = title

        local iconFrame = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        iconFrame:SetSize(28, 28)
        iconFrame:SetPoint("TOPLEFT", 28, -50)
        iconFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        iconFrame:SetBackdropColor(0, 0, 0, 1.0)
        iconFrame:SetBackdropBorderColor(0, 0, 0, 1.0)
        dlg.IconFrame = iconFrame

        local targetInfo = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        targetInfo:SetPoint("TOPLEFT", iconFrame, "TOPRIGHT", 10, -2)
        targetInfo:SetJustifyH("LEFT")
        dlg.TargetInfo = targetInfo

        local guildInfo = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        guildInfo:SetPoint("BOTTOMLEFT", iconFrame, "BOTTOMRIGHT", 10, 0)
        guildInfo:SetJustifyH("LEFT")
        dlg.GuildInfo = guildInfo

        local rewardText = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        rewardText:SetPoint("TOPLEFT", 28, -92)
        rewardText:SetJustifyH("LEFT")
        dlg.RewardText = rewardText

        local locText = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        locText:SetPoint("TOPLEFT", 28, -118)
        locText:SetJustifyH("LEFT")
        dlg.LocText = locText

        local acceptBtn = UI:CreateButton(dlg, 140, 26, "Accept & Hunt")
        acceptBtn:SetPoint("BOTTOMLEFT", 20, 18)
        dlg.AcceptBtn = acceptBtn

        local calloutBtn = UI:CreateButton(dlg, 150, 26, "Alert Faction")
        calloutBtn:SetPoint("LEFT", acceptBtn, "RIGHT", 10, 0)
        dlg.CalloutBtn = calloutBtn

        local dismissBtn = UI:CreateButton(dlg, 120, 26, "Dismiss / Mute")
        dismissBtn:SetPoint("LEFT", calloutBtn, "RIGHT", 10, 0)
        dlg.DismissBtn = dismissBtn

        UI.BountyProximityDialog = dlg
    end

    local dlg = UI.BountyProximityDialog
    local aR, aG, aB, aHex = WoWKB.AccentColor()
    local aCode = "|cff" .. (aHex or "ffd100")

    dlg:SetBackdropBorderColor(aR, aG, aB, 1.0)
    dlg.TitleText:SetText(aCode .. "[!] WANTED OUTLAW IN VICINITY!|r")

    if dlg.IconFrame.Icon then
        dlg.IconFrame.Icon:Hide()
        dlg.IconFrame.Icon = nil
    end
    local bIcon = UI:CreateClassIcon(dlg.IconFrame, targetClass or "UNKNOWN", 28)
    bIcon:SetAllPoints(dlg.IconFrame)
    dlg.IconFrame.Icon = bIcon

    local targetColored = (KB.Utils and KB.Utils.ColorizeByClass) and KB.Utils.ColorizeByClass(targetName, targetClass) or string.format("|cffff3838%s|r", targetName)
    local factionBadge = ""
    if targetFaction == "Alliance" then
        factionBadge = " |cff0070de[A]|r"
    elseif targetFaction == "Horde" then
        factionBadge = " |cffc41e3a[H]|r"
    end
    local classDisplay = (targetClass and targetClass ~= "UNKNOWN") and string.format(" |cff888888(%s)|r", targetClass:sub(1,1):upper() .. targetClass:sub(2):lower()) or ""
    dlg.TargetInfo:SetText(targetColored .. classDisplay .. factionBadge)

    local gText = (targetGuild and targetGuild ~= "No Guild" and targetGuild ~= "None") and string.format("<%s>", targetGuild) or "<No Guild>"
    dlg.GuildInfo:SetText(string.format("|cff94a3b8%s|r", gText))

    local g = math.floor(amountCopper / 10000)
    local s = math.floor((amountCopper % 10000) / 100)
    local c = amountCopper % 100
    dlg.RewardText:SetText(string.format("Bounty Contract Reward: |cffffd100%dg|r |cffe2e8f0%ds|r |cffd97706%dc|r", g, s, c))

    dlg.LocText:SetText(string.format("|cff888888Spotted Location:|r |cffffd700%s|r", zone or (GetZoneText and GetZoneText()) or "Azeroth"))

    -- Wire Accept Button
    dlg.AcceptBtn:SetBackdropBorderColor(aR, aG, aB, 0.8)
    dlg.AcceptBtn.Label:SetTextColor(aR, aG, aB, 1.0)
    dlg.AcceptBtn.Label:SetText("Accept & Hunt")
    dlg.AcceptBtn:SetScript("OnClick", function()
        if KB.BountyEngine and KB.BountyEngine.AcceptBounty then
            for _, bId in ipairs(bountyIds or {}) do
                KB.BountyEngine:AcceptBounty(bId)
            end
            if KB.UI and KB.UI.RefreshIfVisible then KB.UI:RefreshIfVisible() end
        end
        dlg:Hide()
    end)

    -- Wire Callout Button
    dlg.CalloutBtn:SetBackdropBorderColor(56/255, 189/255, 248/255, 0.8)
    dlg.CalloutBtn.Label:SetTextColor(56/255, 189/255, 248/255, 1.0)
    dlg.CalloutBtn.Label:SetText("Alert Faction")
    dlg.CalloutBtn:SetScript("OnClick", function()
        local moneyStr = (KB.Utils and KB.Utils.FormatMoney) and KB.Utils.FormatMoney(amountCopper) or (g .. "g")
        local calloutMsg = string.format("[WoWKB Bounty Radar] Wanted Outlaw %s (%s) spotted in %s! Contract: %s!", targetName, gText, zone or "Azeroth", moneyStr)
        if not InCombatLockdown() then
            SendChatMessage(calloutMsg, "YELL")
        end
        SafePrint(string.format("|cff00e5ff[WoWKB Callout Sent]|r %s", calloutMsg))
        dlg:Hide()
    end)

    -- Wire Dismiss / Mute Button
    dlg.DismissBtn:SetBackdropBorderColor(0.3, 0.3, 0.3, 1.0)
    dlg.DismissBtn.Label:SetTextColor(0.7, 0.7, 0.7, 1.0)
    dlg.DismissBtn.Label:SetText("Dismiss / Mute")
    dlg.DismissBtn:SetScript("OnClick", function()
        if KB.UnitScanner and KB.UnitScanner.MutedBounties then
            KB.UnitScanner.MutedBounties[targetName:lower()] = time() + 300 -- Mute for 5 minutes
        end
        SafePrint(string.format("|cff888888[WoWKB]|r Proximity radar for %s muted for 5 minutes.", targetName))
        dlg:Hide()
    end)

    dlg:Show()
    if dlg.Raise then dlg:Raise() end
end

-- ----------------------------------------------------------------------------
-- Frontline Combat Alerts & Raid Warning Notice (100% Template-Free, Taint-Free)
-- ----------------------------------------------------------------------------
local killBanner = nil
local killBannerTimer = nil
local raidNoticeFrame = nil
local raidNoticeTimer = nil

function UI:InitializeRaidNotice()
    if raidNoticeFrame or InCombatLockdown() then return end

    raidNoticeFrame = CreateFrame("Frame", nil, UIParent)
    raidNoticeFrame:SetSize(860, 80)
    raidNoticeFrame:SetFrameStrata("HIGH")
    raidNoticeFrame:SetClampedToScreen(true)
    raidNoticeFrame:EnableMouse(false)

    -- Anchor relative to UIParent
    local pos = WoWKillboardSettings and WoWKillboardSettings.bannerPosition
    if pos and pos.point and pos.relPoint and pos.x and pos.y then
        raidNoticeFrame:SetPoint(pos.point, UIParent, pos.relPoint, pos.x, pos.y - 65)
    else
        raidNoticeFrame:SetPoint("TOP", UIParent, "TOP", 0, -200)
    end

    local mainText = raidNoticeFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightHuge")
    mainText:SetPoint("TOP", 0, 0)
    local fontFile, fontSize = mainText:GetFont()
    if fontFile then
        mainText:SetFont(fontFile, math.max(fontSize or 20, 22), "THICKOUTLINE")
    end
    mainText:SetJustifyH("CENTER")
    raidNoticeFrame.MainText = mainText

    local subText = raidNoticeFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    subText:SetPoint("TOP", mainText, "BOTTOM", 0, -4)
    local sFontFile, sFontSize = subText:GetFont()
    if sFontFile then
        subText:SetFont(sFontFile, math.max(sFontSize or 14, 15), "OUTLINE")
    end
    subText:SetJustifyH("CENTER")
    raidNoticeFrame.SubText = subText

    raidNoticeFrame:Hide()
    UI.RaidNoticeFrame = raidNoticeFrame
end

function UI:ShowRaidNotice(mainMsg, subMsg, r, g, b)
    if not raidNoticeFrame then
        UI:InitializeRaidNotice()
    end
    if not raidNoticeFrame then return end

    raidNoticeFrame.MainText:SetText(mainMsg or "")
    if r and g and b then
        raidNoticeFrame.MainText:SetTextColor(r, g, b, 1.0)
    else
        raidNoticeFrame.MainText:SetTextColor(1.0, 0.28, 0.0, 1.0)
    end

    if subMsg and subMsg ~= "" then
        raidNoticeFrame.SubText:SetText(subMsg)
        raidNoticeFrame.SubText:Show()
    else
        raidNoticeFrame.SubText:Hide()
    end

    raidNoticeFrame:SetAlpha(1.0)
    raidNoticeFrame:Show()

    if raidNoticeTimer then raidNoticeTimer:Cancel() end
    raidNoticeTimer = C_Timer.NewTimer(4.5, function()
        if raidNoticeFrame and raidNoticeFrame:IsShown() then
            if InCombatLockdown() then
                raidNoticeFrame:SetAlpha(0)
                UI.PendingHides = UI.PendingHides or {}
                table.insert(UI.PendingHides, raidNoticeFrame)
            else
                raidNoticeFrame:Hide()
            end
        end
    end)
end

-- =========================================================================
-- Combat Flavor Phrase Generation (Classic Hardcore / Deathlog style)
-- =========================================================================
function UI:GetCombatFlavorPhrase(killmail)
    if not killmail or not killmail.killer or not killmail.victim then
        return "A combatant was slain in battle."
    end

    local kName = killmail.killer.name or "Unknown"
    local vName = killmail.victim.name or "Unknown"

    local isNpc = (killmail.npc ~= nil) or (killmail.killer and killmail.killer.faction == "Monster") or (killmail.isPveDeath == true)

    local kFormatted
    if isNpc then
        kFormatted = string.format("|cffff2020%s|r", kName)
    elseif killmail.killer.class and KB.Utils and KB.Utils.ColorizeByClass then
        kFormatted = KB.Utils.ColorizeByClass(kName, killmail.killer.class)
    else
        kFormatted = "|cffffffff" .. kName .. "|r"
    end

    local vFormatted
    if killmail.victim.class and KB.Utils and KB.Utils.ColorizeByClass then
        vFormatted = KB.Utils.ColorizeByClass(vName, killmail.victim.class)
    else
        vFormatted = "|cffffffff" .. vName .. "|r"
    end

    local spell = killmail.finalSpell or (killmail.killer and killmail.killer.spell) or "Combat Strike"
    if spell == "" then spell = "Combat Strike" end
    local spellFormatted = string.format("|cff00e5ff%s|r", spell)

    local loc = killmail.location or {}
    local locStr = (loc.subZone and loc.subZone ~= "") and loc.subZone or (loc.zone and loc.zone ~= "") and loc.zone or (GetZoneText and GetZoneText()) or "Azeroth"
    local locFormatted = string.format("|cffffffff%s|r", locStr)

    local pool = {}

    if isNpc then
        pool = {
            string.format("%s was slaughtered by %s (%s) in %s!", vFormatted, kFormatted, spellFormatted, locFormatted),
            string.format("%s fell to %s's %s in %s!", vFormatted, kFormatted, spellFormatted, locFormatted),
            string.format("%s was executed by %s in %s with %s!", vFormatted, kFormatted, locFormatted, spellFormatted),
            string.format("%s succumbed to %s in %s!", vFormatted, kFormatted, locFormatted),
            string.format("%s was devoured by %s's %s in %s!", vFormatted, kFormatted, spellFormatted, locFormatted),
        }
    elseif killmail.isDuel then
        pool = {
            string.format("%s bested %s in an honorable duel in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s defeated %s in a certified duel in %s (%s)!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s claimed duel victory against %s in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
        }
    elseif killmail.isBattleground then
        pool = {
            string.format("%s crushed %s on the battlefield of %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s secured a warfront victory over %s in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s struck down %s in %s (%s)!", kFormatted, vFormatted, locFormatted, spellFormatted),
        }
    elseif killmail.isSolo then
        pool = {
            string.format("%s obliterated %s in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s cleanly executed %s in %s using %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s sent %s to the graveyard in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s outplayed %s in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s eliminated %s in 1v1 combat in %s (%s)!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s harvested %s's soul in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
        }
    else
        local attackers = killmail.attackersCount or 2
        pool = {
            string.format("%s and allies overwhelmed %s in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
            string.format("%s landed the fatal %s on %s in %s (x%d)!", kFormatted, spellFormatted, vFormatted, locFormatted, attackers),
            string.format("%s collapsed under assault by %s in %s (%s)!", vFormatted, kFormatted, locFormatted, spellFormatted),
            string.format("%s ambushed %s with reinforcements in %s with %s!", kFormatted, vFormatted, locFormatted, spellFormatted),
        }
    end

    local seed = 1
    if killmail.killId and type(killmail.killId) == "string" then
        for i = 1, #killmail.killId do
            seed = (seed * 31 + string.byte(killmail.killId, i)) % 1000000007
        end
    else
        seed = math.random(1, 1000)
    end

    local idx = (seed % #pool) + 1
    return pool[idx]
end

local function GetFactionCrestInfo(faction, fallbackClass)
    local f = (faction and faction ~= "") and faction:lower() or ""
    if f == "" or f == "unknown" then
        if fallbackClass == "PALADIN" then f = "alliance"
        elseif fallbackClass == "SHAMAN" then f = "horde"
        else
            local myF = UnitFactionGroup and UnitFactionGroup("player")
            f = myF and myF:lower() or "alliance"
        end
    end
    if f == "alliance" then
        return "Interface\\AddOns\\WoWKillboard\\Textures\\crest_alliance.tga", {0, 1, 0, 1}
    elseif f == "horde" then
        return "Interface\\AddOns\\WoWKillboard\\Textures\\crest_horde.tga", {0, 1, 0, 1}
    else
        return "Interface\\TargetingFrame\\UI-PVP-FFA", {0, 1, 0, 1}
    end
end

local function GetKillerFactionCrestInfo(killmail, isNpc)
    if not isNpc and killmail.killer and killmail.killer.isPlayer ~= false and killmail.killer.faction ~= "Monster" then
        return GetFactionCrestInfo(killmail.killer.faction, killmail.killer.class)
    end

    -- NPC / PvE Lore Insignia Detection
    local killer = killmail.killer or killmail.npc or {}
    local name = (killer.name or ""):lower()
    local cType = (killer.creatureType or (killmail.npc and killmail.npc.creatureType) or ""):lower()
    local faction = (killer.faction or (killmail.npc and killmail.npc.faction) or ""):lower()

    -- Check if NPC is affiliated with Alliance or Horde (City Guards, Faction Troops)
    if faction == "alliance" or (name:find("guard") and (name:find("stormwind") or name:find("ironforge") or name:find("darnassus") or name:find("southshore") or name:find("sentinel"))) then
        return "Interface\\AddOns\\WoWKillboard\\Textures\\crest_alliance.tga", {0, 1, 0, 1}
    elseif faction == "horde" or (name:find("grunt") or name:find("deathguard") or (name:find("guard") and (name:find("orgrimmar") or name:find("undercity") or name:find("thunder bluff") or name:find("tarren mill")))) then
        return "Interface\\AddOns\\WoWKillboard\\Textures\\crest_horde.tga", {0, 1, 0, 1}
    end

    -- Defias Brotherhood & Outlaws (Westfall, Deadmines, Redridge)
    if name:find("defias") or name:find("bandit") or name:find("highwayman") or name:find("pillager") or name:find("cutpurse") or name:find("thief") or name:find("looter") then
        return "Interface\\Icons\\INV_Mask_01", {0, 1, 0, 1} -- Iconic Red Defias Bandana / Mask
    end

    -- Bloodsail Buccaneers & Pirates
    if name:find("bloodsail") or name:find("pirate") or name:find("buccaneer") or name:find("corsair") or name:find("swashbuckler") then
        return "Interface\\Icons\\INV_Misc_PirateFlag_01", {0, 1, 0, 1}
    end

    -- Syndicate
    if name:find("syndicate") then
        return "Interface\\Icons\\INV_Mask_02", {0, 1, 0, 1}
    end

    -- Scarlet Crusade
    if name:find("scarlet") then
        return "Interface\\Icons\\INV_Shield_06", {0, 1, 0, 1}
    end

    -- Kobolds
    if name:find("kobold") or name:find("tunnel rat") or name:find("geomancer") then
        return "Interface\\Icons\\INV_Misc_Candle_01", {0, 1, 0, 1}
    end

    -- Murlocs
    if name:find("murloc") or name:find("tidehunter") or name:find("oracle") or name:find("coastrunner") then
        return "Interface\\Icons\\INV_Misc_Fish_02", {0, 1, 0, 1}
    end

    -- Gnolls & Troggs
    if name:find("gnoll") or name:find("hogger") or name:find("riverpaw") or name:find("redridge") or name:find("trogg") then
        return "Interface\\Icons\\INV_Misc_Bone_08", {0, 1, 0, 1}
    end

    -- Undead & Scourge
    if cType == "undead" or name:find("scourge") or name:find("ghoul") or name:find("zombie") or name:find("skeleton") or name:find("necromancer") or name:find("cultist") or name:find("lich") then
        return "Interface\\Icons\\Spell_Shadow_DeathScream", {0, 1, 0, 1}
    end

    -- Demons & Burning Legion
    if cType == "demon" or name:find("demon") or name:find("fel") or name:find("infernal") or name:find("imp") or name:find("succubus") or name:find("doomguard") or name:find("dreadlord") or name:find("legion") then
        return "Interface\\Icons\\Spell_Shadow_SummonFelHunter", {0, 1, 0, 1}
    end

    -- Dragonkin & Flights
    if cType == "dragonkin" or name:find("dragon") or name:find("drake") or name:find("whelp") or name:find("onyxia") or name:find("nefarian") then
        return "Interface\\Icons\\INV_Misc_Head_Dragon_01", {0, 1, 0, 1}
    end

    -- Elementals
    if cType == "elemental" or name:find("elemental") or name:find("ragnaros") or name:find("flame") or name:find("water") or name:find("earth") or name:find("vortex") then
        return "Interface\\Icons\\Spell_Fire_Elemental_Devastation", {0, 1, 0, 1}
    end

    -- Beasts & Predators
    if cType == "beast" or name:find("wolf") or name:find("bear") or name:find("boar") or name:find("spider") or name:find("raptor") or name:find("cat") or name:find("crocolisk") then
        return "Interface\\Icons\\INV_Misc_MonsterClaw_04", {0, 1, 0, 1}
    end

    -- Mechanical
    if cType == "mechanical" or name:find("harvest golem") or name:find("mech") or name:find("robot") or name:find("golem") then
        return "Interface\\Icons\\INV_Gizmo_02", {0, 1, 0, 1}
    end

    -- Giants
    if cType == "giant" or name:find("giant") or name:find("colossus") then
        return "Interface\\Icons\\Ability_Racial_Avatar", {0, 1, 0, 1}
    end

    -- Default Mob / Threat Insignia
    return "Interface\\Icons\\INV_Misc_MonsterHead_02", {0, 1, 0, 1}
end

-- =========================================================================
-- Kill Banner Semantic Formatters & Contextual Builders
-- =========================================================================
local function GetEventHeaderText(killmail, isNpc)
    local eventTitle = "CASUALTY REPORT"
    local ruleset = (KB.Utils and KB.Utils.GetRealmRuleset and KB.Utils.GetRealmRuleset()) or (UI.GetRuleset and UI:GetRuleset()) or "PVP"

    local myName = UnitName("player") or "Dagariane"
    local isMyVictory = (killmail.killer and killmail.killer.name == myName)

    if killmail.isTest then
        eventTitle = "NETWORK TEST SIMULATION"
    elseif not isNpc and not killmail.isPveDeath then
        if isMyVictory then
            eventTitle = "HONORABLE VICTORY"
        else
            eventTitle = "WORLD PVP CASUALTY"
        end
    elseif ruleset == "HARDCORE" or (killmail.isHardcore == true) then
        eventTitle = "FALLEN HERO"
    else
        eventTitle = "CASUALTY REPORT"
    end

    local loc = killmail.location or {}
    local zName = (loc.zone and loc.zone ~= "") and loc.zone or (GetZoneText and GetZoneText()) or "Azeroth"
    local subZone = loc.subZone or ""

    local zoneStr = zName:upper()
    if subZone ~= "" and subZone:lower() ~= zName:lower() then
        zoneStr = string.format("%s (%s)", zName:upper(), subZone:upper())
    end

    return string.format("|cffffd100%s  •  %s|r", eventTitle, zoneStr)
end

local function GetKillingBlowText(killmail)
    local spell = killmail.finalSpell or (killmail.killer and killmail.killer.spell) or (killmail.npc and killmail.npc.spell)
    if not spell or spell == "" or spell == "Combat Strike" then
        if killmail.environmentalType and killmail.environmentalType ~= "" then
            spell = killmail.environmentalType
        else
            spell = "Melee"
        end
    end

    -- High-contrast fatal blow highlight: Gold (#FFC107) or Arcane Cyan (#71D5FF)
    local spellColor = "ffc107"
    local sLower = spell:lower()
    if sLower:find("frost") or sLower:find("ice") or sLower:find("arcane") or sLower:find("water") or sLower:find("cyan") then
        spellColor = "71d5ff"
    end

    if spell == "Melee" then
        return string.format("killed with |cff%sMelee Strike|r", spellColor)
    else
        return string.format("killed with |cff%s%s|r", spellColor, spell)
    end
end

local function GetKillerSubtitle(killmail, isNpc)
    if isNpc then
        local npc = killmail.npc or killmail.killer or {}
        local cType = npc.creatureType or (killmail.killer and killmail.killer.creatureType) or npc.family
        local classif = npc.classification or (killmail.killer and killmail.killer.classification)
        if classif and classif ~= "" and classif ~= "normal" then
            local classifStr = (classif == "elite" and "Elite") or
                               (classif == "worldboss" and "Boss") or
                               (classif == "rareelite" and "Rare Elite") or
                               (classif == "rare" and "Rare") or classif
            if cType and cType ~= "" then
                return string.format("%s / %s", cType, classifStr)
            else
                return classifStr
            end
        elseif cType and cType ~= "" then
            return cType
        elseif npc.guild and npc.guild ~= "" and npc.guild ~= "None" then
            return string.format("<%s>", npc.guild)
        else
            return "Humanoid / Elite"
        end
    else
        local kGuild = killmail.killer and killmail.killer.guild
        local kTitle = killmail.killer and killmail.killer.title
        if kGuild and kGuild ~= "" and kGuild ~= "None" then
            return string.format("<%s>", kGuild)
        elseif kTitle and kTitle ~= "" then
            return kTitle
        else
            return "<Hostile>"
        end
    end
end

-- =========================================================================
-- Kill Banner Theme Switcher
-- =========================================================================
function WoWKB_SetTheme(themeName)
    local banner = UI.KillBanner or killBanner or _G["WoWKB_DeathToast"]
    if not banner then return end
    if themeName == "Classic" or themeName == "classic" then
        if banner.ClassicSkin then banner.ClassicSkin:Show() end
        if banner.ElvSkin then banner.ElvSkin:Hide() end
    else
        if banner.ClassicSkin then banner.ClassicSkin:Hide() end
        if banner.ElvSkin then banner.ElvSkin:Show() end
    end
end

function UI:SetToastTheme(themeName)
    WoWKB_SetTheme(themeName)
end

function UI:ApplyBannerTheme()
    local theme = UI:GetTheme()
    local themeName = (theme and theme.id == "elvui") and "ElvUI" or "Classic"
    WoWKB_SetTheme(themeName)
end

function UI:InitHUDs()
    if not InCombatLockdown() then
        if not UI.KillBanner then UI:InitializeKillBanner() end
        if not UI.RaidNoticeFrame then UI:InitializeRaidNotice() end
        if not radarHUD and UI.InitializeRadarHUD then UI:InitializeRadarHUD() end
        if not combatWireHUD and UI.InitializeCombatWire then UI:InitializeCombatWire() end
    end
end

function UI:InitializeKillBanner()
    if killBanner or InCombatLockdown() then return end

    -- Guardrail: Ensure GameFontHighlightMedium is available across all client flavors
    if not _G["GameFontHighlightMedium"] then
        _G["GameFontHighlightMedium"] = _G["GameFontHighlightLarge"] or _G["GameFontHighlight"] or _G["GameFontNormal"]
    end

    -- 1. ROOT CONTAINER (Size & Position)
    local Toast = CreateFrame("Frame", "WoWKB_DeathToast", UIParent)
    Toast:SetSize(560, 84)
    Toast:SetPoint("TOP", UIParent, "TOP", 0, -120)
    Toast:SetClampedToScreen(true)
    Toast:SetFrameStrata("HIGH")
    Toast:SetMovable(true)
    Toast:EnableMouse(false)
    Toast:Hide()

    -- Restore saved position if customized
    local pos = WoWKillboardSettings and WoWKillboardSettings.bannerPosition
    if pos and pos.point and pos.relPoint and pos.x and pos.y then
        Toast:ClearAllPoints()
        Toast:SetPoint(pos.point, UIParent, pos.relPoint, pos.x, pos.y)
    end

    Toast:SetScript("OnDragStart", function(self)
        if not InCombatLockdown() then
            self:StartMoving()
        end
    end)
    Toast:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        WoWKillboardSettings = WoWKillboardSettings or {}
        WoWKillboardSettings.bannerPosition = {
            point = point or "TOP",
            relPoint = relPoint or "TOP",
            x = math.floor((x or 0) + 0.5),
            y = math.floor((y or -120) + 0.5),
        }
        if self.headerText then
            self.headerText:SetText(string.format("|cffffd100MOVE / PREVIEW  •  %s (%d, %d)|r", point or "TOP", math.floor((x or 0) + 0.5), math.floor((y or -120) + 0.5)))
        end
        if UI.AlertsDialog and UI.AlertsDialog.UpdateControls then
            UI.AlertsDialog:UpdateControls()
        end
    end)

    -- 2. CLASSIC SKIN CONTAINER (Identical clean structure as ElvUI with Classic Warcraft colors)
    local ClassicSkin = CreateFrame("Frame", nil, Toast, "BackdropTemplate")
    ClassicSkin:SetAllPoints(Toast)
    ClassicSkin:SetFrameLevel(Toast:GetFrameLevel() + 1)
    ClassicSkin:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 }
    })
    ClassicSkin:SetBackdropColor(18/255, 14/255, 12/255, 0.95) -- Warm dark stone base
    ClassicSkin:SetBackdropBorderColor(0.78, 0.61, 0.23, 1.0) -- Classic burnished gold border

    local classicTopAccent = ClassicSkin:CreateTexture(nil, "OVERLAY")
    classicTopAccent:SetHeight(2)
    classicTopAccent:SetPoint("TOPLEFT", ClassicSkin, "TOPLEFT", 1, -1)
    classicTopAccent:SetPoint("TOPRIGHT", ClassicSkin, "TOPRIGHT", -1, -1)
    classicTopAccent:SetColorTexture(1.0, 0.82, 0.0, 1.0) -- #FFD100 Classic Blizzard Gold
    ClassicSkin.TopAccent = classicTopAccent

    -- 3. ELVUI SKIN CONTAINER
    local ElvSkin = CreateFrame("Frame", nil, Toast, "BackdropTemplate")
    ElvSkin:SetAllPoints(Toast)
    ElvSkin:SetFrameLevel(Toast:GetFrameLevel() + 1)
    ElvSkin:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 }
    })
    ElvSkin:SetBackdropColor(13/255, 17/255, 23/255, 0.94) -- Cool dark slate base
    ElvSkin:SetBackdropBorderColor(0.18, 0.20, 0.23, 1) -- Subtle slate border

    local elvTopAccent = ElvSkin:CreateTexture(nil, "OVERLAY")
    elvTopAccent:SetHeight(2)
    elvTopAccent:SetPoint("TOPLEFT", ElvSkin, "TOPLEFT", 1, -1)
    elvTopAccent:SetPoint("TOPRIGHT", ElvSkin, "TOPRIGHT", -1, -1)
    local aR, aG, aB = WoWKB.AccentColor()
    elvTopAccent:SetColorTexture(aR, aG, aB, 1)
    ElvSkin.TopAccent = elvTopAccent

    -- 4. CONTENT LAYER (MUST BE HIGHER FRAME LEVEL SO NOTHING IS HIDDEN)
    local Content = CreateFrame("Frame", nil, Toast)
    Content:SetAllPoints(Toast)
    Content:SetFrameLevel(Toast:GetFrameLevel() + 10)

    -- Header
    local headerText = Content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headerText:SetPoint("TOP", Content, "TOP", 0, -8)
    headerText:SetTextColor(1, 0.82, 0, 1) -- #FFD100
    headerText:SetText("CASUALTY REPORT  •  WESTFALL (SENTINEL HILL)")
    headerText:SetShadowOffset(1, -1)
    headerText:SetShadowColor(0, 0, 0, 1.0)

    -- Left Side: Killer / Victor (Outer Faction Crest + Inner Class/Spell Icon)
    local killerFactionIcon = Content:CreateTexture(nil, "ARTWORK")
    killerFactionIcon:SetSize(36, 36)
    killerFactionIcon:SetPoint("LEFT", Content, "LEFT", 14, -4)
    killerFactionIcon:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\crest_alliance.tga")

    local killerIcon = Content:CreateTexture(nil, "ARTWORK")
    killerIcon:SetSize(36, 36)
    killerIcon:SetPoint("LEFT", killerFactionIcon, "RIGHT", 8, 0)
    killerIcon:SetTexture("Interface\\Icons\\Spell_Holy_RighteousFury")

    local killerName = Content:CreateFontString(nil, "OVERLAY", "GameFontHighlightMedium")
    killerName:SetPoint("TOPLEFT", killerIcon, "TOPRIGHT", 10, -2)
    killerName:SetTextColor(0.96, 0.55, 0.73, 1) -- Paladin Pink
    killerName:SetText("[24] Dagariane")
    killerName:SetJustifyH("LEFT")
    killerName:SetShadowOffset(1, -1)
    killerName:SetShadowColor(0, 0, 0, 1.0)

    local killerSub = Content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    killerSub:SetPoint("BOTTOMLEFT", killerIcon, "BOTTOMRIGHT", 10, 2)
    killerSub:SetTextColor(0.65, 0.65, 0.65, 1)
    killerSub:SetText("<Knights of Azeroth>")
    killerSub:SetJustifyH("LEFT")
    killerSub:SetShadowOffset(1, -1)
    killerSub:SetShadowColor(0, 0, 0, 1.0)

    -- Center: Incident Action (Directional: Killer killed Victim)
    local skullIcon = Content:CreateTexture(nil, "ARTWORK")
    skullIcon:SetSize(22, 22)
    skullIcon:SetPoint("CENTER", Content, "CENTER", 0, -2)
    skullIcon:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
    skullIcon:SetVertexColor(1, 0.15, 0.15, 1)

    local actionText = Content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    actionText:SetPoint("TOP", skullIcon, "BOTTOM", 0, -2)
    actionText:SetText("killed with |cffffc107Judgement|r")
    actionText:SetShadowOffset(1, -1)
    actionText:SetShadowColor(0, 0, 0, 1.0)

    -- Right Side: Victim / Casualty (Bilateral Mirror: Inner Class Icon + Outer Faction Crest)
    local factionIcon = Content:CreateTexture(nil, "ARTWORK")
    factionIcon:SetSize(36, 36)
    factionIcon:SetPoint("RIGHT", Content, "RIGHT", -14, -4)
    factionIcon:SetTexture("Interface\\AddOns\\WoWKillboard\\Textures\\crest_horde.tga")

    local victimIcon = Content:CreateTexture(nil, "ARTWORK")
    victimIcon:SetSize(36, 36)
    victimIcon:SetPoint("RIGHT", factionIcon, "LEFT", -8, 0)
    victimIcon:SetTexture("Interface\\Icons\\Ability_Backstab")

    local victimName = Content:CreateFontString(nil, "OVERLAY", "GameFontHighlightMedium")
    victimName:SetPoint("TOPRIGHT", victimIcon, "TOPLEFT", -10, -2)
    victimName:SetTextColor(1, 0.96, 0.41, 1) -- Rogue Yellow (#FFF569)
    victimName:SetText("[25] Shadowstalker")
    victimName:SetJustifyH("RIGHT")
    victimName:SetShadowOffset(1, -1)
    victimName:SetShadowColor(0, 0, 0, 1.0)

    local victimGuild = Content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    victimGuild:SetPoint("BOTTOMRIGHT", victimIcon, "BOTTOMLEFT", -10, 2)
    victimGuild:SetTextColor(0.65, 0.65, 0.65, 1)
    victimGuild:SetText("<Grim Syndicate>")
    victimGuild:SetJustifyH("RIGHT")
    victimGuild:SetShadowOffset(1, -1)
    victimGuild:SetShadowColor(0, 0, 0, 1.0)

    -- Store references on Toast
    Toast.ClassicSkin = ClassicSkin
    Toast.ElvSkin = ElvSkin
    Toast.classicTopAccent = classicTopAccent
    Toast.elvTopAccent = elvTopAccent
    Toast.TopAccent = elvTopAccent
    Toast.Content = Content

    Toast.headerText = headerText
    Toast.killerFactionIcon = killerFactionIcon
    Toast.killerIcon = killerIcon
    Toast.killerName = killerName
    Toast.killerSub = killerSub
    Toast.skullIcon = skullIcon
    Toast.actionText = actionText
    Toast.victimIcon = victimIcon
    Toast.victimName = victimName
    Toast.victimGuild = victimGuild
    Toast.factionIcon = factionIcon

    -- Backwards-compatible aliases for ShowKillBanner and external callers
    Toast.CenterHeader = headerText
    Toast.CenterAction = headerText
    Toast.KillerFactionIcon = killerFactionIcon
    Toast.killerFactionIcon = killerFactionIcon
    Toast.KillerCrest = killerFactionIcon
    Toast.killerCrest = killerFactionIcon
    Toast.KillerIcon = killerIcon
    Toast.killerIcon = killerIcon
    Toast.KillerNameText = killerName
    Toast.killerName = killerName
    Toast.KillerSubText = killerSub
    Toast.killerSub = killerSub
    Toast.KillerText = killerName

    Toast.CenterIcon = skullIcon
    Toast.skullIcon = skullIcon
    Toast.ActionText = actionText
    Toast.actionText = actionText
    Toast.LocText = actionText
    Toast.ModeTag = actionText

    Toast.VictimCrest = factionIcon
    Toast.victimCrest = factionIcon
    Toast.VictimFactionIcon = factionIcon
    Toast.victimFactionIcon = factionIcon
    Toast.factionIcon = factionIcon
    Toast.VictimIcon = victimIcon
    Toast.victimIcon = victimIcon
    Toast.VictimNameText = victimName
    Toast.victimName = victimName
    Toast.VictimSubText = victimGuild
    Toast.victimGuild = victimGuild
    Toast.VictimText = victimName

    killBanner = Toast
    UI.KillBanner = Toast
    _G["WoWKB_DeathToast"] = Toast

    -- Initialize
    WoWKB_SetTheme("Classic")
    Toast:Hide()
end

function UI:ShowKillBanner(killmail, isTest)
    if not killmail or not killmail.killer or not killmail.victim then return end

    isTest = isTest or (killmail and killmail.isTest) or (killmail and killmail.killId and tostring(killmail.killId):find("^TEST%-")) or (killmail and killmail.deathId and tostring(killmail.deathId):find("^TEST%-"))

    local settings = WoWKillboardSettings or KB.DefaultSettings
    local alertMode = settings.alertMode or "SOUND_AND_BANNER"
    local alertScope = settings.alertScope or "ZONE"
    local alertStyle = settings.alertStyle or "BOTH"

    -- 1. If killmail is a 1v1 duel or alerts are completely disabled, exit immediately (unless explicit test)
    if not isTest and killmail.isDuel then return end
    if alertMode == "OFF" and not isTest then return end

    local myName = UnitName("player") or "Hero"
    local myLower = myName:lower()
    local myGUID = UnitGUID("player") or ""
    local pFaction = (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"

    local function IsLocalCombatant(entity)
        if not entity or type(entity) ~= "table" then return false end
        if myGUID ~= "" and entity.guid and entity.guid == myGUID then return true end
        if entity.name and type(entity.name) == "string" then
            local eLower = entity.name:lower()
            if eLower == myLower or eLower:find("^" .. myLower .. "%-") then
                return true
            end
        end
        return false
    end

    local isMyCombat = IsLocalCombatant(killmail.killer) or IsLocalCombatant(killmail.victim)

    -- 2. Scope & Proximity Filter (bypassed if explicit test or if this is the player's own combat)
    if not isTest and not isMyCombat then
        if alertScope == "MINE" then
            return
        elseif alertScope == "ZONE" then
            local myZone = GetZoneText and GetZoneText() or ""
            local killZone = (killmail.location and killmail.location.zone) or ""
            if myZone ~= "" and killZone ~= "" and myZone:lower() ~= killZone:lower() then
                return
            end
        end
    end

    -- 3. Audio Dispatch (Sound + Banner mode only, or explicit test)
    if isTest or alertMode == "SOUND_AND_BANNER" then
        if PlaySound then
            local soundId = (KB.SoundAlerts and KB.SoundAlerts.SOLO_KILL) or 8959
            pcall(PlaySound, soundId, "Master")
        end
    end

    -- Optional Raid Notice Dispatch
    if alertStyle == "BOTH" or alertStyle == "RAID_WARNING" then
        if not UI.RaidNoticeFrame then
            UI:InitializeRaidNotice()
        end
        local flavor = UI:GetCombatFlavorPhrase(killmail)
        if flavor and UI.ShowRaidNotice then
            UI.ShowRaidNotice(flavor)
        end
    end

    -- 4. Frontline Kill Banner Frame (Frozen Shared 560x84 Layout Across All Themes)
    if isTest or alertStyle == "BOTH" or alertStyle == "BANNER" then
        if not UI.KillBanner then
            UI:InitializeKillBanner()
        end

        local banner = UI.KillBanner
        if not banner then return end

        local isNpc = (killmail.npc ~= nil) or (killmail.killer and killmail.killer.faction == "Monster") or (killmail.isPveDeath == true)
        local isPvp = (not isNpc and not killmail.isPveDeath and killmail.killer and killmail.killer.faction ~= "Monster")

        -- 1. Populate Left Section (Killer / Victor Identity)
        local kCrestTex, kCrestCoords = GetKillerFactionCrestInfo(killmail, isNpc)
        if banner.KillerFactionIcon then
            banner.KillerFactionIcon:SetTexture(kCrestTex)
            banner.KillerFactionIcon:SetTexCoord(kCrestCoords[1], kCrestCoords[2], kCrestCoords[3], kCrestCoords[4])
        end

        if isNpc then
            local spell = killmail.finalSpell or (killmail.killer and killmail.killer.spell) or ""
            local spellTex = nil
            if spell and spell ~= "" and spell ~= "Combat Strike" and spell ~= "Melee" then
                if C_Spell and C_Spell.GetSpellTexture then
                    spellTex = C_Spell.GetSpellTexture(spell)
                elseif GetSpellTexture then
                    spellTex = GetSpellTexture(spell)
                end
                if not spellTex then
                    local sLower = spell:lower()
                    if sLower:find("fireball") then spellTex = "Interface\\Icons\\Spell_Fire_FlameBolt"
                    elseif sLower:find("shadow bolt") then spellTex = "Interface\\Icons\\Spell_Shadow_ShadowBolt"
                    elseif sLower:find("frostbolt") then spellTex = "Interface\\Icons\\Spell_Frost_FrostBolt02"
                    elseif sLower:find("shoot") then spellTex = "Interface\\Icons\\Ability_Marksmanship"
                    elseif sLower:find("cleave") then spellTex = "Interface\\Icons\\Ability_Warrior_Cleave"
                    elseif sLower:find("strike") then spellTex = "Interface\\Icons\\INV_Sword_04"
                    end
                end
            end
            if spellTex then
                banner.KillerIcon:SetTexture(spellTex)
            else
                banner.KillerIcon:SetTexture("Interface\\Icons\\Ability_Creature_Poison_02")
            end
            banner.KillerIcon:SetTexCoord(0, 1, 0, 1)
        else
            local kClass = (killmail.killer.class or ""):upper()
            local kCoords = CLASS_COORDS[kClass] or {0, 0.25, 0, 0.25}
            banner.KillerIcon:SetTexture(CLASS_ICON_TEXTURE)
            banner.KillerIcon:SetTexCoord(kCoords[1], kCoords[2], kCoords[3], kCoords[4])
        end

        local kLevelStr = (killmail.killer.level and killmail.killer.level > 0) and tostring(killmail.killer.level) or "??"
        local kName = killmail.killer.name or "Threat"

        if isNpc then
            local npcClassification = (killmail.npc and killmail.npc.classification) or (killmail.killer and killmail.killer.classification) or ""
            local isElite = npcClassification:find("elite") or npcClassification == "worldboss"
            local lvlDisplay = (isElite and kLevelStr ~= "??") and (kLevelStr .. "+") or kLevelStr

            local npcColor = "ff4444" -- Standard Hostile Mob Red
            if npcClassification == "worldboss" then
                npcColor = "ff2020" -- World Boss Deep Crimson
            elseif npcClassification == "rareelite" then
                npcColor = "ff9900" -- Rare Elite Orange
            elseif npcClassification == "elite" then
                npcColor = "ffd100" -- Iconic Elite Gold
            elseif npcClassification == "rare" then
                npcColor = "00ccff" -- Rare Silver/Cyan
            end
            banner.KillerNameText:SetTextColor(1, 1, 1, 1)
            banner.KillerNameText:SetText(string.format("|cff%s[%s] %s|r", npcColor, lvlDisplay, kName))
        else
            -- PvP: Always use class color for player names
            banner.KillerNameText:SetTextColor(1, 1, 1, 1)
            banner.KillerNameText:SetText(KB.Utils.ColorizeByClass(string.format("[%s] %s", kLevelStr, kName), killmail.killer.class))
        end

        banner.KillerSubText:SetText(GetKillerSubtitle(killmail, isNpc))

        -- 2. Populate Center Section (Directional Incident Action Block)
        banner.CenterHeader:SetText(GetEventHeaderText(killmail, isNpc))
        banner.CenterIcon:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
        banner.CenterIcon:SetTexCoord(0, 1, 0, 1)
        banner.CenterIcon:SetVertexColor(1, 0.15, 0.15, 1)
        if banner.CenterIconShadow then
            banner.CenterIconShadow:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
            banner.CenterIconShadow:SetTexCoord(0, 1, 0, 1)
            banner.CenterIconShadow:SetVertexColor(0.60, 0.05, 0.05, 0.65)
            banner.CenterIconShadow:Show()
        end
        banner.ActionText:SetText(GetKillingBlowText(killmail))

        -- 3. Populate Right Section (Victim / Casualty Identity)
        local vCrestTex, vCrestCoords = GetFactionCrestInfo(killmail.victim.faction, killmail.victim.class)
        banner.VictimCrest:SetTexture(vCrestTex)
        banner.VictimCrest:SetTexCoord(vCrestCoords[1], vCrestCoords[2], vCrestCoords[3], vCrestCoords[4])

        local vClass = (killmail.victim.class or ""):upper()
        local vCoords = CLASS_COORDS[vClass] or {0, 0.25, 0, 0.25}
        banner.VictimIcon:SetTexture(CLASS_ICON_TEXTURE)
        banner.VictimIcon:SetTexCoord(vCoords[1], vCoords[2], vCoords[3], vCoords[4])

        local vLevelStr = (killmail.victim.level and killmail.victim.level > 0) and tostring(killmail.victim.level) or "??"
        local vName = killmail.victim.name or "Unknown"

        local isVictimPlayer = (killmail.victim.isPlayer ~= false) and (killmail.victim.faction ~= "Monster")
        if isVictimPlayer and killmail.victim.class and killmail.victim.class ~= "" then
            -- PvP / Player Casualty: Always use class color for player names
            banner.VictimNameText:SetTextColor(1, 1, 1, 1)
            banner.VictimNameText:SetText(KB.Utils.ColorizeByClass(string.format("[%s] %s", vLevelStr, vName), killmail.victim.class))
        else
            local vClassification = (killmail.victim and killmail.victim.classification) or ""
            local isVElite = vClassification:find("elite") or vClassification == "worldboss"
            local vLvlDisplay = (isVElite and vLevelStr ~= "??") and (vLevelStr .. "+") or vLevelStr
            local vColor = "ff4444"
            if vClassification == "worldboss" then vColor = "ff2020"
            elseif vClassification == "rareelite" then vColor = "ff9900"
            elseif vClassification == "elite" then vColor = "ffd100"
            elseif vClassification == "rare" then vColor = "00ccff"
            end
            banner.VictimNameText:SetTextColor(1, 1, 1, 1)
            banner.VictimNameText:SetText(string.format("|cff%s[%s] %s|r", vColor, vLvlDisplay, vName))
        end

        local vGuild = killmail.victim.guild
        if vGuild and vGuild ~= "" and vGuild ~= "None" then
            banner.VictimSubText:SetText(string.format("<%s>", vGuild))
        else
            banner.VictimSubText:SetText("")
        end

        -- 4. Dynamic Winning Faction Border & Accent Coloring (PvP: Blue for Alliance Win, Red for Horde Win)
        local winningFaction = (killmail.killer and killmail.killer.faction) or ""
        if (winningFaction == "" or winningFaction == "Unknown") and killmail.killer and killmail.killer.name == myName then
            winningFaction = pFaction
        end

        if isPvp and winningFaction == "Alliance" then
            -- Alliance Victor: Alliance Blue Border (#0078FF)
            if banner.ClassicSkin then
                banner.ClassicSkin:SetBackdropBorderColor(0.0, 0.47, 1.0, 1.0)
                if banner.classicTopAccent then banner.classicTopAccent:SetColorTexture(0.0, 0.47, 1.0, 1.0) end
            end
            if banner.ElvSkin then
                banner.ElvSkin:SetBackdropBorderColor(0.0, 0.47, 1.0, 1.0)
                if banner.elvTopAccent then banner.elvTopAccent:SetColorTexture(0.0, 0.47, 1.0, 1.0) end
            end
        elseif isPvp and winningFaction == "Horde" then
            -- Horde Victor: Horde Crimson Red Border (#C41E3A / #DC2626)
            if banner.ClassicSkin then
                banner.ClassicSkin:SetBackdropBorderColor(0.85, 0.15, 0.15, 1.0)
                if banner.classicTopAccent then banner.classicTopAccent:SetColorTexture(0.85, 0.15, 0.15, 1.0) end
            end
            if banner.ElvSkin then
                banner.ElvSkin:SetBackdropBorderColor(0.85, 0.15, 0.15, 1.0)
                if banner.elvTopAccent then banner.elvTopAccent:SetColorTexture(0.85, 0.15, 0.15, 1.0) end
            end
        else
            -- PvE / Non-PvP: Neutral / Classic Aesthetics
            local aR, aG, aB = WoWKB.AccentColor()
            if banner.ClassicSkin then
                banner.ClassicSkin:SetBackdropBorderColor(0.78, 0.61, 0.23, 1.0) -- Classic Burnished Gold
                if banner.classicTopAccent then banner.classicTopAccent:SetColorTexture(aR, aG, aB, 1.0) end
            end
            if banner.ElvSkin then
                banner.ElvSkin:SetBackdropBorderColor(0.18, 0.20, 0.23, 1.0) -- Subtle Slate
                if banner.elvTopAccent then banner.elvTopAccent:SetColorTexture(aR, aG, aB, 1.0) end -- Dynamic Accent Color
            end
        end

        banner:SetAlpha(1.0)
        banner:Show()
        if not UI.bannerUnlocked then
            if killBannerTimer then killBannerTimer:Cancel() end
            killBannerTimer = C_Timer.NewTimer(4.5, function()
                if banner and not UI.bannerUnlocked then
                    if InCombatLockdown() then
                        banner:SetAlpha(0)
                        UI.PendingHides = UI.PendingHides or {}
                        table.insert(UI.PendingHides, banner)
                    else
                        banner:Hide()
                    end
                end
            end)
        end
    end
end

-- Generic Frontline Toast / System Announcement Trigger
function UI:TriggerToast(opts)
    opts = opts or {}
    local title = opts.title or "SYSTEM UPDATE NOTICE"
    local text = opts.text or "Realm update broadcast."
    local duration = opts.duration or 6

    if not UI.KillBanner then
        UI:InitializeKillBanner()
    end
    local banner = UI.KillBanner
    if not banner then return end

    if banner.KillerFactionIcon then
        banner.KillerFactionIcon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
        banner.KillerFactionIcon:SetTexCoord(0, 1, 0, 1)
    end
    if banner.KillerIcon then
        banner.KillerIcon:SetTexture("Interface\\Icons\\Achievement_General")
        banner.KillerIcon:SetTexCoord(0, 1, 0, 1)
    end
    banner.KillerNameText:SetTextColor(1, 0.82, 0, 1)
    banner.KillerNameText:SetText("|cffffd100" .. title .. "|r")
    banner.KillerSubText:SetText("|cff38bdf8WoW Killboard Alert|r")

    banner.CenterHeader:SetText("|cffff3838BROADCAST|r")
    if banner.CenterIcon then
        banner.CenterIcon:SetTexture("Interface\\Icons\\INV_Misc_Bell_01")
        banner.CenterIcon:SetTexCoord(0, 1, 0, 1)
        banner.CenterIcon:SetVertexColor(1, 0.82, 0, 1)
    end
    if banner.CenterIconShadow then
        banner.CenterIconShadow:Hide()
    end
    banner.ActionText:SetText("|cffffffff" .. text .. "|r")

    if banner.VictimCrest then
        banner.VictimCrest:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
        banner.VictimCrest:SetTexCoord(0, 1, 0, 1)
    end
    if banner.VictimIcon then
        banner.VictimIcon:SetTexture("Interface\\Icons\\Achievement_General")
        banner.VictimIcon:SetTexCoord(0, 1, 0, 1)
    end
    banner.VictimNameText:SetTextColor(1, 1, 1, 1)
    banner.VictimNameText:SetText("|cff00e5ffNetwork Alert|r")
    banner.VictimSubText:SetText("")

    if banner.ClassicSkin then
        banner.ClassicSkin:SetBackdropBorderColor(1.0, 0.82, 0.0, 1.0)
        if banner.classicTopAccent then banner.classicTopAccent:SetColorTexture(1.0, 0.82, 0.0, 1.0) end
    end
    if banner.ElvSkin then
        banner.ElvSkin:SetBackdropBorderColor(1.0, 0.82, 0.0, 1.0)
        if banner.elvTopAccent then banner.elvTopAccent:SetColorTexture(1.0, 0.82, 0.0, 1.0) end
    end

    banner:SetAlpha(1.0)
    banner:Show()
    if killBannerTimer then killBannerTimer:Cancel() end
    killBannerTimer = C_Timer.NewTimer(duration, function()
        if banner and not UI.bannerUnlocked then
            if InCombatLockdown and InCombatLockdown() then
                banner:SetAlpha(0)
                UI.PendingHides = UI.PendingHides or {}
                table.insert(UI.PendingHides, banner)
            else
                banner:Hide()
            end
        end
    end)
end

-- Toggle Banner Drag / Positioning Mode
function UI:ToggleBannerLock(explicitState)
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot move alert banner during combat.")
        return
    end
    if not UI.KillBanner then
        UI:InitializeKillBanner()
    end
    local banner = UI.KillBanner
    if not banner then return end

    if explicitState ~= nil then
        UI.bannerUnlocked = explicitState
    else
        UI.bannerUnlocked = not UI.bannerUnlocked
    end

    if UI.bannerUnlocked then
        if killBannerTimer then killBannerTimer:Cancel() end
        banner:EnableMouse(true) -- Enable mouse interaction only while repositioning
        banner:RegisterForDrag("LeftButton")

        UI:ApplyBannerTheme()
        local pos = WoWKillboardSettings and WoWKillboardSettings.bannerPosition or { point = "TOP", x = 0, y = -120 }

        local myName = UnitName("player") or "Dagariane"
        local _, pClass = UnitClass("player")
        pClass = pClass or "PALADIN"
        local pLevel = UnitLevel("player") or 24
        local pGuild = (GetGuildInfo and GetGuildInfo("player")) or "Knights of Azeroth"
        local pFaction = (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"

        local enemyFaction = (pFaction == "Alliance") and "Horde" or "Alliance"
        local enemyClass = (enemyFaction == "Horde") and "ROGUE" or "WARRIOR"
        local enemyName = (enemyFaction == "Horde") and "Shadowstalker" or "Dawnbreaker"
        local enemyGuild = (enemyFaction == "Horde") and "Grim Syndicate" or "Silver Hand"
        local enemyLevel = pLevel + 1

        -- 1. Left: Victor / Player (Dynamic by player class and faction)
        local myCrestTex, myCrestCoords = GetFactionCrestInfo(pFaction, pClass)
        if banner.KillerFactionIcon then
            banner.KillerFactionIcon:SetTexture(myCrestTex)
            banner.KillerFactionIcon:SetTexCoord(myCrestCoords[1], myCrestCoords[2], myCrestCoords[3], myCrestCoords[4])
        end
        local kCoords = CLASS_COORDS[pClass:upper()] or {0, 0.25, 0, 0.25}
        banner.KillerIcon:SetTexture(CLASS_ICON_TEXTURE)
        banner.KillerIcon:SetTexCoord(kCoords[1], kCoords[2], kCoords[3], kCoords[4])
        banner.KillerNameText:SetTextColor(1, 1, 1, 1)
        banner.KillerNameText:SetText(KB.Utils.ColorizeByClass(string.format("[%d] %s", pLevel, myName), pClass))
        banner.KillerSubText:SetText(string.format("<%s>", pGuild))

        -- 2. Center: Incident Action Block & Drag Indicator
        banner.CenterHeader:SetText(string.format("|cffffd100MOVE / PREVIEW  •  %s (%d, %d)|r", pos.point or "TOP", pos.x or 0, pos.y or -120))
        banner.CenterIcon:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
        banner.CenterIcon:SetTexCoord(0, 1, 0, 1)
        banner.CenterIcon:SetVertexColor(1.0, 0.15, 0.15, 1.0)
        if banner.CenterIconShadow then
            banner.CenterIconShadow:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
            banner.CenterIconShadow:SetTexCoord(0, 1, 0, 1)
            banner.CenterIconShadow:SetVertexColor(0.60, 0.05, 0.05, 0.65)
            banner.CenterIconShadow:Show()
        end
        banner.ActionText:SetText("killed with |cffffc107Judgement|r")

        -- 3. Right: Victim / Casualty (Class-colored)
        local enemyCrestTex, enemyCrestCoords = GetFactionCrestInfo(enemyFaction, enemyClass)
        banner.VictimCrest:SetTexture(enemyCrestTex)
        banner.VictimCrest:SetTexCoord(enemyCrestCoords[1], enemyCrestCoords[2], enemyCrestCoords[3], enemyCrestCoords[4])
        local vCoords = CLASS_COORDS[enemyClass:upper()] or {0, 0.25, 0, 0.25}
        banner.VictimIcon:SetTexture(CLASS_ICON_TEXTURE)
        banner.VictimIcon:SetTexCoord(vCoords[1], vCoords[2], vCoords[3], vCoords[4])
        banner.VictimNameText:SetTextColor(1, 1, 1, 1)
        banner.VictimNameText:SetText(KB.Utils.ColorizeByClass(string.format("[%d] %s", enemyLevel, enemyName), enemyClass))
        banner.VictimSubText:SetText(string.format("<%s>", enemyGuild))

        -- 4. Dynamic Winning Faction Border
        if pFaction == "Alliance" then
            if banner.ClassicSkin then
                banner.ClassicSkin:SetBackdropBorderColor(0.0, 0.47, 1.0, 1.0)
                if banner.classicTopAccent then banner.classicTopAccent:SetColorTexture(0.0, 0.47, 1.0, 1.0) end
            end
            if banner.ElvSkin then
                banner.ElvSkin:SetBackdropBorderColor(0.0, 0.47, 1.0, 1.0)
                if banner.elvTopAccent then banner.elvTopAccent:SetColorTexture(0.0, 0.47, 1.0, 1.0) end
            end
        else
            if banner.ClassicSkin then
                banner.ClassicSkin:SetBackdropBorderColor(0.85, 0.15, 0.15, 1.0)
                if banner.classicTopAccent then banner.classicTopAccent:SetColorTexture(0.85, 0.15, 0.15, 1.0) end
            end
            if banner.ElvSkin then
                banner.ElvSkin:SetBackdropBorderColor(0.85, 0.15, 0.15, 1.0)
                if banner.elvTopAccent then banner.elvTopAccent:SetColorTexture(0.85, 0.15, 0.15, 1.0) end
            end
        end

        banner:SetAlpha(1.0)
        banner:Show()

        SafePrint(string.format("|cff00ccff[WoWKB Alert]|r Alert Banner unlocked! Click and drag with |cffffd100Left-Click|r. Type |cffffd100/kb move|r again or click Lock to save at %s (%d, %d).", pos.point or "TOP", pos.x or 0, pos.y or -120))
    else
        banner:EnableMouse(false) -- Revert to click-through immediately
        banner:RegisterForDrag()  -- Unregister drag listeners
        banner:Hide()
        local pos = WoWKillboardSettings and WoWKillboardSettings.bannerPosition or { point = "TOP", x = 0, y = -120 }
        SafePrint(string.format("|cff00ccff[WoWKB Alert]|r Alert Banner locked and hidden. Saved anchor at |cffffd100%s (%d, %d)|r.", pos.point or "TOP", pos.x or 0, pos.y or -120))
    end

    if UI.AlertsDialog and UI.AlertsDialog.UpdateControls then
        UI.AlertsDialog:UpdateControls()
    end
    if UI.SettingsDialog and UI.SettingsDialog.toggleMoveBtn then
        UI.SettingsDialog.toggleMoveBtn.Label:SetText(UI.bannerUnlocked and "|cffff3333Lock Toast|r" or "|cffffd100Move Toast|r")
    end
end

-- Reset Banner to Default Center-Top Position
function UI:ResetBannerPosition()
    if InCombatLockdown() then return end
    if not UI.KillBanner then UI:InitializeKillBanner() end
    if not UI.RaidNoticeFrame then UI:InitializeRaidNotice() end

    if WoWKillboardSettings then
        WoWKillboardSettings.bannerPosition = nil
    end
    if UI.KillBanner then
        UI.KillBanner:ClearAllPoints()
        UI.KillBanner:SetPoint("TOP", UIParent, "TOP", 0, -135)
    end
    if UI.RaidNoticeFrame then
        UI.RaidNoticeFrame:ClearAllPoints()
        UI.RaidNoticeFrame:SetPoint("TOP", UIParent, "TOP", 0, -200)
    end
    SafePrint("|cff00ccff[WoWKB Alert]|r Alert position reset to default screen coordinates (Center-Top).")
    if UI.AlertsDialog and UI.AlertsDialog.UpdateControls then
        UI.AlertsDialog:UpdateControls()
    end
end

-- Fire Test Banner Preview (Supports: "kill", "death", "pve", "pvp", or automatic 3-stage cycle)
function UI:TestKillBanner(mode)
    local myName = UnitName("player") or "Dagariane"
    if myName == "Unknown" or myName == "" then myName = "Dagariane" end
    local _, pClass = UnitClass("player")
    pClass = pClass or "PALADIN"
    local pLevel = UnitLevel("player") or 23
    local pGuild = (GetGuildInfo and GetGuildInfo("player")) or "Knights of Azeroth"
    local pFaction = (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"

    local enemyFaction = (pFaction == "Alliance") and "Horde" or "Alliance"
    local enemyClass = (enemyFaction == "Horde") and "ROGUE" or "WARRIOR"
    local enemyName = (enemyFaction == "Horde") and "Shadowstalker" or "Dawnbreaker"
    local enemyGuild = (enemyFaction == "Horde") and "Grim Syndicate" or "Silver Hand"
    local enemyLevel = math.max(1, pLevel + 1)

    if UnitExists("target") and UnitIsPlayer("target") then
        local tName = UnitName("target")
        if tName and KB.Utils.CanAccess(tName) and tName ~= "" then
            enemyName = tName
            local _, tClass = UnitClass("target")
            if tClass then enemyClass = tClass end
            local tGuild = GetGuildInfo("target")
            if tGuild and tGuild ~= "" then enemyGuild = tGuild end
            local tFaction = UnitFactionGroup("target")
            if tFaction then enemyFaction = tFaction end
            local tLevel = UnitLevel("target")
            if tLevel and tLevel > 0 then enemyLevel = tLevel end
        end
    end

    local selectedScenario = nil
    if type(mode) == "boolean" then
        selectedScenario = mode and "pve" or "pvp_death"
    elseif type(mode) == "string" and mode ~= "" then
        local m = mode:lower():match("^%s*(.-)%s*$")
        if m == "kill" or m == "dag" or m == "win" or m == "pvp_kill" or m == "victory" or m == "player" or m == "1" then
            selectedScenario = "pvp_kill"
        elseif m == "death" or m == "x" or m == "loss" or m == "pvp_death" or m == "die" or m == "2" then
            selectedScenario = "pvp_death"
        elseif m == "pve" or m == "npc" or m == "monster" or m == "mob" or m == "pillager" or m == "3" then
            selectedScenario = "pve"
        elseif m == "pvp" then
            UI.lastPvpTestMode = (UI.lastPvpTestMode == "pvp_kill") and "pvp_death" or "pvp_kill"
            selectedScenario = UI.lastPvpTestMode
        end
    end

    if not selectedScenario then
        -- Cycle: 1 = pvp_kill (Dag killed X), 2 = pvp_death (X killed Dag), 3 = pve (Defias Pillager killed Dag)
        UI.testCycleIndex = ((UI.testCycleIndex or 0) % 3) + 1
        if UI.testCycleIndex == 1 then
            selectedScenario = "pvp_kill"
        elseif UI.testCycleIndex == 2 then
            selectedScenario = "pvp_death"
        else
            selectedScenario = "pve"
        end
    end

    local testKM
    if selectedScenario == "pvp_kill" then
        local mySpell = (pClass == "PALADIN" and "Judgement") or
                        (pClass == "MAGE" and "Fireball") or
                        (pClass == "ROGUE" and "Eviscerate") or
                        (pClass == "WARLOCK" and "Shadow Bolt") or
                        (pClass == "HUNTER" and "Aimed Shot") or
                        (pClass == "WARRIOR" and "Mortal Strike") or "Combat Strike"

        testKM = {
            killId = "TEST-PVP-KILL-" .. tostring(time()),
            timestamp = time(),
            isSolo = true,
            isBattleground = false,
            isArena = false,
            isDuel = false,
            isPveDeath = false,
            attackersCount = 1,
            finalSpell = mySpell,
            killer = {
                name = myName,
                class = pClass,
                level = pLevel,
                guild = pGuild,
                faction = pFaction,
                spell = mySpell,
                isPlayer = true,
            },
            victim = {
                name = enemyName,
                class = enemyClass,
                level = enemyLevel,
                guild = enemyGuild,
                faction = enemyFaction,
                isPlayer = true,
            },
            location = {
                zone = "Hillsbrad Foothills",
                subZone = "Southshore",
                x = 50.1,
                y = 57.4,
            },
        }
        SafePrint(string.format("|cff00ff00[WoWKB Test]|r Previewing |cff38bdf8Alliance Victory|r: %s killed %s (|cff0078ffAlliance Blue Border|r)! (Commands: |cffffd100/kb test dag|r, |cffffd100/kb test x|r, |cffffd100/kb test pve|r)", KB.Utils.ColorizeByClass(myName, pClass), KB.Utils.ColorizeByClass(enemyName, enemyClass)))

    elseif selectedScenario == "pvp_death" then
        local enemySpell = (enemyClass == "MAGE" and "Pyroblast") or
                           (enemyClass == "ROGUE" and "Ambush") or
                           (enemyClass == "WARLOCK" and "Shadow Bolt") or
                           (enemyClass == "WARRIOR" and "Mortal Strike") or "Combat Strike"

        testKM = {
            killId = "TEST-PVP-DEATH-" .. tostring(time()),
            timestamp = time(),
            isSolo = true,
            isBattleground = false,
            isArena = false,
            isDuel = false,
            isPveDeath = false,
            attackersCount = 1,
            finalSpell = enemySpell,
            killer = {
                name = enemyName,
                class = enemyClass,
                level = math.max(enemyLevel, pLevel + 1),
                guild = enemyGuild,
                faction = enemyFaction,
                spell = enemySpell,
                isPlayer = true,
            },
            victim = {
                name = myName,
                class = pClass,
                level = pLevel,
                guild = pGuild,
                faction = pFaction,
                isPlayer = true,
            },
            location = {
                zone = "Hillsbrad Foothills",
                subZone = "Southshore",
                x = 50.1,
                y = 57.4,
            },
        }
        SafePrint(string.format("|cff00ff00[WoWKB Test]|r Previewing |cffff3838Horde Victory|r: %s killed %s (|cffff3838Horde Red Border|r)! (Commands: |cffffd100/kb test dag|r, |cffffd100/kb test x|r, |cffffd100/kb test pve|r)", KB.Utils.ColorizeByClass(enemyName, enemyClass), KB.Utils.ColorizeByClass(myName, pClass)))

    else -- "pve"
        testKM = {
            killId = "TEST-PVE-" .. tostring(time()),
            timestamp = time(),
            isSolo = false,
            isBattleground = false,
            isArena = false,
            isDuel = false,
            isPveDeath = true,
            attackersCount = 1,
            finalSpell = "Fireball",
            npc = {
                name = "Defias Pillager",
                spell = "Fireball",
                creatureType = "Humanoid",
                classification = "elite",
            },
            killer = {
                name = "Defias Pillager",
                class = "MAGE",
                level = 15,
                faction = "Monster",
                spell = "Fireball",
                creatureType = "Humanoid",
                classification = "elite",
            },
            victim = {
                name = myName,
                class = pClass,
                level = 23,
                guild = pGuild,
                faction = pFaction,
            },
            location = {
                zone = "Westfall",
                subZone = "Sentinel Hill",
                x = 42.5,
                y = 58.3,
            },
        }
        SafePrint(string.format("|cff00ff00[WoWKB Test]|r Previewing |cffff9900PvE Casualty|r: |cffffd100[15+] Defias Pillager|r killed %s (|cffffd100Classic Gold Border|r)! (Commands: |cffffd100/kb test dag|r, |cffffd100/kb test x|r, |cffffd100/kb test pve|r)", KB.Utils.ColorizeByClass(myName, pClass)))
    end

    UI:ShowKillBanner(testKM, true)
end

-- =========================================================================
-- Chat Broadcast & Realm Sharing Helpers (100% Zero-Taint)
-- =========================================================================
function UI:GetDefaultChatChannel()
    if IsInRaid and IsInRaid() then
        return "RAID"
    elseif IsInGroup and IsInGroup(LE_PARTY_CATEGORY_INSTANCE or 2) then
        return "INSTANCE_CHAT"
    elseif IsInGroup and IsInGroup() then
        return "PARTY"
    elseif IsInGuild and IsInGuild() then
        return "GUILD"
    else
        return "SAY"
    end
end

UI.shareOverrideChannel = nil

function UI:GetActiveShareChannel()
    if UI.shareOverrideChannel then
        return UI.shareOverrideChannel
    end
    return UI:GetDefaultChatChannel()
end

function UI:CycleShareChannel()
    local cur = UI:GetActiveShareChannel()
    if cur == "GUILD" then
        if IsInGroup and IsInGroup() then
            UI.shareOverrideChannel = "PARTY"
        else
            UI.shareOverrideChannel = "SAY"
        end
    elseif cur == "PARTY" or cur == "RAID" or cur == "INSTANCE_CHAT" then
        UI.shareOverrideChannel = "SAY"
    else
        if IsInGuild and IsInGuild() then
            UI.shareOverrideChannel = "GUILD"
        elseif IsInGroup and IsInGroup() then
            UI.shareOverrideChannel = "PARTY"
        else
            UI.shareOverrideChannel = "SAY"
        end
    end
    return UI:GetActiveShareChannel()
end

function UI:SendChatBroadcast(lines, targetChannel)
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot share to chat during combat.")
        return
    end
    if not lines or #lines == 0 then return end

    local channel = targetChannel or UI:GetActiveShareChannel()
    for _, text in ipairs(lines) do
        if SendChatMessage then
            SendChatMessage(text, channel)
        else
            SafePrint(text)
        end
    end
    SafePrint(string.format("|cff00e5ff[WoWKB]|r Shared %d line(s) to |cffffd100/%s|r chat.", #lines, channel:lower()))
end

function UI:GetShareData(category)
    local title = "Broadcast Intel"
    local compact = ""
    local detailedLines = {}

    local function ResolveFaction(f, name)
        if f and f ~= "" and f ~= "Unknown" and f ~= "UNKNOWN" then
            local s = tostring(f):lower()
            if s == "horde" then return "Horde" end
            if s == "alliance" then return "Alliance" end
            return f
        end
        if name and UnitName and name == UnitName("player") and UnitFactionGroup then
            local myFac = UnitFactionGroup("player")
            if myFac and myFac ~= "" then
                local s = tostring(myFac):lower()
                if s == "horde" then return "Horde" end
                if s == "alliance" then return "Alliance" end
                return myFac
            end
        end
        if name and KB.UnitScanner and KB.UnitScanner.Cache then
            for _, u in pairs(KB.UnitScanner.Cache) do
                if u.name and u.name:lower() == name:lower() and u.faction and u.faction ~= "Unknown" then
                    local s = tostring(u.faction):lower()
                    if s == "horde" then return "Horde" end
                    if s == "alliance" then return "Alliance" end
                    return u.faction
                end
            end
        end
        return "Contested"
    end

    local cta = "See all the stats at wowkillboard.com or download the app"

    if category == "WANTED" then
        title = "Most Wanted Outlaws"
        local outlaws = {}
        if WoWKillboardBounties then
            for _, b in pairs(WoWKillboardBounties) do
                if b.status == (KB.STATUS and KB.STATUS.ACTIVE or "ACTIVE") then
                    table.insert(outlaws, b)
                end
            end
            table.sort(outlaws, function(a, b)
                return (a.amountCopper or 0) > (b.amountCopper or 0)
            end)
        end
        if #outlaws == 0 then
            compact = string.format("[WoWKB: Most Wanted Outlaws] No active outlaw bounties currently registered — %s", cta)
            detailedLines = {
                "== [WoWKB] Most Wanted Outlaws ==",
                "No active outlaw bounties currently registered.",
                cta
            }
        else
            local parts = {}
            for i = 1, math.min(3, #outlaws) do
                local b = outlaws[i]
                local gold = b.amountGold or math.floor((b.amountCopper or 0) / 10000)
                local fac = ResolveFaction(b.targetFaction, b.targetName)
                table.insert(parts, string.format("#%d %s (%s - %dg)", i, b.targetName, fac, gold))
            end
            compact = string.format("[WoWKB: Most Wanted Outlaws] %s — %s", table.concat(parts, " | "), cta)

            detailedLines = { "== [WoWKB] Most Wanted Outlaws ==" }
            for i = 1, math.min(5, #outlaws) do
                local b = outlaws[i]
                local gold = b.amountGold or math.floor((b.amountCopper or 0) / 10000)
                local fac = ResolveFaction(b.targetFaction, b.targetName)
                table.insert(detailedLines, string.format("#%d %s [%s] | Bounty: %dg", i, b.targetName, fac, gold))
            end
            table.insert(detailedLines, cta)
        end

    elseif category == "CHAMPIONS" then
        local mode = currentMode or "ALL"
        local modeLabel = (mode == "ALL") and "All PvP" or mode
        title = string.format("Top PvP Champions - %s", modeLabel)
        local killers = KB.Leaderboard and KB.Leaderboard.GetTopKillers and KB.Leaderboard:GetTopKillers(mode, 5) or {}
        if #killers == 0 then
            compact = string.format("[WoWKB: Top PvP Champions - %s] No recorded champions in this category yet — %s", modeLabel, cta)
            detailedLines = {
                string.format("== [WoWKB] Top PvP Champions [%s] ==", modeLabel),
                "No champions recorded for this category yet.",
                cta
            }
        else
            local parts = {}
            for i = 1, math.min(3, #killers) do
                local p = killers[i]
                local fac = ResolveFaction(p.faction, p.name)
                table.insert(parts, string.format("#%d %s (%s - %d kills)", i, p.name, fac, p.kills))
            end
            compact = string.format("[WoWKB: Top PvP Champions - %s] %s — %s", modeLabel, table.concat(parts, " | "), cta)

            detailedLines = { string.format("== [WoWKB] Top PvP Champions [%s] ==", modeLabel) }
            for i, p in ipairs(killers) do
                local fac = ResolveFaction(p.faction, p.name)
                local kd = (p.deaths and p.deaths > 0) and string.format("%.2f", p.kills / p.deaths) or tostring(p.kills)
                table.insert(detailedLines, string.format("#%d %s [%s] - %d Kills (K/D: %s)", i, p.name, fac, p.kills, kd))
            end
            table.insert(detailedLines, cta)
        end

    elseif category == "GUILDS" then
        local mode = currentMode or "ALL"
        local modeLabel = (mode == "ALL") and "All PvP" or mode
        title = string.format("Top War Guilds - %s", modeLabel)
        local guilds = KB.Leaderboard and KB.Leaderboard.GetTopGuilds and KB.Leaderboard:GetTopGuilds(mode, 5) or {}
        if #guilds == 0 then
            compact = string.format("[WoWKB: Top War Guilds - %s] No recorded War Guilds in this category yet — %s", modeLabel, cta)
            detailedLines = {
                string.format("== [WoWKB] Top War Guilds [%s] ==", modeLabel),
                "No guilds recorded for this category yet.",
                cta
            }
        else
            local parts = {}
            for i = 1, math.min(3, #guilds) do
                local g = guilds[i]
                table.insert(parts, string.format("#%d <%s> (%d kills)", i, g.guild, g.kills))
            end
            compact = string.format("[WoWKB: Top War Guilds - %s] %s — %s", modeLabel, table.concat(parts, " | "), cta)

            detailedLines = { string.format("== [WoWKB] Top War Guilds [%s] ==", modeLabel) }
            for i, g in ipairs(guilds) do
                table.insert(detailedLines, string.format("#%d <%s> - %d Certified Kills", i, g.guild, g.kills))
            end
            table.insert(detailedLines, cta)
        end

    elseif category == "GANKERS" then
        title = "Top Gankers (24h)"
        local gankers = (WoWKillboard_RealmData and WoWKillboard_RealmData.TopGankers24h) or (WoWKillboardDB and WoWKillboardDB.RealmData and WoWKillboardDB.RealmData.TopGankers24h) or {}
        if #gankers == 0 then
            compact = string.format("[WoWKB: Top Gankers 24h] No active 24h gankers currently listed — %s", cta)
            detailedLines = {
                "== [WoWKB] Top Gankers (24h) ==",
                "No active gankers recorded in the last 24 hours.",
                cta
            }
        else
            local parts = {}
            for i = 1, math.min(3, #gankers) do
                local g = gankers[i]
                local fac = ResolveFaction(g.faction, g.name)
                table.insert(parts, string.format("#%d %s (%s - %d kills)", i, g.name or "Unknown", fac, g.kills or 0))
            end
            compact = string.format("[WoWKB: Top Gankers 24h] %s — %s", table.concat(parts, " | "), cta)

            detailedLines = { "== [WoWKB] Top Gankers (24h) ==" }
            for i = 1, math.min(5, #gankers) do
                local g = gankers[i]
                local fac = ResolveFaction(g.faction, g.name)
                table.insert(detailedLines, string.format("#%d %s [%s] - %d Kills", i, g.name or "Unknown", fac, g.kills or 0))
            end
            table.insert(detailedLines, cta)
        end
    end

    return title, compact, detailedLines
end

function UI:EnsureShareDialog()
    if UI.ShareDialog then return end

    local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    dlg:SetSize(580, 480)
    dlg:SetPoint("CENTER", 0, 20)
    dlg:SetFrameStrata("DIALOG")
    dlg:SetFrameLevel(125)
    dlg:EnableMouse(true)
    dlg:SetClampedToScreen(true)
    dlg:SetMovable(true)

    local theme = UI:GetTheme()
    dlg:SetBackdrop(theme.modalBackdrop or {
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 },
    })
    dlg:SetBackdropColor(unpack(theme.modalBg or { 0.06, 0.08, 0.12, 0.98 }))
    dlg:SetBackdropBorderColor(unpack(theme.modalBorder or { 0.85, 0.68, 0.22, 1.0 }))

    -- Header Drag Bar
    local header = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(28)
    header:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
    header:SetBackdropColor(0.12, 0.09, 0.06, 0.98)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() if not InCombatLockdown() then dlg:StartMoving() end end)
    header:SetScript("OnDragStop", function() dlg:StopMovingOrSizing() end)

    local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", 12, 0)
    title:SetText("|cffffd100WoW KILLBOARD  -  SHARE INTEL PREVIEW|r")

    local closeX = CreateFrame("Button", nil, header)
    closeX:SetSize(22, 22)
    closeX:SetPoint("RIGHT", -4, 0)
    local closeXText = closeX:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    closeXText:SetPoint("CENTER", 0, 0)
    closeXText:SetText("|cffff4444X|r")
    closeX:SetScript("OnClick", function() dlg:Hide() end)

    local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    sub:SetPoint("TOPLEFT", 16, -34)
    sub:SetText("|cff38bdf8Review before broadcasting. Click inside any box to copy (Ctrl+C).|r")

    -- Category Label & Channel Selector Row
    local catLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    catLabel:SetPoint("TOPLEFT", 16, -56)
    catLabel:SetText("|cffffd100Target: Intel Broadcast|r")
    dlg.CategoryLabel = catLabel

    local chBtn = UI:CreateButton(dlg, 190, 22, "Channel: /guild (Change)")
    chBtn:SetPoint("TOPRIGHT", -16, -54)
    chBtn:SetScript("OnClick", function()
        local nextCh = UI:CycleShareChannel()
        chBtn.Label:SetText("Channel: /" .. nextCh:lower() .. " (Change)")
        if dlg.BtnSendCompact then
            dlg.BtnSendCompact.Label:SetText("Send 1-Line to /" .. nextCh:lower())
        end
        if dlg.BtnSendDetailed then
            dlg.BtnSendDetailed.Label:SetText("Send Full to /" .. nextCh:lower())
        end
    end)
    dlg.ChannelBtn = chBtn

    -- Section 1: Compact (1-Line) Box
    local s1Label = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    s1Label:SetPoint("TOPLEFT", 16, -82)
    s1Label:SetText("|cff10b9811. Compact Broadcast (1 Line - Recommended for Low Chat Spam)|r")

    local box1 = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
    box1:SetPoint("TOPLEFT", 16, -98)
    box1:SetPoint("TOPRIGHT", -16, -98)
    box1:SetHeight(38)
    box1:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    box1:SetBackdropColor(0.02, 0.04, 0.08, 0.95)
    box1:SetBackdropBorderColor(0.18, 0.65, 0.40, 0.9)

    local eb1 = CreateFrame("EditBox", nil, box1)
    eb1:SetPoint("TOPLEFT", 8, -4)
    eb1:SetPoint("BOTTOMRIGHT", -8, 4)
    eb1:SetFontObject("GameFontHighlightSmall")
    eb1:SetMultiLine(false)
    eb1:SetAutoFocus(false)
    eb1:EnableMouse(true)
    eb1:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    eb1:SetScript("OnMouseUp", function(self) self:HighlightText() end)
    eb1:SetScript("OnEscapePressed", function() dlg:Hide() end)
    dlg.CompactEb = eb1

    local btnSendCompact = UI:CreateButton(dlg, 200, 24, "Send 1-Line to Chat", "GameFontHighlightSmall")
    btnSendCompact:SetPoint("TOPLEFT", 16, -140)
    btnSendCompact:SetScript("OnClick", function()
        local text = eb1:GetText()
        if text and text ~= "" then
            UI:SendChatBroadcast({ text }, UI:GetActiveShareChannel())
            dlg:Hide()
        end
    end)
    dlg.BtnSendCompact = btnSendCompact

    -- Section 2: Detailed (Multi-Line) Box
    local s2Label = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    s2Label:SetPoint("TOPLEFT", 16, -172)
    s2Label:SetText("|cffffd1002. Detailed Report (Full Multi-Line Breakdown)|r")

    local box2 = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
    box2:SetPoint("TOPLEFT", 16, -188)
    box2:SetPoint("TOPRIGHT", -16, -188)
    box2:SetHeight(180)
    box2:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    box2:SetBackdropColor(0.02, 0.04, 0.08, 0.95)
    box2:SetBackdropBorderColor(0.85, 0.68, 0.22, 0.7)

    local eb2 = CreateFrame("EditBox", nil, box2)
    eb2:SetPoint("TOPLEFT", 8, -6)
    eb2:SetPoint("BOTTOMRIGHT", -8, 6)
    eb2:SetFontObject("GameFontHighlightSmall")
    eb2:SetMultiLine(true)
    eb2:SetAutoFocus(false)
    eb2:EnableMouse(true)
    eb2:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    eb2:SetScript("OnMouseUp", function(self) self:HighlightText() end)
    eb2:SetScript("OnEscapePressed", function() dlg:Hide() end)
    dlg.DetailedEb = eb2

    local btnSendDetailed = UI:CreateButton(dlg, 200, 24, "Send Full Report to Chat", "GameFontHighlightSmall")
    btnSendDetailed:SetPoint("TOPLEFT", 16, -372)
    btnSendDetailed:SetScript("OnClick", function()
        if dlg.currentDetailedLines and #dlg.currentDetailedLines > 0 then
            UI:SendChatBroadcast(dlg.currentDetailedLines, UI:GetActiveShareChannel())
            dlg:Hide()
        end
    end)
    dlg.BtnSendDetailed = btnSendDetailed

    -- Tip & Close Button
    local tipFs = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    tipFs:SetPoint("BOTTOMLEFT", 16, 18)
    tipFs:SetText("Tip: Hit Ctrl+C to copy manually for Discord/whispers without chat spam.")

    local closeBtn = UI:CreateButton(dlg, 100, 26, "Close", "GameFontHighlightSmall")
    closeBtn:SetPoint("BOTTOMRIGHT", -16, 14)
    closeBtn:SetScript("OnClick", function() dlg:Hide() end)

    -- ESC key handler
    dlg:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            self:SetPropagateKeyboardInput(false)
            self:Hide()
        else
            self:SetPropagateKeyboardInput(true)
        end
    end)

    UI.ShareDialog = dlg
end

function UI:ShowShareModal(category)
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open share preview during combat.")
        return
    end

    UI:EnsureShareDialog()
    local dlg = UI.ShareDialog

    local title, compact, detailedLines = UI:GetShareData(category or "WANTED")
    dlg.currentCategory = category or "WANTED"
    dlg.currentDetailedLines = detailedLines
    dlg.currentCompactText = compact

    dlg.CategoryLabel:SetText("|cffffd100Target: " .. title .. "|r")
    dlg.CompactEb:SetText(compact)
    dlg.DetailedEb:SetText(table.concat(detailedLines, "\n"))

    local ch = UI:GetActiveShareChannel()
    dlg.ChannelBtn.Label:SetText("Channel: /" .. ch:lower() .. " (Change)")
    dlg.BtnSendCompact.Label:SetText("Send 1-Line to /" .. ch:lower())
    dlg.BtnSendDetailed.Label:SetText("Send Full to /" .. ch:lower())

    dlg:Show()
    if dlg.Raise then dlg:Raise() end
end

function UI:ShareWantedToChat()
    UI:ShowShareModal("WANTED")
end

function UI:ShareHitlistToChat()
    UI:ShowShareModal("WANTED")
end

function UI:ShareChampionsToChat()
    UI:ShowShareModal("CHAMPIONS")
end

function UI:ShareGuildsToChat()
    UI:ShowShareModal("GUILDS")
end

function UI:ShareGankersToChat()
    UI:ShowShareModal("GANKERS")
end

-- =========================================================================
-- Consolidated Settings & Preferences Modal (100% Template-Free, Zero-Taint)
-- =========================================================================
function UI:ShowSettingsModal()
    if InCombatLockdown and InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open settings during combat.")
        return
    end

    if not UI.SettingsDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(500, 630)
        dlg:SetPoint("CENTER", 0, 20)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(120)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)
        dlg:RegisterForDrag("LeftButton")
        dlg:SetScript("OnDragStart", function(self)
            if not InCombatLockdown() then self:StartMoving() end
        end)
        dlg:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
        end)

        -- ESC Key Handling
        dlg:EnableKeyboard(false)
        dlg:SetScript("OnShow", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(true) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            if self.toggleMoveBtn then
                self.toggleMoveBtn.Label:SetText(UI.bannerUnlocked and "|cffff3333Lock Toast|r" or "|cffffd100Move Toast|r")
            end
            if self.realmIsoBtn then
                local s = WoWKillboardSettings or KB.DefaultSettings or {}
                self.realmIsoBtn.Label:SetText((s.isolateRealms ~= false) and "|cff00ff00Realm: ACTIVE ONLY|r" or "|cffffaa00Realm: ALL REALMS|r")
            end
        end)
        dlg:SetScript("OnHide", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(false) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnKeyDown", function(self, key)
            if not self:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
                return
            end
            if key == "ESCAPE" then
                if UI.bannerUnlocked then UI:ToggleBannerLock(false) end
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                self:Hide()
            else
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            end
        end)

        local theme = UI:GetTheme()
        local aR, aG, aB, aHex = WoWKB.AccentColor()
        local aCode = "|cff" .. (aHex or "ffd100")
        dlg:SetBackdrop(theme and theme.modalBackdrop or {
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        dlg:SetBackdropColor(unpack(theme.modalBg or {0.06, 0.06, 0.08, 0.98}))
        dlg:SetBackdropBorderColor(unpack(theme.modalBorder or {0.0, 0.0, 0.0, 1.0}))

        -- Title & Subtitle
        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText(aCode .. "KILLBOARD SETTINGS & PREFERENCES|r")
        dlg.TitleText = title

        local sub = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sub:SetPoint("TOP", title, "BOTTOM", 0, -4)
        sub:SetText("|cffb8a080Configure interface appearance, combat alerts, and gameplay prompts.|r")

        -- Close Button [X]
        local closeBtn = CreateFrame("Button", nil, dlg, "BackdropTemplate")
        closeBtn:SetSize(22, 22)
        closeBtn:SetPoint("TOPRIGHT", -8, -8)
        closeBtn:EnableMouse(true)
        local closeLabel = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        closeLabel:SetPoint("CENTER", 0, 0)
        closeLabel:SetText("|cffff3333X|r")
        closeBtn.Label = closeLabel
        closeBtn:SetScript("OnClick", function()
            if UI.bannerUnlocked then UI:ToggleBannerLock(false) end
            if dlg.themeDropdownMenu then dlg.themeDropdownMenu:Hide() end
            dlg:Hide()
        end)

        local y = -60

        -- SECTION 1: INTERFACE THEME & ACCENT COLOR
        local s1Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        s1Title:SetPoint("TOPLEFT", 24, y)
        s1Title:SetText(aCode .. "1. Interface Theme & Accent Color|r")
        dlg.S1Title = s1Title

        local themeDesc = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        themeDesc:SetPoint("TOPLEFT", 24, y - 16)
        themeDesc:SetText("Choose interface theme and customize global highlight/accent color.")

        local function GetThemeDisplayName(themeId)
            themeId = (themeId or ""):lower()
            if themeId == "classic" then return "Classic"
            elseif themeId == "elvui" then return "ElvUI"
            else return "WKB Theme" end
        end

        local function GetThemeButtonLabel(t)
            local tid = t and t.id or "wkb"
            return string.format("Theme: %s  [v]", GetThemeDisplayName(tid))
        end

        local themeBtn = UI:CreateButton(dlg, 260, 24, "Toggle Theme")
        themeBtn:SetPoint("TOPLEFT", 24, y - 34)
        local curTheme = UI:GetTheme()
        themeBtn.Label:SetText(GetThemeButtonLabel(curTheme))

        -- Pure Lua Zero-Taint Theme Dropdown Menu: [Classic], [ElvUI], [WKB Theme]
        local themeMenu = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
        themeMenu:SetSize(260, 78)
        themeMenu:SetPoint("TOPLEFT", themeBtn, "BOTTOMLEFT", 0, -2)
        themeMenu:SetFrameStrata("TOOLTIP")
        themeMenu:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        themeMenu:Hide()
        dlg.themeDropdownMenu = themeMenu

        local themeOptions = {
            { id = "classic", name = "Classic" },
            { id = "elvui",   name = "ElvUI" },
            { id = "wkb",     name = "WKB Theme" },
        }

        local function UpdateThemeMenuVisuals()
            local cur = UI:GetTheme()
            themeMenu:SetBackdropColor(unpack(cur.cardBg or {0.043, 0.059, 0.090, 0.98}))
            themeMenu:SetBackdropBorderColor(unpack(cur.cardBorder or cur.modalBorder or {0.58, 0.45, 0.22, 1.0}))
        end

        for i, opt in ipairs(themeOptions) do
            local optBtn = CreateFrame("Button", nil, themeMenu, "BackdropTemplate")
            optBtn:SetSize(256, 22)
            optBtn:SetPoint("TOPLEFT", themeMenu, "TOPLEFT", 2, -2 - ((i - 1) * 24))
            optBtn:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            })
            optBtn:SetBackdropColor(0.06, 0.08, 0.12, 0.8)
            optBtn:SetBackdropBorderColor(0.12, 0.16, 0.23, 0.5)

            local optLabel = optBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            optLabel:SetPoint("LEFT", 10, 0)
            optLabel:SetText(opt.name)
            optBtn.Label = optLabel

            local optId = opt.id
            optBtn:SetScript("OnEnter", function(self)
                self:SetBackdropColor(0.12, 0.16, 0.24, 1.0)
                self:SetBackdropBorderColor(0.78, 0.60, 0.24, 0.8)
                self.Label:SetTextColor(1, 1, 1, 1)
            end)
            optBtn:SetScript("OnLeave", function(self)
                local curId = UI:GetCurrentThemeName()
                if curId == optId then
                    self:SetBackdropColor(0.78, 0.60, 0.24, 0.25)
                    self:SetBackdropBorderColor(0.78, 0.60, 0.24, 1.0)
                    self.Label:SetTextColor(0.984, 0.749, 0.141, 1.0)
                else
                    self:SetBackdropColor(0.06, 0.08, 0.12, 0.8)
                    self:SetBackdropBorderColor(0.12, 0.16, 0.23, 0.5)
                    self.Label:SetTextColor(0.75, 0.75, 0.75, 1.0)
                end
            end)
            optBtn:SetScript("OnClick", function()
                UI:SetTheme(optId)
                local cur = UI:GetTheme()
                themeBtn.Label:SetText(GetThemeButtonLabel(cur))
                dlg:SetBackdropColor(unpack(cur.mainBg or {0.04, 0.06, 0.09, 0.95}))
                dlg:SetBackdropBorderColor(unpack(cur.modalBorder or {0.58, 0.45, 0.22, 1.0}))
                UpdateThemeMenuVisuals()
                themeMenu:Hide()
            end)
        end

        themeBtn:SetScript("OnClick", function()
            if themeMenu:IsShown() then
                themeMenu:Hide()
            else
                UpdateThemeMenuVisuals()
                themeMenu:Show()
            end
        end)
        dlg.themeBtn = themeBtn

        -- Accent Color Mode Selector (Classic Gold, Class Color, Custom Picker)
        local accentLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        accentLabel:SetPoint("TOPLEFT", 24, y - 64)
        accentLabel:SetText("Accent Color:")

        local function SetToggleState(btn, text, isOn)
            if not btn then return end
            btn.isOn = isOn
            local curR, curG, curB, curHex = WoWKB.AccentColor()
            local theme = UI:GetTheme()
            if isOn then
                btn:SetBackdropColor(curR * 0.18, curG * 0.18, curB * 0.18, 0.95)
                btn:SetBackdropBorderColor(curR, curG, curB, 0.95)
                btn.Label:SetText(string.format("|cff%s* %s: ON|r", curHex or "ffd100", text))
            else
                btn:SetBackdropColor(unpack(theme.btnBg or { 0.08, 0.10, 0.15, 1.0 }))
                btn:SetBackdropBorderColor(unpack(theme.btnBorder or { 0.22, 0.22, 0.22, 0.95 }))
                btn.Label:SetText(string.format("|cff888888%s: OFF|r", text))
            end
        end

        local function UpdateAccentButtons()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            local mode = s.accentColorMode or "gold"
            local curR, curG, curB, curHex = WoWKB.AccentColor()
            local curCode = "|cff" .. (curHex or "ffd100")

            if dlg.TitleText then dlg.TitleText:SetText(curCode .. "KILLBOARD SETTINGS & PREFERENCES|r") end
            if dlg.S1Title then dlg.S1Title:SetText(curCode .. "1. Interface Theme & Accent Color|r") end
            if dlg.S2Title then dlg.S2Title:SetText(curCode .. "2. Combat Alerts & Kill Banners|r") end
            if dlg.S3Title then dlg.S3Title:SetText(curCode .. "3. Tactical Chat & Broadcast Telemetry|r") end
            if dlg.S4Title then dlg.S4Title:SetText(curCode .. "4. Mark of Spite Death Prompt|r") end
            if dlg.S5Title then dlg.S5Title:SetText(curCode .. "5. Data Export & Desktop Sync|r") end

            if dlg.btnGold then
                local isGold = (mode == "gold")
                dlg.btnGold:SetBackdropBorderColor(isGold and curR or 0.22, isGold and curG or 0.22, isGold and curB or 0.22, 1.0)
                dlg.btnGold.Label:SetTextColor(isGold and curR or 0.6, isGold and curG or 0.6, isGold and curB or 0.6)
            end
            if dlg.btnClass then
                local isClass = (mode == "class")
                dlg.btnClass:SetBackdropBorderColor(isClass and curR or 0.22, isClass and curG or 0.22, isClass and curB or 0.22, 1.0)
                dlg.btnClass.Label:SetTextColor(isClass and curR or 0.6, isClass and curG or 0.6, isClass and curB or 0.6)
            end
            if dlg.btnCustom then
                local isCustom = (mode == "custom")
                dlg.btnCustom:SetBackdropBorderColor(isCustom and curR or 0.22, isCustom and curG or 0.22, isCustom and curB or 0.22, 1.0)
                dlg.btnCustom.Label:SetTextColor(isCustom and curR or 0.6, isCustom and curG or 0.6, isCustom and curB or 0.6)
            end
            if dlg.toggleMoveBtn and dlg.toggleMoveBtn.Label then
                if UI.bannerUnlocked then
                    dlg.toggleMoveBtn.Label:SetText("|cffff3333Lock Toast|r")
                    dlg.toggleMoveBtn:SetBackdropBorderColor(1.0, 0.2, 0.2, 0.9)
                else
                    dlg.toggleMoveBtn.Label:SetText(curCode .. "Move Toast|r")
                    dlg.toggleMoveBtn:SetBackdropBorderColor(curR, curG, curB, 0.6)
                end
            end
            if dlg.calibBtn and dlg.calibBtn.Label then
                dlg.calibBtn.Label:SetText("Calibrate Alerts")
                dlg.calibBtn:SetBackdropBorderColor(0.3, 0.3, 0.3, 1.0)
            end
            if dlg.bcastTestBtn and dlg.bcastTestBtn.Label then
                dlg.bcastTestBtn.Label:SetText("|cff38bdf8Broadcast Test|r")
                dlg.bcastTestBtn:SetBackdropBorderColor(56/255, 189/255, 248/255, 0.6)
            end
            if dlg.announceBtn and dlg.announceBtn.Label then
                dlg.announceBtn.Label:SetText(curCode .. "Realm Announce|r")
                dlg.announceBtn:SetBackdropBorderColor(curR, curG, curB, 0.6)
            end
            if dlg.exportBtn and dlg.exportBtn.Label then
                dlg.exportBtn.Label:SetText("Export Data / JSON")
                dlg.exportBtn:SetBackdropBorderColor(0.3, 0.3, 0.3, 1.0)
            end
            if dlg.reloadBtn and dlg.reloadBtn.Label then
                dlg.reloadBtn.Label:SetText(curCode .. "Save & Reload UI|r")
                dlg.reloadBtn:SetBackdropBorderColor(curR, curG, curB, 0.6)
            end
            if dlg.doneBtn and dlg.doneBtn.Label then
                dlg.doneBtn.Label:SetText("Done")
                dlg.doneBtn:SetBackdropBorderColor(curR, curG, curB, 0.6)
            end

            -- Update toggle button states
            SetToggleState(dlg.soundBtn, "Sound Alerts", s.soundAlerts ~= false)
            SetToggleState(dlg.chatStreamBtn, "Chat Stream", s.showChannelInChat == true)
            SetToggleState(dlg.chatBroadcastBtn, "Chat (Yell/Say)", s.enableChatBroadcasts == true)
            SetToggleState(dlg.guildBroadcastBtn, "Guild Alerts", s.enableGuildBroadcasts ~= false)
            SetToggleState(dlg.coordsBtn, "GPS Coordinates", s.includeCoordinates ~= false)
            SetToggleState(dlg.autoInviteBtn, "Auto-Invite", s.enableWhisperAutoInvite ~= false)
            SetToggleState(dlg.deathPromptBtn, "Death Mark Prompt", not s.ignoreDeathBounties)
            if s.isolateRealms ~= false then
                SetToggleState(dlg.realmIsoBtn, "Active Realm Only", true)
            else
                SetToggleState(dlg.realmIsoBtn, "All Account Realms", false)
            end
        end
        dlg.UpdateAccentButtons = UpdateAccentButtons

        local btnGold = UI:CreateButton(dlg, 110, 20, "Classic Gold")
        btnGold:SetPoint("LEFT", accentLabel, "RIGHT", 10, 0)
        btnGold:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.accentColorMode = "gold"
            UpdateAccentButtons()
            UI:Refresh()
        end)
        dlg.btnGold = btnGold

        local btnClass = UI:CreateButton(dlg, 110, 20, "Class Color")
        btnClass:SetPoint("LEFT", btnGold, "RIGHT", 6, 0)
        btnClass:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.accentColorMode = "class"
            UpdateAccentButtons()
            UI:Refresh()
        end)
        dlg.btnClass = btnClass

        local btnCustom = UI:CreateButton(dlg, 110, 20, "Custom Picker")
        btnCustom:SetPoint("LEFT", btnClass, "RIGHT", 6, 0)
        btnCustom:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            local curR, curG, curB = WoWKB.AccentColor()
            if ColorPickerFrame.SetupColorPickerAndShow then
                local info = {
                    swatchFunc = function()
                        local r, g, b = ColorPickerFrame:GetColorRGB()
                        s.customAccentColor = { r, g, b, 1.0 }
                        s.accentColorMode = "custom"
                        UpdateAccentButtons()
                        UI:Refresh()
                    end,
                    cancelFunc = function(prev)
                        if prev then
                            s.customAccentColor = { prev.r, prev.g, prev.b, 1.0 }
                            UpdateAccentButtons()
                            UI:Refresh()
                        end
                    end,
                    r = curR, g = curG, b = curB,
                    hasOpacity = false,
                    previousValues = { r = curR, g = curG, b = curB },
                }
                ColorPickerFrame:SetupColorPickerAndShow(info)
            else
                ColorPickerFrame.func = function()
                    local r, g, b = ColorPickerFrame:GetColorRGB()
                    s.customAccentColor = { r, g, b, 1.0 }
                    s.accentColorMode = "custom"
                    UpdateAccentButtons()
                    UI:Refresh()
                end
                ColorPickerFrame.hasOpacity = false
                ColorPickerFrame.previousValues = { curR, curG, curB, 1.0 }
                ColorPickerFrame.cancelFunc = function()
                    s.customAccentColor = { curR, curG, curB, 1.0 }
                    UpdateAccentButtons()
                    UI:Refresh()
                end
                ColorPickerFrame:SetColorRGB(curR, curG, curB)
                ColorPickerFrame:Show()
            end
        end)
        dlg.btnCustom = btnCustom

        y = y - 96

        -- SECTION 2: COMBAT ALERTS & RADAR
        local s2Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        s2Title:SetPoint("TOPLEFT", 24, y)
        s2Title:SetText(aCode .. "2. Combat Alerts & Kill Banners|r")
        dlg.S2Title = s2Title

        local alertsDesc = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        alertsDesc:SetPoint("TOPLEFT", 24, y - 16)
        alertsDesc:SetText("Calibrate screen positioning, kill banner scale, sound, and HUD.")

        local calibBtn = UI:CreateButton(dlg, 165, 22, "Calibrate Alerts")
        calibBtn:SetPoint("TOPLEFT", 24, y - 34)
        calibBtn:SetScript("OnClick", function()
            dlg:Hide()
            UI:ShowAlertsConfig()
        end)
        dlg.calibBtn = calibBtn

        local toggleMoveBtn = UI:CreateButton(dlg, 145, 22, UI.bannerUnlocked and "|cffff3333Lock Toast|r" or "|cffffd100Move Toast|r")
        toggleMoveBtn:SetPoint("LEFT", calibBtn, "RIGHT", 10, 0)
        toggleMoveBtn:SetScript("OnClick", function()
            UI:ToggleBannerLock()
            UpdateAccentButtons()
        end)
        dlg.toggleMoveBtn = toggleMoveBtn

        local soundBtn = UI:CreateButton(dlg, 130, 22, "Sound: Enabled")
        soundBtn:SetPoint("LEFT", toggleMoveBtn, "RIGHT", 10, 0)
        soundBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.soundAlerts = not s.soundAlerts
            if KB.db and KB.db.settings then KB.db.settings.soundAlerts = s.soundAlerts end
            UpdateAccentButtons()
        end)
        dlg.soundBtn = soundBtn

        -- Row 2: Live Chat Stream, Network Broadcast Simulation & Realm Update Broadcaster
        local chatStreamBtn = UI:CreateButton(dlg, 145, 22, "Chat Stream: OFF")
        chatStreamBtn:SetPoint("TOPLEFT", 24, y - 60)
        chatStreamBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.showChannelInChat = not s.showChannelInChat
            if KB.db and KB.db.settings then KB.db.settings.showChannelInChat = s.showChannelInChat end
            if KB.Sync and KB.Sync.ApplyChatVisibility then KB.Sync:ApplyChatVisibility() end
            UpdateAccentButtons()
        end)
        chatStreamBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "Chat Window Casualty Stream", "Toggle live casualty alerts in your chat window. When ON, open-world kills stream into General chat. When OFF, chat is kept clean and quiet.")
        end)
        chatStreamBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.chatStreamBtn = chatStreamBtn

        local bcastTestBtn = UI:CreateButton(dlg, 145, 22, "|cff38bdf8Broadcast Test|r")
        bcastTestBtn:SetPoint("LEFT", chatStreamBtn, "RIGHT", 10, 0)
        bcastTestBtn:SetScript("OnClick", function()
            if KB.Sync and KB.Sync.BroadcastTestCasualty then
                KB.Sync:BroadcastTestCasualty("pve")
            end
        end)
        bcastTestBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cff38bdf8Broadcast Test (Party/Net)|r", "Simulates a casualty across your Party, Guild, and Realm channel to test toast alerts on your other computers without saving to history.")
        end)
        bcastTestBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.bcastTestBtn = bcastTestBtn

        local announceBtn = UI:CreateButton(dlg, 150, 22, "|cffffd100Realm Announce|r")
        announceBtn:SetPoint("LEFT", bcastTestBtn, "RIGHT", 10, 0)
        announceBtn:SetScript("OnClick", function()
            dlg:Hide()
            UI:ShowAnnouncementModal()
        end)
        announceBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Announce Update to Realm|r", "Broadcasts an on-screen update warning across Party, Guild, and Realm channel to notify other players.")
        end)
        announceBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.announceBtn = announceBtn

        y = y - 94

        -- SECTION 3: TACTICAL CHAT & BROADCAST TELEMETRY
        local s3Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        s3Title:SetPoint("TOPLEFT", 24, y)
        s3Title:SetText(aCode .. "3. Tactical Chat & Broadcast Telemetry|r")
        dlg.S3Title = s3Title

        local s3Desc = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        s3Desc:SetPoint("TOPLEFT", 24, y - 16)
        s3Desc:SetText("Configure public callouts, guild defense alerts, GPS coords & auto-invites.")

        -- Row 1: Chat Broadcasts & Guild Broadcasts
        local chatBroadcastBtn = UI:CreateButton(dlg, 220, 22, "Chat (Yell/Say): OFF")
        chatBroadcastBtn:SetPoint("TOPLEFT", 24, y - 34)
        chatBroadcastBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.enableChatBroadcasts = not s.enableChatBroadcasts
            UpdateAccentButtons()
            SafePrint(string.format("|cff00e5ff[WoWKB]|r Chat Broadcasts (Yell/Say) is now %s.", s.enableChatBroadcasts and "|cff00ff00ENABLED|r" or "|cffff3333DISABLED (Opt-in)|r"))
        end)
        chatBroadcastBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Chat Broadcasts (Yell/Say)|r", "Broadcasts public defense callouts via /yell during open world PvP engagements. [Default: Off / Opt-in]")
        end)
        chatBroadcastBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.chatBroadcastBtn = chatBroadcastBtn

        local guildBroadcastBtn = UI:CreateButton(dlg, 220, 22, "Guild Broadcasts: ON")
        guildBroadcastBtn:SetPoint("LEFT", chatBroadcastBtn, "RIGHT", 10, 0)
        guildBroadcastBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.enableGuildBroadcasts = (s.enableGuildBroadcasts == false)
            UpdateAccentButtons()
            SafePrint(string.format("|cff00e5ff[WoWKB]|r Guild Broadcasts is now %s.", s.enableGuildBroadcasts and "|cff00ff00ENABLED|r" or "|cffff3333DISABLED|r"))
        end)
        guildBroadcastBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Guild Broadcasts|r", "Dispatches tactical defense alerts and casualties to your Guild chat channel. [Default: On]")
        end)
        guildBroadcastBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.guildBroadcastBtn = guildBroadcastBtn

        -- Row 2: Include Coordinates & Whisper Auto-Invite
        local coordsBtn = UI:CreateButton(dlg, 220, 22, "Coordinates: ON")
        coordsBtn:SetPoint("TOPLEFT", 24, y - 60)
        coordsBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.includeCoordinates = (s.includeCoordinates == false)
            UpdateAccentButtons()
            SafePrint(string.format("|cff00e5ff[WoWKB]|r Include Coordinates is now %s.", s.includeCoordinates and "|cff00ff00ENABLED|r" or "|cffff3333DISABLED|r"))
        end)
        coordsBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Include Coordinates|r", "Appends real-time map GPS coordinates (e.g. 66.7, 42.4) to chat callouts. [Default: On]")
        end)
        coordsBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.coordsBtn = coordsBtn

        local autoInviteBtn = UI:CreateButton(dlg, 220, 22, "Auto-Invite: ON")
        autoInviteBtn:SetPoint("LEFT", coordsBtn, "RIGHT", 10, 0)
        autoInviteBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.enableWhisperAutoInvite = (s.enableWhisperAutoInvite == false)
            UpdateAccentButtons()
            SafePrint(string.format("|cff00e5ff[WoWKB]|r Whisper Auto-Invite is now %s.", s.enableWhisperAutoInvite and "|cff00ff00ENABLED|r" or "|cffff3333DISABLED|r"))
        end)
        autoInviteBtn:SetScript("OnEnter", function(self)
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Whisper Auto-Invite|r", "Automatically adds friendly allies to your squad when they whisper 'invite' or 'rally'. [Default: On]")
        end)
        autoInviteBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.autoInviteBtn = autoInviteBtn

        y = y - 96

        -- SECTION 4: DEATH MARK PROMPT (MARK OF SPITE)
        local s4Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        s4Title:SetPoint("TOPLEFT", 24, y)
        s4Title:SetText(aCode .. "4. Mark of Spite Death Prompt|r")
        dlg.S4Title = s4Title

        local deathDesc = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        deathDesc:SetPoint("TOPLEFT", 24, y - 16)
        deathDesc:SetText("Offer to declare an execution contract when slain in open combat.\n(Prompts are automatically suppressed in Battlegrounds and Arenas).")

        local deathPromptBtn = UI:CreateButton(dlg, 220, 22, "Death Prompt: Enabled")
        deathPromptBtn:SetPoint("TOPLEFT", 24, y - 44)
        deathPromptBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.ignoreDeathBounties = not s.ignoreDeathBounties
            if KB.db and KB.db.settings then KB.db.settings.ignoreDeathBounties = s.ignoreDeathBounties end
            UpdateAccentButtons()
            SafePrint(string.format("|cff00e5ff[WoWKB]|r Death Mark Prompt is now %s.", s.ignoreDeathBounties and "|cffff3333MUTED|r" or "|cff00ff00ENABLED|r"))
        end)
        dlg.deathPromptBtn = deathPromptBtn

        local realmIsoBtn = UI:CreateButton(dlg, 220, 22, "Realm: Active Only")
        realmIsoBtn:SetPoint("LEFT", deathPromptBtn, "RIGHT", 10, 0)
        realmIsoBtn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings or {}
            s.isolateRealms = (s.isolateRealms == false)
            UpdateAccentButtons()
            SafePrint(string.format("|cff00e5ff[WoWKB]|r Realm Isolation is now %s.", (s.isolateRealms ~= false) and "|cff00ff00ENABLED (Active Realm Only)|r" or "|cffffaa00DISABLED (All Account Realms)|r"))
            if KB.Leaderboard and KB.Leaderboard.Rebuild then KB.Leaderboard:Rebuild() end
            UI:Refresh()
        end)
        realmIsoBtn:SetScript("OnEnter", function(self)
            local myRealm = (GetRealmName and GetRealmName()) or "Current"
            UI:ShowPrivateTooltip(self, "BOTTOM", "TOP", 0, 4, "|cffffd100Realm Telemetry Isolation|r", string.format("Restricts combat data, killfeeds, and standings strictly to |cffffffff%s|r.\nPrevents PvP kills from leaking into PvE, Hardcore, or RP servers. [Default: On]", myRealm))
        end)
        realmIsoBtn:SetScript("OnLeave", function() UI:HidePrivateTooltip() end)
        dlg.realmIsoBtn = realmIsoBtn

        y = y - 78

        -- SECTION 5: DATA EXPORT & DESKTOP SYNC
        local s5Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        s5Title:SetPoint("TOPLEFT", 24, y)
        s5Title:SetText(aCode .. "5. Data Export & Desktop Sync|r")
        dlg.S5Title = s5Title

        local exportBtn = UI:CreateButton(dlg, 160, 22, "Export Data / JSON")
        exportBtn:SetPoint("TOPLEFT", 24, y - 22)
        exportBtn:SetScript("OnClick", function()
            dlg:Hide()
            UI:ShowExportDialog()
        end)
        dlg.exportBtn = exportBtn

        local reloadBtn = UI:CreateButton(dlg, 160, 22, "Save & Reload UI")
        reloadBtn:SetPoint("LEFT", exportBtn, "RIGHT", 10, 0)
        reloadBtn:SetScript("OnClick", function()
            if InCombatLockdown and InCombatLockdown() then
                SafePrint("|cffff9900[WoWKB]|r Cannot reload UI during combat.")
                return
            end
            SafePrint("|cff00ccff[WoWKB]|r Saving combat records and reloading UI...")
            ReloadUI()
        end)
        dlg.reloadBtn = reloadBtn

        -- Bottom Done Button
        local doneBtn = UI:CreateButton(dlg, 120, 26, "Done")
        doneBtn:SetPoint("BOTTOM", 0, 16)
        doneBtn:SetScript("OnClick", function()
            if dlg.themeDropdownMenu then dlg.themeDropdownMenu:Hide() end
            dlg:Hide()
        end)
        dlg.doneBtn = doneBtn

        UI.SettingsDialog = dlg
    end

    -- Update dynamic labels and toggle states
    local cur = UI:GetTheme()
    if UI.SettingsDialog.themeBtn and UI.SettingsDialog.themeBtn.Label then
        local tName = (cur.id == "classic") and "Classic"
            or ((cur.id == "elvui") and "ElvUI"
            or "WKB Theme")
        UI.SettingsDialog.themeBtn.Label:SetText(string.format("Theme: %s  [v]", tName))
    end
    if UI.SettingsDialog.themeDropdownMenu then
        UI.SettingsDialog.themeDropdownMenu:Hide()
    end
    if UI.SettingsDialog.UpdateAccentButtons then
        UI.SettingsDialog:UpdateAccentButtons()
    end

    UI.SettingsDialog:Show()
end

-- Alerts & Radar Configuration Modal Dialog (100% Template-Free, Zero-Taint)
function UI:ShowAlertsConfig()
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot open configuration during combat.")
        return
    end

    if not UI.AlertsDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(520, 665)
        dlg:SetPoint("CENTER", 0, 20)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(120)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)
        dlg:RegisterForDrag("LeftButton")
        dlg:SetScript("OnDragStart", function(self)
            if not InCombatLockdown() then self:StartMoving() end
        end)
        dlg:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
        end)

        local theme = UI:GetTheme()
        local aR, aG, aB, aHex = WoWKB.AccentColor()
        local aCode = "|cff" .. (aHex or "ffd100")
        dlg:SetBackdrop(theme and theme.modalBackdrop or {
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        dlg:SetBackdropColor(unpack(theme.modalBg or {0.06, 0.06, 0.08, 0.98}))
        dlg:SetBackdropBorderColor(unpack(theme.modalBorder or {0.0, 0.0, 0.0, 1.0}))

        -- ESC Key Handling (only active when shown)
        dlg:EnableKeyboard(false)
        dlg:SetScript("OnShow", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(true) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnHide", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(false) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnKeyDown", function(self, key)
            if not self:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
                return
            end
            if key == "ESCAPE" then
                if UI.bannerUnlocked then UI:ToggleBannerLock(false) end
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                self:Hide()
            else
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            end
        end)

        -- Header
        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText(aCode .. "FRONTLINE COMBAT ALERTS & RADAR|r")
        dlg.TitleText = title

        local subtitle = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        subtitle:SetPoint("TOP", 0, -38)
        subtitle:SetText("|cff94a3b8Configure on-screen kill notifications, audio feedback, raid warnings & positioning|r")
        dlg.SubtitleText = subtitle

        local div = dlg:CreateTexture(nil, "ARTWORK")
        div:SetHeight(1)
        div:SetPoint("TOPLEFT", 18, -56)
        div:SetPoint("TOPRIGHT", -18, -56)
        div:SetColorTexture(0.2, 0.2, 0.2, 0.8)
        dlg.Divider = div

        -- Helper to style segmented buttons
        local function StyleSegmentButton(btn, text)
            btn.baseText = text
            btn.Label:SetText(text)
        end

        -- Section 1: Alert Delivery Mode & Live Chat Stream
        local sec1Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec1Title:SetPoint("TOPLEFT", 24, -68)
        sec1Title:SetText(aCode .. "1. CASUALTY ALERT DELIVERY & CHAT STREAM|r")
        dlg.Sec1Title = sec1Title

        -- Row 1: 4 Quick Delivery Presets
        local btnPresetBoth = UI:CreateButton(dlg, 110, 24, "Both Displays", "GameFontHighlightSmall")
        btnPresetBoth:SetPoint("TOPLEFT", 24, -88)
        StyleSegmentButton(btnPresetBoth, "Both Displays")
        dlg.BtnPresetBoth = btnPresetBoth

        local btnPresetHeadsUp = UI:CreateButton(dlg, 110, 24, "Heads-Up Only", "GameFontHighlightSmall")
        btnPresetHeadsUp:SetPoint("LEFT", btnPresetBoth, "RIGHT", 6, 0)
        StyleSegmentButton(btnPresetHeadsUp, "Heads-Up Only")
        dlg.BtnPresetHeadsUp = btnPresetHeadsUp

        local btnPresetChat = UI:CreateButton(dlg, 116, 24, "Chat Log Only", "GameFontHighlightSmall")
        btnPresetChat:SetPoint("LEFT", btnPresetHeadsUp, "RIGHT", 6, 0)
        StyleSegmentButton(btnPresetChat, "Chat Log Only")
        dlg.BtnPresetChat = btnPresetChat

        local btnPresetOff = UI:CreateButton(dlg, 110, 24, "Muted / Off", "GameFontHighlightSmall")
        btnPresetOff:SetPoint("LEFT", btnPresetChat, "RIGHT", 6, 0)
        StyleSegmentButton(btnPresetOff, "Muted / Off")
        dlg.BtnPresetOff = btnPresetOff

        -- Row 2: Granular Toggles
        local btnToggleChat = UI:CreateButton(dlg, 226, 22, "Chat Window Feed: ON", "GameFontHighlightSmall")
        btnToggleChat:SetPoint("TOPLEFT", 24, -118)
        dlg.BtnToggleChat = btnToggleChat

        local btnToggleSound = UI:CreateButton(dlg, 230, 22, "Audio Warhorn: ON", "GameFontHighlightSmall")
        btnToggleSound:SetPoint("LEFT", btnToggleChat, "RIGHT", 8, 0)
        dlg.BtnToggleSound = btnToggleSound

        local modeHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        modeHint:SetPoint("TOPLEFT", 24, -146)
        dlg.ModeHint = modeHint

        -- Section 2: Proximity & Scope Filter (Radar)
        local sec2Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec2Title:SetPoint("TOPLEFT", 24, -170)
        sec2Title:SetText(aCode .. "2. RADAR & PROXIMITY SCOPE|r")
        dlg.Sec2Title = sec2Title

        local btnScopeZone = UI:CreateButton(dlg, 150, 24, "Same Zone Only", "GameFontHighlightSmall")
        btnScopeZone:SetPoint("TOPLEFT", 24, -190)
        StyleSegmentButton(btnScopeZone, "Same Zone Only")
        dlg.BtnScopeZone = btnScopeZone

        local btnScopeAll = UI:CreateButton(dlg, 150, 24, "Entire Realm", "GameFontHighlightSmall")
        btnScopeAll:SetPoint("LEFT", btnScopeZone, "RIGHT", 11, 0)
        StyleSegmentButton(btnScopeAll, "Entire Realm")
        dlg.BtnScopeAll = btnScopeAll

        local btnScopeMine = UI:CreateButton(dlg, 150, 24, "Personal Only", "GameFontHighlightSmall")
        btnScopeMine:SetPoint("LEFT", btnScopeAll, "RIGHT", 11, 0)
        StyleSegmentButton(btnScopeMine, "Personal Only")
        dlg.BtnScopeMine = btnScopeMine

        local scopeHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        scopeHint:SetPoint("TOPLEFT", 24, -218)
        dlg.ScopeHint = scopeHint

        -- Section 3: Visual Alert Style (Raid Warning vs Tactical Banner)
        local sec3Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec3Title:SetPoint("TOPLEFT", 24, -242)
        sec3Title:SetText(aCode .. "3. VISUAL ALERT STYLE|r")
        dlg.Sec3Title = sec3Title

        local btnStyleBoth = UI:CreateButton(dlg, 150, 24, "Both Displays", "GameFontHighlightSmall")
        btnStyleBoth:SetPoint("TOPLEFT", 24, -262)
        StyleSegmentButton(btnStyleBoth, "Both Displays")
        dlg.BtnStyleBoth = btnStyleBoth

        local btnStyleRW = UI:CreateButton(dlg, 150, 24, "Raid Warning", "GameFontHighlightSmall")
        btnStyleRW:SetPoint("LEFT", btnStyleBoth, "RIGHT", 11, 0)
        StyleSegmentButton(btnStyleRW, "Raid Warning")
        dlg.BtnStyleRW = btnStyleRW

        local btnStyleBanner = UI:CreateButton(dlg, 150, 24, "Tactical Banner", "GameFontHighlightSmall")
        btnStyleBanner:SetPoint("LEFT", btnStyleRW, "RIGHT", 11, 0)
        StyleSegmentButton(btnStyleBanner, "Tactical Banner")
        dlg.BtnStyleBanner = btnStyleBanner

        local styleHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        styleHint:SetPoint("TOPLEFT", 24, -290)
        dlg.StyleHint = styleHint

        -- Section 4: Screen Positioning & Calibration
        local sec4Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec4Title:SetPoint("TOPLEFT", 24, -314)
        sec4Title:SetText(aCode .. "4. SCREEN POSITIONING & CALIBRATION|r")
        dlg.Sec4Title = sec4Title

        local unlockBtn = UI:CreateButton(dlg, 230, 24, "Move / Unlock Alert Anchor", "GameFontHighlightSmall")
        unlockBtn:SetPoint("TOPLEFT", 24, -334)
        dlg.UnlockBtn = unlockBtn

        local resetBtn = UI:CreateButton(dlg, 230, 24, "Reset to Center", "GameFontHighlightSmall")
        resetBtn:SetPoint("LEFT", unlockBtn, "RIGHT", 12, 0)
        dlg.ResetBtn = resetBtn

        local posHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        posHint:SetPoint("TOPLEFT", 24, -362)
        posHint:SetText("|cff94a3b8Click 'Move / Unlock' or type |cffffd100/wowkb move|r to drag alert anywhere on screen.|r")
        dlg.PosHint = posHint

        local posCoords = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        posCoords:SetPoint("TOPLEFT", 24, -378)
        dlg.PosCoords = posCoords

        -- Section 5: Mark of Spite Death Popup
        local sec5Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec5Title:SetPoint("TOPLEFT", 24, -404)
        sec5Title:SetText(aCode .. "5. MARK OF SPITE DEATH POPUP|r")
        dlg.Sec5Title = sec5Title

        local btnMarkPromptOn = UI:CreateButton(dlg, 230, 24, "Prompt on Death", "GameFontHighlightSmall")
        btnMarkPromptOn:SetPoint("TOPLEFT", 24, -424)
        StyleSegmentButton(btnMarkPromptOn, "Prompt on Death")
        dlg.BtnMarkPromptOn = btnMarkPromptOn

        local btnMarkPromptOff = UI:CreateButton(dlg, 230, 24, "Never Prompt / Muted", "GameFontHighlightSmall")
        btnMarkPromptOff:SetPoint("LEFT", btnMarkPromptOn, "RIGHT", 12, 0)
        StyleSegmentButton(btnMarkPromptOff, "Never Prompt / Muted")
        dlg.BtnMarkPromptOff = btnMarkPromptOff

        local markHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        markHint:SetPoint("TOPLEFT", 24, -452)
        dlg.MarkHint = markHint

        -- Section 6: Combat Feed Destination (Shadow Network vs Main Chat)
        local sec6Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec6Title:SetPoint("TOPLEFT", 24, -476)
        sec6Title:SetText(aCode .. "6. COMBAT FEED DESTINATION|r")
        dlg.Sec6Title = sec6Title

        local btnFeedWire = UI:CreateButton(dlg, 150, 24, "Shadow Network", "GameFontHighlightSmall")
        btnFeedWire:SetPoint("TOPLEFT", 24, -496)
        StyleSegmentButton(btnFeedWire, "Shadow Network")
        dlg.BtnFeedWire = btnFeedWire

        local btnFeedChat = UI:CreateButton(dlg, 150, 24, "Main Chat Frame", "GameFontHighlightSmall")
        btnFeedChat:SetPoint("LEFT", btnFeedWire, "RIGHT", 11, 0)
        StyleSegmentButton(btnFeedChat, "Main Chat Frame")
        dlg.BtnFeedChat = btnFeedChat

        local btnFeedOff = UI:CreateButton(dlg, 150, 24, "Muted / Off", "GameFontHighlightSmall")
        btnFeedOff:SetPoint("LEFT", btnFeedChat, "RIGHT", 11, 0)
        StyleSegmentButton(btnFeedOff, "Muted / Off")
        dlg.BtnFeedOff = btnFeedOff

        local feedHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        feedHint:SetPoint("TOPLEFT", 24, -524)
        dlg.FeedHint = feedHint

        -- Bottom Divider
        local bDiv = dlg:CreateTexture(nil, "ARTWORK")
        bDiv:SetHeight(1)
        bDiv:SetPoint("TOPLEFT", 18, -552)
        bDiv:SetPoint("TOPRIGHT", -18, -552)
        dlg.BottomDivider = bDiv

        -- Footer Action Buttons
        local testBtn = UI:CreateButton(dlg, 145, 28, "Test Local Preview", "GameFontHighlightSmall")
        testBtn:SetPoint("BOTTOMLEFT", 20, 16)
        dlg.TestBtn = testBtn

        local bcastBtn = UI:CreateButton(dlg, 210, 28, "|cff38bdf8Broadcast Test (Party/Net)|r", "GameFontHighlightSmall")
        bcastBtn:SetPoint("LEFT", testBtn, "RIGHT", 8, 0)
        dlg.BcastBtn = bcastBtn

        local closeBtn = UI:CreateButton(dlg, 95, 28, "Close", "GameFontHighlight")
        closeBtn:SetPoint("BOTTOMRIGHT", -20, 16)
        dlg.CloseBtn = closeBtn

        -- Helper to apply active/inactive visual state to segmented buttons
        local function ApplySegmentState(btn, isActive)
            btn.isActive = isActive
            local theme = UI:GetTheme()
            local curR, curG, curB, curHex = WoWKB.AccentColor()
            if isActive then
                btn:SetBackdropColor(curR * 0.22, curG * 0.22, curB * 0.22, 0.95)
                btn:SetBackdropBorderColor(curR, curG, curB, 0.95)
                btn.Label:SetText(string.format("|cff%s* %s|r", curHex or "ffd100", btn.baseText or ""))
            else
                btn:SetBackdropColor(unpack(theme.btnBg or { 0.08, 0.10, 0.15, 1.0 }))
                btn:SetBackdropBorderColor(unpack(theme.btnBorder or { 0.22, 0.22, 0.22, 0.95 }))
                btn.Label:SetText(string.format("|cff888888%s|r", btn.baseText or ""))
            end
        end

        -- Synchronize Controls
        local function UpdateControls()
            local s = WoWKillboardSettings or KB.DefaultSettings
            local mode = s.alertMode or "SOUND_AND_BANNER"
            local scope = s.alertScope or "ZONE"
            local style = s.alertStyle or "BOTH"
            local theme = UI:GetTheme()
            local curR, curG, curB, curHex = WoWKB.AccentColor()
            local curCode = "|cff" .. (curHex or "ffd100")

            if dlg.TitleText then dlg.TitleText:SetText(curCode .. "FRONTLINE COMBAT ALERTS & RADAR|r") end
            if dlg.Sec1Title then dlg.Sec1Title:SetText(curCode .. "1. CASUALTY ALERT DELIVERY & CHAT STREAM|r") end
            if dlg.Sec2Title then dlg.Sec2Title:SetText(curCode .. "2. RADAR & PROXIMITY SCOPE|r") end
            if dlg.Sec3Title then dlg.Sec3Title:SetText(curCode .. "3. VISUAL ALERT STYLE|r") end
            if dlg.Sec4Title then dlg.Sec4Title:SetText(curCode .. "4. SCREEN POSITIONING & CALIBRATION|r") end
            if dlg.Sec5Title then dlg.Sec5Title:SetText(curCode .. "5. MARK OF SPITE DEATH POPUP|r") end
            if dlg.Sec6Title then dlg.Sec6Title:SetText(curCode .. "6. COMBAT FEED DESTINATION|r") end

            -- Section 1: Alert Delivery Mode & Live Chat Stream
            local showChat = (s.showChannelInChat == true)
            local isMuted = (mode == "OFF")
            local isBoth = (showChat and not isMuted)
            local isHeadsUp = (not showChat and not isMuted)
            local isChatOnly = (showChat and isMuted)
            local isOff = (not showChat and isMuted)

            ApplySegmentState(dlg.BtnPresetBoth, isBoth)
            ApplySegmentState(dlg.BtnPresetHeadsUp, isHeadsUp)
            ApplySegmentState(dlg.BtnPresetChat, isChatOnly)
            ApplySegmentState(dlg.BtnPresetOff, isOff)

            if isBoth then
                dlg.ModeHint:SetText(curCode .. "* Both Displays Active:|r |cff94a3b8Screen banner & audio horn trigger, and casualties stream into General chat.|r")
            elseif isHeadsUp then
                dlg.ModeHint:SetText(curCode .. "* Heads-Up Only:|r |cff94a3b8Screen banner & audio horn trigger. Chat window remains 100% clean and quiet.|r")
            elseif isChatOnly then
                dlg.ModeHint:SetText(curCode .. "* Silent Chat Stream:|r |cff94a3b8Casualties quietly stream into your chat window. Zero screen banners or audio horns.|r")
            else
                dlg.ModeHint:SetText("|cffff3333* All Alerts Muted:|r |cff94a3b8Screen banners and chat feeds suppressed. Kills recorded silently to database.|r")
            end

            if showChat then
                dlg.BtnToggleChat:SetBackdropColor(curR * 0.18, curG * 0.18, curB * 0.18, 0.95)
                dlg.BtnToggleChat:SetBackdropBorderColor(curR, curG, curB, 0.95)
                dlg.BtnToggleChat.Label:SetText(curCode .. "* Chat Window Feed: ON|r")
            else
                dlg.BtnToggleChat:SetBackdropColor(unpack(theme.btnBg or { 0.08, 0.10, 0.15, 1.0 }))
                dlg.BtnToggleChat:SetBackdropBorderColor(unpack(theme.btnBorder or { 0.22, 0.22, 0.22, 0.95 }))
                dlg.BtnToggleChat.Label:SetText("|cff888888Chat Window Feed: OFF|r")
            end

            if s.soundAlerts ~= false then
                dlg.BtnToggleSound:SetBackdropColor(curR * 0.18, curG * 0.18, curB * 0.18, 0.95)
                dlg.BtnToggleSound:SetBackdropBorderColor(curR, curG, curB, 0.95)
                dlg.BtnToggleSound.Label:SetText(curCode .. "* Audio Warhorn: ON|r")
            else
                dlg.BtnToggleSound:SetBackdropColor(unpack(theme.btnBg or { 0.08, 0.10, 0.15, 1.0 }))
                dlg.BtnToggleSound:SetBackdropBorderColor(unpack(theme.btnBorder or { 0.22, 0.22, 0.22, 0.95 }))
                dlg.BtnToggleSound.Label:SetText("|cff888888Audio Warhorn: OFF|r")
            end

            -- Section 2: Proximity Scope
            ApplySegmentState(dlg.BtnScopeZone, scope == "ZONE")
            ApplySegmentState(dlg.BtnScopeAll, scope == "ALL")
            ApplySegmentState(dlg.BtnScopeMine, scope == "MINE")

            if scope == "ZONE" then
                dlg.ScopeHint:SetText(curCode .. "* Radar:|r |cff94a3b8Alerts only when combat occurs in your current zone.|r")
            elseif scope == "ALL" then
                dlg.ScopeHint:SetText(curCode .. "* Broadcast:|r |cff94a3b8Alerts for all kills broadcasted across realm network.|r")
            else
                dlg.ScopeHint:SetText(curCode .. "* Solo:|r |cff94a3b8Only triggers when you personally kill or are killed.|r")
            end

            -- Section 3: Visual Alert Style
            ApplySegmentState(dlg.BtnStyleBoth, style == "BOTH")
            ApplySegmentState(dlg.BtnStyleRW, style == "RAID_WARNING")
            ApplySegmentState(dlg.BtnStyleBanner, style == "BANNER")

            if style == "BOTH" then
                dlg.StyleHint:SetText(curCode .. "* Dual Display:|r |cff94a3b8Flashes large Raid Warning text AND Tactical Kill Banner.|r")
            elseif style == "RAID_WARNING" then
                dlg.StyleHint:SetText("|cffff3333* Raid Warning:|r |cff94a3b8Flashes high-visibility cinematic text across screen center.|r")
            else
                dlg.StyleHint:SetText(curCode .. "* Tactical Banner:|r |cff94a3b8Displays compact banner with combatant class icons & GPS.|r")
            end

            -- Section 4: Screen Positioning
            local pos = s.bannerPosition or { point = "TOP", x = 0, y = -120 }
            dlg.PosCoords:SetText(string.format("%sCurrent Anchor:|r |cffffffff%s (X: %d, Y: %d)|r", curCode, pos.point or "TOP", pos.x or 0, pos.y or -120))

            if UI.bannerUnlocked then
                dlg.UnlockBtn.Label:SetText("|cffff3333Lock Toast Position|r")
                dlg.UnlockBtn:SetBackdropBorderColor(1.0, 0.2, 0.2, 0.9)
            else
                dlg.UnlockBtn.Label:SetText(curCode .. "Move Toast Position|r")
                dlg.UnlockBtn:SetBackdropBorderColor(curR, curG, curB, 0.6)
            end
            dlg.ResetBtn.Label:SetText("Reset to Center")
            dlg.ResetBtn:SetBackdropBorderColor(0.3, 0.3, 0.3, 1.0)
            dlg.CloseBtn.Label:SetText("Close")
            dlg.CloseBtn:SetBackdropBorderColor(curR, curG, curB, 0.6)

            -- Section 5: Mark of Spite Death Popup
            local promptEnabled = (s.promptMarkOnDeath ~= false and s.promptBountyOnDeath ~= false)
            ApplySegmentState(dlg.BtnMarkPromptOn, promptEnabled)
            ApplySegmentState(dlg.BtnMarkPromptOff, not promptEnabled)

            if promptEnabled then
                dlg.MarkHint:SetText("|cff00ff00* Enabled:|r |cff94a3b8Prompts revenge Mark of Spite contract upon dying in Open World.|r")
            else
                dlg.MarkHint:SetText("|cffff3333* Disabled:|r |cff94a3b8Suppresses popup upon PvP death. Mark contracts can still be set in War Room.|r")
            end

            -- Section 6: Combat Feed Destination
            local feedMode = s.combatFeedMode or "POPOUT"
            ApplySegmentState(dlg.BtnFeedWire, feedMode == "POPOUT")
            ApplySegmentState(dlg.BtnFeedChat, feedMode == "CHAT")
            ApplySegmentState(dlg.BtnFeedOff, feedMode == "OFF")

            if feedMode == "POPOUT" then
                dlg.FeedHint:SetText("|cff00e5ff* Shadow Network:|r |cff94a3b8Routes combat events to floating live feed window. Zero chat spam.|r")
            elseif feedMode == "CHAT" then
                dlg.FeedHint:SetText("|cffffd100* Main Chat:|r |cff94a3b8Prints combat records directly to your standard General chat frame.|r")
            else
                dlg.FeedHint:SetText("|cffff3333* Muted:|r |cff94a3b8Suppresses both chat and wire feed. Combat is recorded silently.|r")
            end
        end
        dlg.UpdateControls = UpdateControls

        -- Section 1 Event Handlers
        btnPresetBoth:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.showChannelInChat = true
            s.alertMode = "SOUND_AND_BANNER"
            s.soundAlerts = true
            if KB.db and KB.db.settings then
                KB.db.settings.showChannelInChat = true
                KB.db.settings.alertMode = "SOUND_AND_BANNER"
                KB.db.settings.soundAlerts = true
            end
            if KB.Sync and KB.Sync.ApplyChatVisibility then KB.Sync:ApplyChatVisibility() end
            UpdateControls()
        end)
        btnPresetHeadsUp:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.showChannelInChat = false
            s.alertMode = "SOUND_AND_BANNER"
            s.soundAlerts = true
            if KB.db and KB.db.settings then
                KB.db.settings.showChannelInChat = false
                KB.db.settings.alertMode = "SOUND_AND_BANNER"
                KB.db.settings.soundAlerts = true
            end
            if KB.Sync and KB.Sync.ApplyChatVisibility then KB.Sync:ApplyChatVisibility() end
            UpdateControls()
        end)
        btnPresetChat:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.showChannelInChat = true
            s.alertMode = "OFF"
            s.soundAlerts = false
            if KB.db and KB.db.settings then
                KB.db.settings.showChannelInChat = true
                KB.db.settings.alertMode = "OFF"
                KB.db.settings.soundAlerts = false
            end
            if KB.Sync and KB.Sync.ApplyChatVisibility then KB.Sync:ApplyChatVisibility() end
            UpdateControls()
        end)
        btnPresetOff:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.showChannelInChat = false
            s.alertMode = "OFF"
            s.soundAlerts = false
            if KB.db and KB.db.settings then
                KB.db.settings.showChannelInChat = false
                KB.db.settings.alertMode = "OFF"
                KB.db.settings.soundAlerts = false
            end
            if KB.Sync and KB.Sync.ApplyChatVisibility then KB.Sync:ApplyChatVisibility() end
            UpdateControls()
        end)

        btnToggleChat:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.showChannelInChat = not s.showChannelInChat
            if KB.db and KB.db.settings then KB.db.settings.showChannelInChat = s.showChannelInChat end
            if KB.Sync and KB.Sync.ApplyChatVisibility then KB.Sync:ApplyChatVisibility() end
            UpdateControls()
        end)

        btnToggleSound:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.soundAlerts = not s.soundAlerts
            if KB.db and KB.db.settings then KB.db.settings.soundAlerts = s.soundAlerts end
            UpdateControls()
        end)

        -- Section 2 Event Handlers
        btnScopeZone:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.alertScope = "ZONE"
            UpdateControls()
        end)
        btnScopeAll:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.alertScope = "ALL"
            UpdateControls()
        end)
        btnScopeMine:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.alertScope = "MINE"
            UpdateControls()
        end)

        -- Section 3 Event Handlers
        btnStyleBoth:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.alertStyle = "BOTH"
            s.alertRaidWarning = true
            UpdateControls()
        end)
        btnStyleRW:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.alertStyle = "RAID_WARNING"
            s.alertRaidWarning = true
            UpdateControls()
        end)
        btnStyleBanner:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.alertStyle = "BANNER"
            s.alertRaidWarning = false
            UpdateControls()
        end)

        -- Section 4 Event Handlers
        unlockBtn:SetScript("OnClick", function()
            UI:ToggleBannerLock()
            UpdateControls()
        end)
        resetBtn:SetScript("OnClick", function()
            UI:ResetBannerPosition()
        end)

        -- Section 5 Event Handlers
        btnMarkPromptOn:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.promptMarkOnDeath = true
            s.promptBountyOnDeath = true
            UpdateControls()
        end)
        btnMarkPromptOff:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.promptMarkOnDeath = false
            s.promptBountyOnDeath = false
            UpdateControls()
        end)

        -- Section 6 Event Handlers
        btnFeedWire:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.combatFeedMode = "POPOUT"
            s.showCombatWire = true
            if not InCombatLockdown() then UI:InitializeCombatWire() end
            if UI.CombatWireHUD then UI.CombatWireHUD:Show() end
            UpdateControls()
        end)
        btnFeedChat:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.combatFeedMode = "CHAT"
            UpdateControls()
        end)
        btnFeedOff:SetScript("OnClick", function()
            local s = WoWKillboardSettings or KB.DefaultSettings
            s.combatFeedMode = "OFF"
            UpdateControls()
        end)

        -- Footer Event Handlers
        testBtn:SetScript("OnClick", function()
            UI:TestKillBanner()
        end)
        bcastBtn:SetScript("OnClick", function()
            if KB.Sync and KB.Sync.BroadcastTestCasualty then
                KB.Sync:BroadcastTestCasualty("pve")
            end
        end)
        closeBtn:SetScript("OnClick", function()
            if UI.bannerUnlocked then UI:ToggleBannerLock(false) end
            dlg:Hide()
        end)

        UI.AlertsDialog = dlg
    end

    -- Theme Backdrop Styling
    local theme = UI:GetTheme()
    if not UI.AlertsDialog.SolidBg then
        local solid = UI.AlertsDialog:CreateTexture(nil, "BACKGROUND", nil, -8)
        solid:SetAllPoints(UI.AlertsDialog)
        UI.AlertsDialog.SolidBg = solid
    end
    if theme.id == "classic" then
        UI.AlertsDialog.SolidBg:Hide()
    else
        UI.AlertsDialog.SolidBg:Show()
        UI.AlertsDialog.SolidBg:SetColorTexture(unpack(theme.solidBg or theme.modalBg or {0.04, 0.05, 0.07, 1.0}))
    end

    UI.AlertsDialog:SetBackdrop(theme.modalBackdrop or {
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    UI.AlertsDialog:SetBackdropColor(unpack(theme.modalBg or {0.035, 0.045, 0.07, 1.0}))
    UI.AlertsDialog:SetBackdropBorderColor(unpack(theme.modalBorder or {0.45, 0.35, 0.18, 0.95}))
    if UI.AlertsDialog.Divider and theme.dividerColor then
        UI.AlertsDialog.Divider:SetColorTexture(unpack(theme.dividerColor))
    end
    if UI.AlertsDialog.BottomDivider and theme.dividerColor then
        UI.AlertsDialog.BottomDivider:SetColorTexture(unpack(theme.dividerColor))
    end

    UI.AlertsDialog.UpdateControls()
    UI.AlertsDialog:Show()
    if UI.AlertsDialog.Raise then UI.AlertsDialog:Raise() end
end

--------------------------------------------------------------------------------
-- Tactical Radar HUD (Moveable, Togglable Floating Hostile Scanner Window)
--------------------------------------------------------------------------------
local radarHUD = nil
local radarEntries = {}

function UI:InitializeRadarHUD()
    if radarHUD or InCombatLockdown() then return end

    local hud = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    hud:SetSize(270, 114)
    hud:SetFrameStrata("MEDIUM")
    hud:SetClampedToScreen(true)
    hud:SetMovable(true)
    hud:EnableMouse(true)
    hud:RegisterForDrag("LeftButton")

    -- Restore saved position or default to TOPRIGHT, -220, -160
    local pos = WoWKillboardSettings and WoWKillboardSettings.radarPos
    if pos and pos.point and pos.relPoint and pos.x and pos.y then
        hud:SetPoint(pos.point, UIParent, pos.relPoint, pos.x, pos.y)
    else
        hud:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -220, -160)
    end

    hud:SetScript("OnDragStart", function(self)
        if not InCombatLockdown() then
            self:StartMoving()
        end
    end)
    hud:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        WoWKillboardSettings = WoWKillboardSettings or {}
        WoWKillboardSettings.radarPos = { point = p, relPoint = rp, x = math.floor(x), y = math.floor(y) }
    end)

    -- Sleek dark tactical gunmetal backdrop
    hud:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    hud:SetBackdropColor(0.035, 0.045, 0.065, 0.94)
    hud:SetBackdropBorderColor(0.0, 0.85, 1.0, 0.75)

    -- Header Drag Bar
    local header = CreateFrame("Frame", nil, hud, "BackdropTemplate")
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(20)
    header:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
    })
    header:SetBackdropColor(0.07, 0.10, 0.15, 0.98)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() if not InCombatLockdown() then hud:StartMoving() end end)
    header:SetScript("OnDragStop", function()
        hud:StopMovingOrSizing()
        local p, _, rp, x, y = hud:GetPoint()
        WoWKillboardSettings = WoWKillboardSettings or {}
        WoWKillboardSettings.radarPos = { point = p, relPoint = rp, x = math.floor(x), y = math.floor(y) }
    end)

    local title = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    title:SetPoint("LEFT", 6, 0)
    title:SetText("|cff00e5ffKB RADAR|r  |cff64748b(Tactical HUD)|r")

    -- Close Button
    local close = CreateFrame("Button", nil, header)
    close:SetSize(16, 16)
    close:SetPoint("RIGHT", -2, 0)
    local closeText = close:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    closeText:SetPoint("CENTER", 0, 0)
    closeText:SetText("|cffff4444X|r")
    close:SetScript("OnClick", function()
        hud:Hide()
        SafePrint("|cff00ccff[WoWKB]|r Tactical Radar HUD hidden. Type |cffffff00/kb radar|r to show.")
    end)

    -- Hostile Entry Rows (Up to 3 hostiles displayed cleanly)
    hud.rows = {}
    for i = 1, 3 do
        local row = CreateFrame("Frame", nil, hud)
        row:SetSize(262, 28)
        row:SetPoint("TOPLEFT", 4, -22 - (i - 1) * 30)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", 4, 0)
        row.icon = icon

        local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        nameText:SetPoint("LEFT", icon, "RIGHT", 6, 4)
        nameText:SetJustifyH("LEFT")
        row.nameText = nameText

        local subText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        subText:SetPoint("LEFT", icon, "RIGHT", 6, -8)
        subText:SetJustifyH("LEFT")
        row.subText = subText

        local timeText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        timeText:SetPoint("RIGHT", -6, 4)
        timeText:SetJustifyH("RIGHT")
        row.timeText = timeText

        row:Hide()
        table.insert(hud.rows, row)
    end

    local emptyText = hud:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    emptyText:SetPoint("CENTER", 0, -8)
    emptyText:SetText("|cff64748bNo hostiles in immediate proximity|r")
    hud.emptyText = emptyText

    radarHUD = hud
    UI.RadarHUD = hud
    hud:Hide()
end

function UI:RefreshRadarHUD()
    if not radarHUD then return end
    local count = #radarEntries
    if count == 0 then
        radarHUD.emptyText:Show()
        for _, row in ipairs(radarHUD.rows) do row:Hide() end
        radarHUD:SetHeight(54)
    else
        radarHUD.emptyText:Hide()
        for i = 1, 3 do
            local row = radarHUD.rows[i]
            local entry = radarEntries[i]
            if entry then
                local col = (KB.ClassColors and KB.ClassColors[entry.class]) or "FFFFFF"
                local lvlStr = (entry.level and entry.level > 0 and entry.level <= 85) and string.format("[%d] ", entry.level) or ""
                row.nameText:SetText(string.format("|cff%s%s%s|r", col, lvlStr, entry.name))

                local guildStr = (entry.guild and entry.guild ~= "None" and entry.guild ~= "") and (" <" .. entry.guild .. ">") or ""
                local zoneShort = entry.zone or "Wilderness"
                if #zoneShort > 22 then zoneShort = zoneShort:sub(1, 20) .. ".." end
                row.subText:SetText(string.format("|cff94a3b8%s%s|r", zoneShort, guildStr))

                local diff = math.max(0, time() - (entry.time or time()))
                local timeStr = (diff < 60) and string.format("%ds ago", diff) or string.format("%dm ago", math.floor(diff / 60))
                row.timeText:SetText(string.format("|cff64748b%s|r", timeStr))

                local coords = CLASS_COORDS and CLASS_COORDS[entry.class]
                if coords then
                    row.icon:SetTexture(CLASS_ICON_TEXTURE or "Interface\\TargetingFrame\\UI-Classes-Circles")
                    row.icon:SetTexCoord(unpack(coords))
                    row.icon:Show()
                else
                    row.icon:Hide()
                end

                row:Show()
            else
                row:Hide()
            end
        end
        radarHUD:SetHeight(24 + count * 30)
    end
end

function UI:UpdateRadarHUD(info)
    if InCombatLockdown() then return end
    if not radarHUD then UI:InitializeRadarHUD() end
    if not radarHUD then return end

    local s = WoWKillboardSettings or KB.DefaultSettings
    if s and s.showRadarHUD == false then return end

    -- Check if hostile already in radarEntries and update
    local found = nil
    for idx, e in ipairs(radarEntries) do
        if e.name == info.name then
            found = idx
            break
        end
    end
    if found then
        table.remove(radarEntries, found)
    end
    table.insert(radarEntries, 1, {
        name = info.name,
        class = (info.class or "UNKNOWN"):upper(),
        level = info.level or 0,
        guild = info.guild,
        zone = GetZoneText() or "Wilderness",
        time = time(),
    })
    while #radarEntries > 3 do
        table.remove(radarEntries)
    end

    UI:RefreshRadarHUD()
    radarHUD:SetAlpha(1.0)
    radarHUD:Show()

    -- Auto-dismiss timer after 15 seconds of inactivity if not hovered
    if radarHUD.fadeTimer then
        radarHUD.fadeTimer:Cancel()
    end
    if C_Timer and C_Timer.NewTimer then
        radarHUD.fadeTimer = C_Timer.NewTimer(15, function()
            if radarHUD and not radarHUD:IsMouseOver() then
                if InCombatLockdown() then
                    radarHUD:SetAlpha(0)
                    UI.PendingHides = UI.PendingHides or {}
                    table.insert(UI.PendingHides, radarHUD)
                else
                    radarHUD:Hide()
                end
            end
        end)
    end
end

function UI:ToggleRadarHUD()
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot toggle Tactical Radar HUD during combat.")
        return
    end
    if not radarHUD then UI:InitializeRadarHUD() end
    if not radarHUD then return end
    if radarHUD:IsShown() then
        radarHUD:Hide()
        SafePrint("|cff00ccff[WoWKB]|r Tactical Radar HUD: |cffff4444Hidden|r.")
    else
        UI:RefreshRadarHUD()
        radarHUD:SetAlpha(1.0)
        radarHUD:Show()
        SafePrint("|cff00ccff[WoWKB]|r Tactical Radar HUD: |cff00ff00Shown|r (Click & drag header to reposition).")
    end
end

--------------------------------------------------------------------------------
-- War Council Rally Muster Dialog (Vanguard Squad & Raid Recruitment Panel)
--------------------------------------------------------------------------------
function UI:ShowRallyDialog()
    if InCombatLockdown() then
        SafePrint("|cffff0000[WoWKB]|r Cannot muster war rally during combat lockdown.")
        return
    end

    if not UI.RallyDialog then
        local dlg = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        dlg:SetSize(480, 480)
        dlg:SetPoint("CENTER", 0, 20)
        dlg:SetFrameStrata("DIALOG")
        dlg:SetFrameLevel(120)
        dlg:EnableMouse(true)
        dlg:SetClampedToScreen(true)
        dlg:SetMovable(true)
        dlg:RegisterForDrag("LeftButton")
        dlg:SetScript("OnDragStart", function(self)
            if not InCombatLockdown() then self:StartMoving() end
        end)
        dlg:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
        end)

        -- ESC Key Handling
        dlg:EnableKeyboard(false)
        dlg:SetScript("OnShow", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(true) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnHide", function(self)
            if self.EnableKeyboard then self:EnableKeyboard(false) end
            if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
        end)
        dlg:SetScript("OnKeyDown", function(self, key)
            if not self:IsShown() then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
                return
            end
            if key == "ESCAPE" then
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
                self:Hide()
            else
                if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
            end
        end)

        -- Header
        local title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText(" |cffffd100MUSTER FACTION VANGUARD RALLY|r")
        dlg.TitleText = title

        local subtitle = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        subtitle:SetPoint("TOP", 0, -38)
        subtitle:SetText("|cff94a3b8Sound the War Horn to assemble allies for coordinated PvP engagements.|r")
        dlg.SubtitleText = subtitle

        local div = dlg:CreateTexture(nil, "ARTWORK")
        div:SetHeight(1)
        div:SetPoint("TOPLEFT", 18, -56)
        div:SetPoint("TOPRIGHT", -18, -56)
        dlg.Divider = div

        -- Helper to style segment buttons
        local function StyleChip(btn, text)
            btn.baseText = text
            btn.Label:SetText(text)
        end
        local function SetChipActive(btn, isActive)
            btn.isActive = isActive
            local theme = UI:GetTheme()
            if isActive then
                btn:SetBackdropColor(unpack(theme.btnActiveBg or { 0.25, 0.18, 0.07, 1.0 }))
                btn:SetBackdropBorderColor(unpack(theme.btnActiveBorder or { 1.0, 0.82, 0.0, 1.0 }))
                btn.Label:SetText(string.format("|cff00ff00*|r |cffffd100%s|r", btn.baseText or ""))
            else
                btn:SetBackdropColor(unpack(theme.btnBg or { 0.08, 0.10, 0.15, 1.0 }))
                btn:SetBackdropBorderColor(unpack(theme.btnBorder or { 0.45, 0.35, 0.18, 0.95 }))
                btn.Label:SetText(string.format("|cff888888%s|r", btn.baseText or ""))
            end
        end

        -- State variables
        dlg.selectedGroupType = "PARTY"
        dlg.selectedContentType = "WORLD"
        dlg.selectedRoles = { tank = true, heal = true, dps = true }

        -- 1. Group Size
        local sec1Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec1Title:SetPoint("TOPLEFT", 24, -68)
        sec1Title:SetText("|cffffffff1. SQUAD CAPACITY / GROUP SIZE|r")

        local btnParty = UI:CreateButton(dlg, 210, 24, "5-Man Squad (Party)", "GameFontHighlightSmall")
        btnParty:SetPoint("TOPLEFT", 24, -88)
        StyleChip(btnParty, "5-Man Squad (Party)")
        dlg.BtnParty = btnParty

        local btnRaid = UI:CreateButton(dlg, 210, 24, "40-Man Strike Team (Raid)", "GameFontHighlightSmall")
        btnRaid:SetPoint("LEFT", btnParty, "RIGHT", 12, 0)
        StyleChip(btnRaid, "40-Man Strike Team (Raid)")
        dlg.BtnRaid = btnRaid

        btnParty:SetScript("OnClick", function()
            dlg.selectedGroupType = "PARTY"
            SetChipActive(dlg.BtnParty, true)
            SetChipActive(dlg.BtnRaid, false)
        end)
        btnRaid:SetScript("OnClick", function()
            dlg.selectedGroupType = "RAID"
            SetChipActive(dlg.BtnParty, false)
            SetChipActive(dlg.BtnRaid, true)
        end)

        -- 2. Content Type
        local sec2Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec2Title:SetPoint("TOPLEFT", 24, -122)
        sec2Title:SetText("|cffffffff2. THEATRE / CONTENT TYPE|r")

        local btnWorld = UI:CreateButton(dlg, 210, 24, "Open World PvP", "GameFontHighlightSmall")
        btnWorld:SetPoint("TOPLEFT", 24, -142)
        StyleChip(btnWorld, "Open World PvP")
        dlg.BtnWorld = btnWorld

        local btnBG = UI:CreateButton(dlg, 210, 24, "Battleground", "GameFontHighlightSmall")
        btnBG:SetPoint("LEFT", btnWorld, "RIGHT", 12, 0)
        StyleChip(btnBG, "Battleground")
        dlg.BtnBG = btnBG

        btnWorld:SetScript("OnClick", function()
            dlg.selectedContentType = "WORLD"
            SetChipActive(dlg.BtnWorld, true)
            SetChipActive(dlg.BtnBG, false)
            if dlg.ebLocation and (dlg.ebLocation:GetText() == "" or dlg.ebLocation:GetText():find("Warsong") or dlg.ebLocation:GetText():find("Arathi") or dlg.ebLocation:GetText():find("Alterac")) then
                dlg.ebLocation:SetText(GetZoneText() or "Azeroth")
            end
        end)
        btnBG:SetScript("OnClick", function()
            dlg.selectedContentType = "BG"
            SetChipActive(dlg.BtnWorld, false)
            SetChipActive(dlg.BtnBG, true)
            if dlg.ebLocation and (dlg.ebLocation:GetText() == "" or dlg.ebLocation:GetText() == GetZoneText()) then
                dlg.ebLocation:SetText("Warsong Gulch")
            end
        end)

        -- 3. Location / Zone
        local sec3Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec3Title:SetPoint("TOPLEFT", 24, -176)
        sec3Title:SetText("|cffffffff3. TARGET LOCATION / ZONE / BATTLEGROUND|r")

        local ebLocation = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebLocation:SetSize(432, 24)
        ebLocation:SetPoint("TOPLEFT", 24, -196)
        ebLocation:SetAutoFocus(false)
        ebLocation:SetFontObject("GameFontHighlightSmall")
        ebLocation:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebLocation:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebLocation:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebLocation:SetTextInsets(8, 8, 0, 0)
        dlg.ebLocation = ebLocation

        -- 4. Preferred Level Range
        local sec4Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec4Title:SetPoint("TOPLEFT", 24, -230)
        sec4Title:SetText("|cffffffff4. PREFERRED LEVEL BRACKET (MIN / MAX)|r")

        local ebMinLevel = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebMinLevel:SetSize(80, 24)
        ebMinLevel:SetPoint("TOPLEFT", 24, -250)
        ebMinLevel:SetAutoFocus(false)
        ebMinLevel:SetNumeric(true)
        ebMinLevel:SetFontObject("GameFontHighlightSmall")
        ebMinLevel:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebMinLevel:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebMinLevel:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebMinLevel:SetTextInsets(8, 8, 0, 0)
        dlg.ebMinLevel = ebMinLevel

        local toLabel = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        toLabel:SetPoint("LEFT", ebMinLevel, "RIGHT", 10, 0)
        toLabel:SetText("to")

        local ebMaxLevel = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebMaxLevel:SetSize(80, 24)
        ebMaxLevel:SetPoint("LEFT", toLabel, "RIGHT", 10, 0)
        ebMaxLevel:SetAutoFocus(false)
        ebMaxLevel:SetNumeric(true)
        ebMaxLevel:SetFontObject("GameFontHighlightSmall")
        ebMaxLevel:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebMaxLevel:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebMaxLevel:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebMaxLevel:SetTextInsets(8, 8, 0, 0)
        dlg.ebMaxLevel = ebMaxLevel

        local lvlHint = dlg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        lvlHint:SetPoint("LEFT", ebMaxLevel, "RIGHT", 14, 0)
        lvlHint:SetText("|cff64748b(e.g., 20 to 29 for Twink bracket or 1 to 60)|r")

        -- 5. Requested Roles
        local sec5Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec5Title:SetPoint("TOPLEFT", 24, -284)
        sec5Title:SetText("|cffffffff5. REQUESTED COMBAT ROLES / SPECS|r")

        local btnTank = UI:CreateButton(dlg, 136, 24, "Tank", "GameFontHighlightSmall")
        btnTank:SetPoint("TOPLEFT", 24, -304)
        StyleChip(btnTank, "Tank")
        dlg.BtnTank = btnTank

        local btnHeal = UI:CreateButton(dlg, 136, 24, "Healer", "GameFontHighlightSmall")
        btnHeal:SetPoint("LEFT", btnTank, "RIGHT", 12, 0)
        StyleChip(btnHeal, "Healer")
        dlg.BtnHeal = btnHeal

        local btnDPS = UI:CreateButton(dlg, 136, 24, "DPS", "GameFontHighlightSmall")
        btnDPS:SetPoint("LEFT", btnHeal, "RIGHT", 12, 0)
        StyleChip(btnDPS, "DPS")
        dlg.BtnDPS = btnDPS

        btnTank:SetScript("OnClick", function()
            dlg.selectedRoles.tank = not dlg.selectedRoles.tank
            SetChipActive(dlg.BtnTank, dlg.selectedRoles.tank)
        end)
        btnHeal:SetScript("OnClick", function()
            dlg.selectedRoles.heal = not dlg.selectedRoles.heal
            SetChipActive(dlg.BtnHeal, dlg.selectedRoles.heal)
        end)
        btnDPS:SetScript("OnClick", function()
            dlg.selectedRoles.dps = not dlg.selectedRoles.dps
            SetChipActive(dlg.BtnDPS, dlg.selectedRoles.dps)
        end)

        -- 6. Rally Message / Battle Cry
        local sec6Title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        sec6Title:SetPoint("TOPLEFT", 24, -338)
        sec6Title:SetText("|cffffffff6. BATTLE CRY / MISSION DIRECTIVE|r")

        local ebMsg = CreateFrame("EditBox", nil, dlg, "BackdropTemplate")
        ebMsg:SetSize(432, 24)
        ebMsg:SetPoint("TOPLEFT", 24, -358)
        ebMsg:SetAutoFocus(false)
        ebMsg:SetFontObject("GameFontHighlightSmall")
        ebMsg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            edgeSize = 1,
        })
        ebMsg:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
        ebMsg:SetBackdropBorderColor(0.3, 0.35, 0.45, 1)
        ebMsg:SetTextInsets(8, 8, 0, 0)
        dlg.ebMsg = ebMsg

        -- Bottom Divider
        local bDiv = dlg:CreateTexture(nil, "ARTWORK")
        bDiv:SetHeight(1)
        bDiv:SetPoint("TOPLEFT", 18, -394)
        bDiv:SetPoint("TOPRIGHT", -18, -394)
        dlg.BottomDivider = bDiv

        -- Submit Button
        local submitBtn = UI:CreateButton(dlg, 240, 30, " Muster Vanguard Rally", "GameFontNormal")
        submitBtn:SetPoint("BOTTOMLEFT", 24, 20)
        submitBtn:SetScript("OnClick", function()
            local groupType = dlg.selectedGroupType or "PARTY"
            local contentType = dlg.selectedContentType or "WORLD"
            local locText = dlg.ebLocation:GetText() or GetZoneText() or "Azeroth"
            local minLvl = tonumber(dlg.ebMinLevel:GetText()) or 1
            local maxLvl = tonumber(dlg.ebMaxLevel:GetText()) or 60
            local msgText = dlg.ebMsg:GetText() or "Muster Vanguard Strike Team!"
            local roles = {
                tank = dlg.selectedRoles.tank,
                heal = dlg.selectedRoles.heal,
                dps = dlg.selectedRoles.dps,
            }

            if KB.Reinforcements and KB.Reinforcements.CreateCustomRally then
                KB.Reinforcements:CreateCustomRally({
                    groupType = groupType,
                    contentType = contentType,
                    zone = locText,
                    minLevel = minLvl,
                    maxLevel = maxLvl,
                    roles = roles,
                    message = msgText,
                })
            end

            dlg:Hide()
            UI:Refresh()
        end)
        dlg.SubmitBtn = submitBtn

        local cancelBtn = UI:CreateButton(dlg, 120, 30, "Cancel", "GameFontHighlight")
        cancelBtn:SetPoint("BOTTOMRIGHT", -24, 20)
        cancelBtn:SetScript("OnClick", function()
            dlg:Hide()
        end)
        dlg.CancelBtn = cancelBtn

        dlg.SetChipActive = SetChipActive
        UI.RallyDialog = dlg
    end

    -- Update active theme and reset fields to sensible defaults
    local theme = UI:GetTheme()
    UI.RallyDialog:SetBackdrop(theme.modalBackdrop or {
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    UI.RallyDialog:SetBackdropColor(unpack(theme.modalBg or { 0.035, 0.045, 0.07, 1.0 }))
    UI.RallyDialog:SetBackdropBorderColor(unpack(theme.modalBorder or { 0.45, 0.35, 0.18, 0.95 }))
    if UI.RallyDialog.Divider and theme.dividerColor then
        UI.RallyDialog.Divider:SetColorTexture(unpack(theme.dividerColor))
    end
    if UI.RallyDialog.BottomDivider and theme.dividerColor then
        UI.RallyDialog.BottomDivider:SetColorTexture(unpack(theme.dividerColor))
    end

    -- Pre-populate defaults
    local pLevel = UnitLevel("player") or 20
    local pZone = GetZoneText() or "Azeroth"
    UI.RallyDialog.selectedGroupType = "PARTY"
    UI.RallyDialog.selectedContentType = "WORLD"
    UI.RallyDialog.selectedRoles = { tank = true, heal = true, dps = true }

    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnParty, true)
    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnRaid, false)
    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnWorld, true)
    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnBG, false)
    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnTank, true)
    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnHeal, true)
    UI.RallyDialog.SetChipActive(UI.RallyDialog.BtnDPS, true)

    UI.RallyDialog.ebLocation:SetText(pZone)
    local minL = math.max(1, pLevel - 5)
    local maxL = math.min(60, pLevel + 5)
    UI.RallyDialog.ebMinLevel:SetNumber(minL)
    UI.RallyDialog.ebMaxLevel:SetNumber(maxL)
    UI.RallyDialog.ebMsg:SetText(string.format("Muster Vanguard in %s! Whisper 'rally' to join.", pZone))

    UI.RallyDialog:Show()
    if UI.RallyDialog.Raise then UI.RallyDialog:Raise() end
end

--------------------------------------------------------------------------------
-- The Shadow Network (Floating, Moveable Live Combat Pop-Out Window)
--------------------------------------------------------------------------------
local combatWireHUD = nil

function UI:InitializeCombatWire()
    if combatWireHUD or InCombatLockdown() then return end

    local hud = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    hud:SetSize(440, 180)
    hud:SetFrameStrata("MEDIUM")
    hud:SetClampedToScreen(true)
    hud:SetMovable(true)
    hud:EnableMouse(true)
    hud:RegisterForDrag("LeftButton")

    -- Restore saved position or default to TOPLEFT, 24, -180
    local pos = WoWKillboardSettings and WoWKillboardSettings.combatWirePos
    if pos and pos.point and pos.relPoint and pos.x and pos.y then
        hud:SetPoint(pos.point, UIParent, pos.relPoint, pos.x, pos.y)
    else
        hud:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 24, -180)
    end

    hud:SetScript("OnDragStart", function(self)
        if not InCombatLockdown() then
            self:StartMoving()
        end
    end)
    hud:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        WoWKillboardSettings = WoWKillboardSettings or {}
        WoWKillboardSettings.combatWirePos = { point = p, relPoint = rp, x = math.floor(x), y = math.floor(y) }
    end)

    -- Sleek dark tactical gunmetal backdrop
    hud:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    hud:SetBackdropColor(0.03, 0.04, 0.05, 0.94)
    hud:SetBackdropBorderColor(0.0, 0.85, 1.0, 0.75)

    -- Header Drag Bar
    local header = CreateFrame("Frame", nil, hud, "BackdropTemplate")
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(22)
    header:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
    })
    header:SetBackdropColor(0.06, 0.09, 0.14, 0.98)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() if not InCombatLockdown() then hud:StartMoving() end end)
    header:SetScript("OnDragStop", function()
        hud:StopMovingOrSizing()
        local p, _, rp, x, y = hud:GetPoint()
        WoWKillboardSettings = WoWKillboardSettings or {}
        WoWKillboardSettings.combatWirePos = { point = p, relPoint = rp, x = math.floor(x), y = math.floor(y) }
    end)
    hud.header = header

    local title = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    title:SetPoint("LEFT", 8, 0)
    title:SetText("|cff00e5ffTHE SHADOW NETWORK|r  |cff64748b(Pop-Out Live Feed)|r")

    -- Close Button [X]
    local close = CreateFrame("Button", nil, header)
    close:SetSize(18, 18)
    close:SetPoint("RIGHT", -3, 0)
    local closeText = close:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    closeText:SetPoint("CENTER", 0, 0)
    closeText:SetText("|cffff4444X|r")
    close:SetScript("OnClick", function()
        hud:Hide()
        WoWKillboardSettings = WoWKillboardSettings or {}
        WoWKillboardSettings.showCombatWire = false
        SafePrint("|cff00ccff[WoWKB]|r Shadow Network hidden. Click |cffffd100[Network]|r in header or type |cffffff00/kb wire|r to restore.")
    end)

    -- Clear Button [Clear]
    local clearBtn = CreateFrame("Button", nil, header)
    clearBtn:SetSize(42, 18)
    clearBtn:SetPoint("RIGHT", close, "LEFT", -4, 0)
    local clearText = clearBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    clearText:SetPoint("CENTER", 0, 0)
    clearText:SetText("|cff94a3b8Clear|r")
    clearBtn:SetScript("OnClick", function()
        if hud.msgFrame and hud.msgFrame.Clear then
            hud.msgFrame:Clear()
            hud.msgFrame:AddMessage("|cff64748b[Shadow Network cleared  -  listening for live combat records...]|r")
        end
    end)

    -- Scrolling Combat Message Frame
    local msgFrame = CreateFrame("ScrollingMessageFrame", nil, hud)
    msgFrame:SetPoint("TOPLEFT", 8, -26)
    msgFrame:SetPoint("BOTTOMRIGHT", -8, 8)
    msgFrame:SetFontObject("GameFontHighlightSmall")
    msgFrame:SetJustifyH("LEFT")
    msgFrame:SetMaxLines(100)
    msgFrame:SetFading(false)
    msgFrame:EnableMouseWheel(true)
    msgFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then
            self:ScrollUp()
        else
            self:ScrollDown()
        end
    end)

    msgFrame:AddMessage("|cff00e5ff[WoWKB Network Initialized]|r |cff64748bCombat events stream here. Chat is clean.|r")

    hud.msgFrame = msgFrame
    combatWireHUD = hud
    UI.CombatWireHUD = hud

    -- Honor saved show setting
    local s = WoWKillboardSettings or KB.DefaultSettings
    if s and s.showCombatWire == false then
        hud:Hide()
    else
        hud:Show()
    end
end

function UI:AddCombatWireEntry(killmail, chatMsg)
    local s = WoWKillboardSettings or KB.DefaultSettings
    local feedMode = (s and s.combatFeedMode) or "POPOUT"
    if feedMode == "OFF" then return end

    local tStr = date("%H:%M:%S", (killmail and killmail.timestamp) or time())
    local line = string.format("|cff64748b[%s]|r %s", tStr, chatMsg or "")

    if InCombatLockdown() then
        UI.PendingWireEntries = UI.PendingWireEntries or {}
        table.insert(UI.PendingWireEntries, line)
        return
    end

    if not combatWireHUD then
        UI:InitializeCombatWire()
    end
    if not combatWireHUD then return end

    if combatWireHUD.msgFrame then
        combatWireHUD.msgFrame:AddMessage(line)
    end

    if (not s or s.showCombatWire ~= false) and not combatWireHUD:IsShown() then
        combatWireHUD:Show()
    end
end

function UI:ToggleCombatWire()
    if InCombatLockdown() then
        SafePrint("|cffff9900[WoWKB]|r Cannot toggle Shadow Network during combat.")
        return
    end
    if not combatWireHUD then UI:InitializeCombatWire() end
    if not combatWireHUD then return end

    WoWKillboardSettings = WoWKillboardSettings or {}
    if combatWireHUD:IsShown() then
        combatWireHUD:Hide()
        WoWKillboardSettings.showCombatWire = false
        SafePrint("|cff00ccff[WoWKB]|r Shadow Network: |cffff4444Hidden|r.")
    else
        combatWireHUD:Show()
        WoWKillboardSettings.showCombatWire = true
        SafePrint("|cff00ccff[WoWKB]|r Shadow Network: |cff00ff00Shown|r (Click & drag header to reposition).")
    end
end


